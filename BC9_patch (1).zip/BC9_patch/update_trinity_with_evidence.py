#!/usr/bin/env python3
"""
update_trinity_with_evidence.py
--------------------------------

After running a Trinity cycle, this helper script attaches additional
context to the output by injecting the most recent Body daily check‑in
and evidence links.  The result is a new JSON payload and an
accompanying markdown summary that correlates the run outputs with
human‑level evidence artifacts.

Usage (from repository root):

```
python scripts/update_trinity_with_evidence.py \
    --trinity-json docs/trinity-latest.json \
    --body-json docs/body-track-daily-latest.json \
    --evidence-json docs/evidence-links-latest.json \
    --output-json docs/trinity-latest-with-evidence.json \
    --output-md docs/trinity-latest-with-evidence.md
```

If any of the optional inputs are missing, the script still
generates a valid output with whatever information is available.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any, Dict, Optional


def load_json(path: Path) -> Optional[Dict[str, Any]]:
    """Load a JSON file if it exists, else return None."""
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None


def build_output(trinity: Dict[str, Any] | None,
                 body: Dict[str, Any] | None,
                 evidence: Dict[str, Any] | None) -> Dict[str, Any]:
    """Merge the input dictionaries into a single payload."""
    result: Dict[str, Any] = {}
    if trinity is not None:
        result.update(trinity)
    # Insert body daily
    if body is not None:
        result['body_daily'] = body
    # Insert evidence links
    if evidence is not None:
        result['evidence_links'] = evidence
    return result


def render_markdown(data: Dict[str, Any]) -> str:
    """Render a human‑readable markdown report summarising the merged payload."""
    lines: list[str] = []
    lines.append("# Trinity Run with Evidence")
    lines.append("")
    generated = data.get('generated_utc') or '(unknown)'  # fallback
    lines.append(f"- generated_utc: `{generated}`")
    overall_status = data.get('overall_status') or data.get('status') or '(unknown)'
    lines.append(f"- overall_status: **{overall_status}**")
    lines.append("")
    # Summarise lanes (if present)
    if 'lanes' in data and isinstance(data['lanes'], list):
        lines.append("## Lane summary")
        lines.append("")
        lines.append("| lane | status | returncode | duration_seconds |")
        lines.append("|---|---|---:|---:|")
        for lane in data['lanes']:
            lane_name = lane.get('lane', '(unknown)')
            status = lane.get('status', '(?)')
            returncode = lane.get('returncode', '-')
            dur = lane.get('duration_seconds', '-')
            lines.append(f"| {lane_name} | {status} | {returncode} | {dur} |")
        lines.append("")
    # Summarise body daily
    body = data.get('body_daily')
    if body is not None:
        lines.append("## Body Daily Check‑In")
        lines.append("")
        # Print summary metrics if available
        if isinstance(body, dict):
            lines.append("```json")
            lines.append(json.dumps(body, indent=2))
            lines.append("```")
            lines.append("")
    # Summarise evidence
    ev = data.get('evidence_links')
    if ev is not None:
        lines.append("## Evidence Links")
        lines.append("")
        if isinstance(ev, dict):
            # Show number of link entries
            entries = ev.get('links') or ev
            count = len(entries) if hasattr(entries, '__len__') else 'unknown'
            lines.append(f"Total links: **{count}**")
            lines.append("")
            lines.append("```json")
            lines.append(json.dumps(ev, indent=2))
            lines.append("```")
            lines.append("")
    return "\n".join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(description="Attach body and evidence data to a Trinity run.")
    parser.add_argument("--trinity-json", required=False, default="docs/trinity-latest.json",
                        help="Path to the Trinity run JSON file")
    parser.add_argument("--body-json", required=False, default="docs/body-track-daily-latest.json",
                        help="Path to the Body daily check‑in JSON file")
    parser.add_argument("--evidence-json", required=False, default="docs/evidence-links-latest.json",
                        help="Path to the evidence links JSON file")
    parser.add_argument("--output-json", required=False, default="docs/trinity-latest-with-evidence.json",
                        help="Path to write the merged JSON output")
    parser.add_argument("--output-md", required=False, default="docs/trinity-latest-with-evidence.md",
                        help="Path to write the merged markdown summary")
    args = parser.parse_args()

    trinity_data = load_json(Path(args.trinity_json))
    body_data = load_json(Path(args.body_json))
    evidence_data = load_json(Path(args.evidence_json))

    merged = build_output(trinity_data, body_data, evidence_data)

    out_json_path = Path(args.output_json)
    out_md_path = Path(args.output_md)
    out_json_path.parent.mkdir(parents=True, exist_ok=True)
    out_md_path.parent.mkdir(parents=True, exist_ok=True)
    out_json_path.write_text(json.dumps(merged, indent=2) + "\n", encoding="utf-8")
    out_md_path.write_text(render_markdown(merged), encoding="utf-8")
    print(f"Merged Trinity run saved to {out_json_path} and {out_md_path}")


if __name__ == "__main__":
    main()