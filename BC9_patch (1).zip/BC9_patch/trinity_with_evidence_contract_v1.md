# Trinity with Evidence Contract (v1)

This document defines the structure of the JSON and Markdown files
produced by the `update_trinity_with_evidence.py` script.  The goal is
to enrich a Trinity run with additional context from the Body lane and
explicit evidence links.

## JSON Structure

The output JSON is a superset of the original `trinity-latest.json`:

- `generated_utc` (string): ISO 8601 timestamp of the Trinity run.
- `overall_status` (string): high‑level status, e.g. `PASS`, `WARN`, or `FAIL`.
- `lanes` (array of objects): details of each lane run (Body, Mind,
  Heart).  Each object contains keys such as `lane`, `status`,
  `returncode`, and `duration_seconds`.
- `body_daily` (object, optional): the content of
  `body-track-daily-latest.json`.  This usually contains the user’s
  daily check‑in metrics and notes.
- `evidence_links` (object or array, optional): the contents of
  `evidence-links-latest.json`.  This maps claim and control IDs to
  their associated PDF references.

Additional fields from the original Trinity run are preserved.

## Markdown Summary

The Markdown summary includes:

1. A heading and the generation timestamp.
2. A status line showing the overall status.
3. A table summarising the lanes (if available).
4. A JSON dump of the Body daily data (if available).
5. A summary of evidence links, including a count of how many
   link entries there are and a JSON dump of the link structure.

## Usage Notes

Run `update_trinity_with_evidence.py` after you have generated:

1. `docs/trinity-latest.json` from `trinity_runner.py`.
2. `docs/body-track-daily-latest.json` from the Body lane check‑in.
3. `docs/evidence-links-latest.json` from `generate_evidence_links.py`.

This script is idempotent and safe to run even if one or more of the
input files are missing; the missing fields will simply not appear
in the merged output.