"""
scripts/render_journey_pdf_registry.py
--------------------------------------

Render docs/journey_pdf_registry_v0.json into docs/JOURNEY_PDF_REGISTRY.md
for human browsing.

This script is pure standard library.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


def main() -> int:
    root = Path(".")
    src = root / "docs/journey_pdf_registry_v0.json"
    out = root / "docs/JOURNEY_PDF_REGISTRY.md"
    if not src.exists():
        out.write_text("# Journey PDF Registry\n\nMissing registry JSON.\n", encoding="utf-8")
        return 1

    payload = json.loads(src.read_text(encoding="utf-8"))
    entries = payload.get("entries", [])

    lines = [
        "# Journey PDF Registry",
        "",
        f"Last rendered: `{datetime.now(timezone.utc).replace(microsecond=0).isoformat()}`",
        "",
        "| version | agent | title | created_utc | modified_utc | drive_url |",
        "|---|---|---|---|---|---|",
    ]

    for e in entries:
        lines.append(
            f"| {e.get('version_label','-')} | {e.get('agent_name','-')} | {e.get('title','-')} | "
            f"{e.get('created_time_utc','-')} | {e.get('modified_time_utc','-')} | {e.get('drive_url','-')} |"
        )

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(lines).strip() + "\n", encoding="utf-8")
    print(f"wrote={out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
