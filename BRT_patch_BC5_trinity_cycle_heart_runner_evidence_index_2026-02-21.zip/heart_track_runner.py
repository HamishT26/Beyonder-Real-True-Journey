"""
heart_track_runner.py
---------------------

Standardized Heart-track runner for Freed ID governance verification.

Runs:
- freed_id_control_verifier.py (GOV-005)
- freed_id_minimum_disclosure_verifier.py (GOV-002)

Writes:
- docs/heart-track-runs/<stamp>-heart-track-smoke.{json,md}
- docs/heart-track-smoke-latest.{json,md}
- docs/heart-track-metrics-latest.json
- docs/heart-track-metrics-history.jsonl

Status semantics:
- PASS: all required verifiers pass
- FAIL: any required verifier fails
- WARN: verifier script missing or outputs missing (non-fatal)
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional


@dataclass
class Step:
    name: str
    command: List[str]
    returncode: int
    duration_seconds: float
    stdout: str
    stderr: str
    status: str
    latest_json: Optional[str] = None
    latest_md: Optional[str] = None


def _run(cmd: List[str]) -> tuple[int, float, str, str]:
    started = time.perf_counter()
    p = subprocess.run(cmd, capture_output=True, text=True, check=False)
    dur = time.perf_counter() - started
    return p.returncode, dur, (p.stdout or "").strip(), (p.stderr or "").strip()


def _trim(text: str, max_lines: int = 30) -> str:
    if not text:
        return "(empty)"
    lines = text.splitlines()
    if len(lines) <= max_lines:
        return "\n".join(lines)
    return "\n".join(lines[:max_lines] + [f"... ({len(lines) - max_lines} more lines)"])


def _md(generated_utc: str, overall_status: str, summary: Dict[str, object], steps: List[Step]) -> str:
    lines = [
        "# Heart Track Smoke Report",
        "",
        f"- generated_utc: `{generated_utc}`",
        f"- overall_status: **{overall_status}**",
        "",
        "## Summary",
        f"- total_steps: `{summary['total_steps']}`",
        f"- passed_steps: `{summary['passed_steps']}`",
        f"- failed_steps: `{summary['failed_steps']}`",
        f"- warned_steps: `{summary['warned_steps']}`",
        f"- heart_health_score: `{summary['heart_health_score']}`",
        "",
        "## Steps",
        "| step | status | returncode | duration_seconds | command |",
        "|---|---|---:|---:|---|",
    ]
    for s in steps:
        lines.append(f"| {s.name} | {s.status} | {s.returncode} | {s.duration_seconds:.3f} | `{' '.join(s.command)}` |")

    for s in steps:
        lines += [
            "",
            f"## {s.name}",
            "",
            f"- status: **{s.status}**",
            f"- returncode: `{s.returncode}`",
            "",
            "### stdout (trimmed)",
            "```",
            _trim(s.stdout),
            "```",
            "",
            "### stderr (trimmed)",
            "```",
            _trim(s.stderr),
            "```",
        ]
    return "\n".join(lines).strip() + "\n"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--reports-dir", default="docs/heart-track-runs")
    ap.add_argument("--latest-json", default="docs/heart-track-smoke-latest.json")
    ap.add_argument("--latest-md", default="docs/heart-track-smoke-latest.md")
    ap.add_argument("--latest-metrics", default="docs/heart-track-metrics-latest.json")
    ap.add_argument("--metrics-history", default="docs/heart-track-metrics-history.jsonl")
    args = ap.parse_args()

    root = Path(".")
    reports_dir = root / args.reports_dir
    reports_dir.mkdir(parents=True, exist_ok=True)

    generated_utc = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    def step_for(script: str, name: str) -> Step:
        sp = root / script
        if not sp.exists():
            return Step(
                name=name,
                command=[sys.executable, script],
                returncode=0,
                duration_seconds=0.0,
                stdout="SKIP: script missing",
                stderr="",
                status="WARN",
            )
        cmd = [sys.executable, script]
        rc, dur, out, err = _run(cmd)
        status = "PASS" if rc == 0 else "FAIL"
        return Step(name=name, command=cmd, returncode=rc, duration_seconds=dur, stdout=out, stderr=err, status=status)

    steps = [
        step_for("freed_id_control_verifier.py", "GOV-005_control_verifier"),
        step_for("freed_id_minimum_disclosure_verifier.py", "GOV-002_min_disclosure_verifier"),
    ]

    total = len(steps)
    passed = sum(1 for s in steps if s.status == "PASS")
    failed = sum(1 for s in steps if s.status == "FAIL")
    warned = sum(1 for s in steps if s.status == "WARN")
    # health score: 100 if all pass, else scaled down. WARN counts as half-credit.
    heart_health_score = round(((passed + 0.5 * warned) / total) * 100.0, 2) if total else 0.0

    if failed > 0:
        overall_status = "FAIL"
    elif warned > 0:
        overall_status = "WARN"
    else:
        overall_status = "PASS"

    summary = {
        "total_steps": total,
        "passed_steps": passed,
        "failed_steps": failed,
        "warned_steps": warned,
        "heart_health_score": heart_health_score,
    }

    payload = {
        "generated_utc": generated_utc,
        "overall_status": overall_status,
        "summary": summary,
        "steps": [asdict(s) for s in steps],
    }

    timestamped_json = reports_dir / f"{stamp}-heart-track-smoke.json"
    timestamped_md = reports_dir / f"{stamp}-heart-track-smoke.md"
    latest_json = root / args.latest_json
    latest_md = root / args.latest_md
    latest_metrics = root / args.latest_metrics
    metrics_history = root / args.metrics_history

    latest_json.parent.mkdir(parents=True, exist_ok=True)
    latest_md.parent.mkdir(parents=True, exist_ok=True)
    latest_metrics.parent.mkdir(parents=True, exist_ok=True)
    metrics_history.parent.mkdir(parents=True, exist_ok=True)

    timestamped_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    timestamped_md.write_text(_md(generated_utc, overall_status, summary, steps), encoding="utf-8")
    latest_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    latest_md.write_text(_md(generated_utc, overall_status, summary, steps), encoding="utf-8")
    latest_metrics.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    with metrics_history.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps({"generated_utc": generated_utc, **summary}) + "\n")

    print(f"overall_status={overall_status}")
    print(f"timestamped_json={timestamped_json}")
    print(f"timestamped_md={timestamped_md}")
    return 0 if overall_status in ("PASS", "WARN") else 1


if __name__ == "__main__":
    raise SystemExit(main())
