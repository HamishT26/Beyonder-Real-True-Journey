# Trinity Artifact Contract v1

generated: `2026-02-21T05:13:05Z`

This document defines the minimal contract for the **Trinity runner** artifact outputs so that automation, trend tracking, and evidence linkage stay stable even as implementations evolve.

## Required outputs

### Trinity (unified)
- `docs/trinity-latest.json`
- `docs/trinity-latest.md`
- `docs/trinity-history.jsonl` (append-only)

**trinity-latest.json (minimum fields)**
```json
{
  "generated_utc": "ISO-8601 UTC string",
  "overall_status": "PASS|WARN|FAIL",
  "lanes": [
    {
      "lane": "Body|Mind|Heart",
      "status": "PASS|WARN|FAIL|SKIP",
      "returncode": 0,
      "duration_seconds": 0.0,
      "latest_json": "path-or-null",
      "latest_md": "path-or-null"
    }
  ]
}
```

### Body
- `docs/body-track-smoke-latest.json`
- `docs/body-track-smoke-latest.md`
- `docs/body-track-metrics-history.jsonl` (append-only)

### Mind
- `docs/mind-track-smoke-latest.json`
- `docs/mind-track-smoke-latest.md`
- `docs/mind-track-metrics-history.jsonl` (append-only)

### Heart
- `docs/heart-track-smoke-latest.json`
- `docs/heart-track-smoke-latest.md`
- `docs/heart-track-metrics-history.jsonl` (append-only)

## Run registry (optional but recommended)
- `docs/run-registry.jsonl` (append-only) — compact human-friendly record.

## Index pages
- `docs/TRINITY_INDEX.md` — table of last N runs.

## Evidence linkage hooks (C)
If available, attach:
- `docs/evidence-links-latest.json` (mapping claim/control → artifact path → external link/hash)
