# Evidence Index v0

generated: `2026-02-21T05:13:05Z`

This page is the *human entry point* for evidence.

## Primary registries
- `docs/journey_pdf_registry_v0.json` — Drive PDF registry
- `docs/claim_to_pdf_links_v0.md` — claim/control → PDF anchoring
- `docs/run-registry.jsonl` — run events
- `docs/TRINITY_INDEX.md` — run table

## How to add a new evidence anchor (fast)
1. Add the PDF to the Drive folder (or reference its Drive ID).
2. Add an entry to `docs/journey_pdf_registry_v0.json`.
3. Add a claim link row to `docs/claim_to_pdf_links_v0.md`.
4. Run `python scripts/run_trinity_cycle.py --profile standard`
5. Commit the updated `docs/` artifacts and (optionally) upload the patch zip to Drive.

## What counts as evidence
- Reproducible runner outputs (json + md)
- Append-only histories (jsonl)
- External references (PDF page/section + file ID)
