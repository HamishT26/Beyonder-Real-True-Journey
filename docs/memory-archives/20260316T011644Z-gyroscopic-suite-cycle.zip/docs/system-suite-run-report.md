# Trinity System Suite Run Report

Generated: 2026-03-16T00:53:55.065597+00:00
Step timeout (s): disabled
Profile: recover
Profile source: --profile
Include version scan: False
Include skill install: False
Include curated skill catalog: False
Include public api refresh: False
Include mcp refresh: False
Include staged connectors: False
Include live writes: False
Materialization level desired: l2_persistent_dev
Offline only: False
Live network mode: offline_default
MCP refresh mode: disabled
Staged connector mode: staged_only
Active materialization mode: read_only
Soft-fail network: False
Fail on warn: True
Achievement target steps: disabled
Quick mode: False
Body benchmark mode: off
Status JSON path: docs\system-suite-status.json

This report runs currently available repo systems and records command outputs.

## trinity extension catalog validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_extension_catalog_validator.py --fail-on-warn`
- started: `2026-03-16T00:53:55.065597+00:00`
- finished: `2026-03-16T00:53:56.961864+00:00`
- duration_sec: `1.907`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-extension-catalog-validation-latest.json
latest_md=docs\trinity-extension-catalog-validation-latest.md
```

## trinity command book validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_command_book_validator.py --fail-on-warn`
- started: `2026-03-16T00:53:56.962860+00:00`
- finished: `2026-03-16T00:54:00.644003+00:00`
- duration_sec: `3.671`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-command-book-validation-latest.json
latest_md=docs\trinity-command-book-validation-latest.md
```

## trinity api book validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_api_book_validator.py --fail-on-warn`
- started: `2026-03-16T00:54:00.645007+00:00`
- finished: `2026-03-16T00:54:01.871821+00:00`
- duration_sec: `1.235`
```text

```

## trinity agent council validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_agent_council_v10_validator.py --fail-on-warn`
- started: `2026-03-16T00:54:01.871821+00:00`
- finished: `2026-03-16T00:54:03.150156+00:00`
- duration_sec: `1.281`
```text
overall_status=PASS
effective_success=True
latest_json=docs/trinity-agent-council-validation-latest.json
latest_md=docs/trinity-agent-council-validation-latest.md
```

## trinity materialization ladder validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_materialization_ladder_validator.py --fail-on-warn`
- started: `2026-03-16T00:54:03.150156+00:00`
- finished: `2026-03-16T00:54:03.603671+00:00`
- duration_sec: `0.453`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-materialization-ladder-validation-latest.json
latest_md=docs\trinity-materialization-ladder-validation-latest.md
```

## trinity expansion manifest validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_manifest_validator.py --fail-on-warn`
- started: `2026-03-16T00:54:03.603671+00:00`
- finished: `2026-03-16T00:54:11.519410+00:00`
- duration_sec: `7.906`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion-manifest-validation-latest.json
latest_md=docs\trinity-expansion-manifest-validation-latest.md
```

## trinity memory bank validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_memory_bank_validator.py --fail-on-warn`
- started: `2026-03-16T00:54:11.519410+00:00`
- finished: `2026-03-16T00:54:11.974195+00:00`
- duration_sec: `0.469`
```text

```

## trinity storage prune dry-run
- status: **PASS**
- command: `python3 scripts/trinity_storage_retention.py --keep-stamps 2 --keep-archives 3 --dry-run`
- started: `2026-03-16T00:54:11.974195+00:00`
- finished: `2026-03-16T00:54:30.297893+00:00`
- duration_sec: `18.313`
```text
deleted_files=15091
reclaimed_mb=25.48
free_gib_delta=0.0
```

## trinity api manifest validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_api_source_manifest_validator.py --fail-on-warn`
- started: `2026-03-16T00:54:30.298572+00:00`
- finished: `2026-03-16T00:54:31.644041+00:00`
- duration_sec: `1.343`
```text
overall_status=PASS
api_count=7
```

## trinity public research validation (enforce)
- status: **PASS**
- command: `python3 scripts/validate_trinity_public_research.py --fail-on-warn`
- started: `2026-03-16T00:54:31.644805+00:00`
- finished: `2026-03-16T00:54:32.245059+00:00`
- duration_sec: `0.610`
```text
overall_status=PASS
timestamped_json=docs\trinity-public-research-runs\20260316T005431Z-trinity-public-research-validation.json
timestamped_md=docs\trinity-public-research-runs\20260316T005431Z-trinity-public-research-validation.md
latest_json=docs\trinity-public-research-validation-latest.json
latest_md=docs\trinity-public-research-validation-latest.md
```

## trinity public signal board (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_public_signal_board.py --fail-on-warn`
- started: `2026-03-16T00:54:32.245059+00:00`
- finished: `2026-03-16T00:54:33.118453+00:00`
- duration_sec: `0.875`
```text
overall_status=PASS
timestamped_json=docs\trinity-public-signal-runs\20260316T005432Z-trinity-public-signal-board.json
timestamped_md=docs\trinity-public-signal-runs\20260316T005432Z-trinity-public-signal-board.md
latest_json=docs\trinity-public-signal-board-latest.json
latest_md=docs\trinity-public-signal-board-latest.md
```

## gmut canon validation (enforce)
- status: **PASS**
- command: `python3 scripts/grand_mandala_canon_validator.py --fail-on-warn`
- started: `2026-03-16T00:54:33.119007+00:00`
- finished: `2026-03-16T00:54:33.439475+00:00`
- duration_sec: `0.312`
```text
gmut_canon_validation=PASS
```

## legacy reconstruction validation (enforce)
- status: **PASS**
- command: `python3 scripts/legacy_reconstruction_validator.py --fail-on-warn`
- started: `2026-03-16T00:54:33.439475+00:00`
- finished: `2026-03-16T00:54:33.715640+00:00`
- duration_sec: `0.282`
```text
legacy_reconstruction_validation=PASS
```

## expansion: canonical_gmut_latex_v13_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id canonical_gmut_latex_v13_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:54:33.715640+00:00`
- finished: `2026-03-16T00:54:35.573855+00:00`
- duration_sec: `1.859`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\canonical-gmut-latex-v13-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T005435Z-canonical-gmut-latex-v13-surface-audit.json
latest_md=docs\trinity-expansion\canonical-gmut-latex-v13-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T005435Z-canonical-gmut-latex-v13-surface-audit.md
```

## expansion: canonical_gmut_latex_v13_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id canonical_gmut_latex_v13_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:54:35.574466+00:00`
- finished: `2026-03-16T00:54:36.686372+00:00`
- duration_sec: `1.109`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\canonical-gmut-latex-v13-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T005436Z-canonical-gmut-latex-v13-gate.json
latest_md=docs\trinity-expansion\canonical-gmut-latex-v13-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T005436Z-canonical-gmut-latex-v13-gate.md
```

## expansion: mind_falsification_matrix_v13_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id mind_falsification_matrix_v13_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:54:36.686372+00:00`
- finished: `2026-03-16T00:54:37.733429+00:00`
- duration_sec: `1.047`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\mind-falsification-matrix-v13-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T005437Z-mind-falsification-matrix-v13-surface-audit.json
latest_md=docs\trinity-expansion\mind-falsification-matrix-v13-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T005437Z-mind-falsification-matrix-v13-surface-audit.md
```

## expansion: mind_falsification_matrix_v13_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id mind_falsification_matrix_v13_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:54:37.733429+00:00`
- finished: `2026-03-16T00:54:38.743029+00:00`
- duration_sec: `1.016`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\mind-falsification-matrix-v13-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T005438Z-mind-falsification-matrix-v13-gate.json
latest_md=docs\trinity-expansion\mind-falsification-matrix-v13-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T005438Z-mind-falsification-matrix-v13-gate.md
```

## expansion: public_source_refresh_v13_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id public_source_refresh_v13_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:54:38.743029+00:00`
- finished: `2026-03-16T00:54:39.744651+00:00`
- duration_sec: `1.000`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\public-source-refresh-v13-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T005439Z-public-source-refresh-v13-surface-audit.json
latest_md=docs\trinity-expansion\public-source-refresh-v13-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T005439Z-public-source-refresh-v13-surface-audit.md
```

## expansion: public_source_refresh_v13_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id public_source_refresh_v13_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:54:39.747677+00:00`
- finished: `2026-03-16T00:54:40.758791+00:00`
- duration_sec: `1.015`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\public-source-refresh-v13-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T005440Z-public-source-refresh-v13-gate.json
latest_md=docs\trinity-expansion\public-source-refresh-v13-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T005440Z-public-source-refresh-v13-gate.md
```

## expansion: heart_governance_alignment_v13_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id heart_governance_alignment_v13_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:54:40.758791+00:00`
- finished: `2026-03-16T00:54:41.794981+00:00`
- duration_sec: `1.032`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\heart-governance-alignment-v13-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T005441Z-heart-governance-alignment-v13-surface-audit.json
latest_md=docs\trinity-expansion\heart-governance-alignment-v13-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T005441Z-heart-governance-alignment-v13-surface-audit.md
```

## expansion: heart_governance_alignment_v13_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id heart_governance_alignment_v13_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:54:41.794981+00:00`
- finished: `2026-03-16T00:54:42.775226+00:00`
- duration_sec: `0.984`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\heart-governance-alignment-v13-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T005442Z-heart-governance-alignment-v13-gate.json
latest_md=docs\trinity-expansion\heart-governance-alignment-v13-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T005442Z-heart-governance-alignment-v13-gate.md
```

## expansion: supplemental_reflection_bridge_v13_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id supplemental_reflection_bridge_v13_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:54:42.775226+00:00`
- finished: `2026-03-16T00:54:43.776378+00:00`
- duration_sec: `1.000`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\supplemental-reflection-bridge-v13-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T005443Z-supplemental-reflection-bridge-v13-surface-audit.json
latest_md=docs\trinity-expansion\supplemental-reflection-bridge-v13-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T005443Z-supplemental-reflection-bridge-v13-surface-audit.md
```

## expansion: supplemental_reflection_bridge_v13_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id supplemental_reflection_bridge_v13_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:54:43.777406+00:00`
- finished: `2026-03-16T00:54:47.262740+00:00`
- duration_sec: `3.484`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\supplemental-reflection-bridge-v13-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T005446Z-supplemental-reflection-bridge-v13-gate.json
latest_md=docs\trinity-expansion\supplemental-reflection-bridge-v13-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T005446Z-supplemental-reflection-bridge-v13-gate.md
```

## expansion: legacy_module_inventory_v13_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id legacy_module_inventory_v13_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:54:47.262740+00:00`
- finished: `2026-03-16T00:54:48.559704+00:00`
- duration_sec: `1.297`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\legacy-module-inventory-v13-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T005448Z-legacy-module-inventory-v13-surface-audit.json
latest_md=docs\trinity-expansion\legacy-module-inventory-v13-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T005448Z-legacy-module-inventory-v13-surface-audit.md
```

## expansion: legacy_module_inventory_v13_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id legacy_module_inventory_v13_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:54:48.560722+00:00`
- finished: `2026-03-16T00:54:50.783813+00:00`
- duration_sec: `2.219`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\legacy-module-inventory-v13-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T005450Z-legacy-module-inventory-v13-gate.json
latest_md=docs\trinity-expansion\legacy-module-inventory-v13-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T005450Z-legacy-module-inventory-v13-gate.md
```

## expansion: kairotic_body_reconstruction_v13_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id kairotic_body_reconstruction_v13_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:54:50.783813+00:00`
- finished: `2026-03-16T00:54:52.551534+00:00`
- duration_sec: `1.766`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\kairotic-body-reconstruction-v13-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T005452Z-kairotic-body-reconstruction-v13-surface-audit.json
latest_md=docs\trinity-expansion\kairotic-body-reconstruction-v13-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T005452Z-kairotic-body-reconstruction-v13-surface-audit.md
```

## expansion: kairotic_body_reconstruction_v13_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id kairotic_body_reconstruction_v13_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:54:52.552534+00:00`
- finished: `2026-03-16T00:54:53.859197+00:00`
- duration_sec: `1.312`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\kairotic-body-reconstruction-v13-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T005453Z-kairotic-body-reconstruction-v13-gate.json
latest_md=docs\trinity-expansion\kairotic-body-reconstruction-v13-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T005453Z-kairotic-body-reconstruction-v13-gate.md
```

## expansion: api_surface_book_v13_sync_bridge (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id api_surface_book_v13_sync_bridge --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:54:53.859197+00:00`
- finished: `2026-03-16T00:54:55.784037+00:00`
- duration_sec: `1.922`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\api-surface-book-v13-sync-bridge-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T005455Z-api-surface-book-v13-sync-bridge.json
latest_md=docs\trinity-expansion\api-surface-book-v13-sync-bridge-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T005455Z-api-surface-book-v13-sync-bridge.md
```

## expansion: api_surface_book_v13_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id api_surface_book_v13_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:54:55.784037+00:00`
- finished: `2026-03-16T00:54:56.957482+00:00`
- duration_sec: `1.172`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\api-surface-book-v13-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T005456Z-api-surface-book-v13-surface-audit.json
latest_md=docs\trinity-expansion\api-surface-book-v13-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T005456Z-api-surface-book-v13-surface-audit.md
```

## expansion: api_surface_book_v13_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id api_surface_book_v13_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:54:56.957482+00:00`
- finished: `2026-03-16T00:54:58.485256+00:00`
- duration_sec: `1.531`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\api-surface-book-v13-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T005458Z-api-surface-book-v13-gate.json
latest_md=docs\trinity-expansion\api-surface-book-v13-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T005458Z-api-surface-book-v13-gate.md
```

## expansion: trinity_control_tower_v13_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v13_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:54:58.485256+00:00`
- finished: `2026-03-16T00:54:59.521150+00:00`
- duration_sec: `1.031`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\trinity-control-tower-v13-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T005459Z-trinity-control-tower-v13-surface-audit.json
latest_md=docs\trinity-expansion\trinity-control-tower-v13-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T005459Z-trinity-control-tower-v13-surface-audit.md
```

## expansion: trinity_control_tower_v13_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v13_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:54:59.521150+00:00`
- finished: `2026-03-16T00:55:00.650214+00:00`
- duration_sec: `1.141`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\trinity-control-tower-v13-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T005500Z-trinity-control-tower-v13-gate.json
latest_md=docs\trinity-expansion\trinity-control-tower-v13-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T005500Z-trinity-control-tower-v13-gate.md
```

## trinity mandala scoreboard
- status: **PASS**
- command: `python3 scripts/trinity_mandala_scoreboard.py --fail-on-warn --suite-status docs/system-suite-status.json`
- started: `2026-03-16T00:55:01.006660+00:00`
- finished: `2026-03-16T00:55:03.940755+00:00`
- duration_sec: `2.922`
```text
hybrid_os_status=PASS
timestamped_json=docs\trinity-mandala-runs\20260316T005501Z-trinity-mandala-scoreboard.json
timestamped_md=docs\trinity-mandala-runs\20260316T005501Z-trinity-mandala-scoreboard.md
latest_json=docs\trinity-mandala-scoreboard-latest.json
latest_md=docs\trinity-mandala-scoreboard-latest.md
```

## Overall status
- Effective success: **True**
- PASS: **33**
- WARN: **0**
- TIMEOUT: **0**
- FAIL: **0**
- Expansion systems total: **19**
- Expansion systems passed: **19**
- Collab pack count: **121**
- Materialization pack count: **16**
- Materialization level desired: **l2_persistent_dev**
- Materialization level actual: **readiness_only**
- Persistent target count: **4**
- Command surface state: **PASS**
- Council state: **PASS**
- Provisional agent count: **0**
- Group chat state: **PASS**
- Duo chat count: **15**
- Identity authority state: **PASS**
- Memory mirror state: **PASS**
- Late-step autonomy state: **PASS**
- Eligible live write connectors: **filesystem, github, linear, notion, postgres**
- Promoted live write connectors: **github, linear, notion, postgres**
- Blocked promotions: **filesystem**
- Achieved steps: **33**
- Achievement gate met: **True**
- Suite started: `2026-03-16T00:53:55.065597+00:00`
- Suite finished: `2026-03-16T00:55:03.943133+00:00`
- Suite duration_sec: `68.891`

## Machine-readable summary
```json
{
  "generated_utc": "2026-03-16T00:55:22.759152+00:00",
  "suite_started_at_utc": "2026-03-16T00:53:55.065597+00:00",
  "suite_finished_at_utc": "2026-03-16T00:55:03.943133+00:00",
  "suite_duration_sec": 68.891,
  "effective_success": true,
  "achieved_steps": 33,
  "achievement_gate_met": true,
  "counts": {
    "pass": 33,
    "warn": 0,
    "timeout": 0,
    "fail": 0
  },
  "expansion_systems_total": 19,
  "expansion_systems_passed": 19,
  "collab_pack_count": 121,
  "materialization_pack_count": 16,
  "verified_mcp_connectors": [
    "figma",
    "github",
    "linear",
    "notion",
    "postgres"
  ],
  "eligible_live_write_connectors": [
    "filesystem",
    "github",
    "linear",
    "notion",
    "postgres"
  ],
  "promoted_live_write_connectors": [
    "github",
    "linear",
    "notion",
    "postgres"
  ],
  "blocked_promotions": [
    "filesystem"
  ],
  "active_materialization_mode": "read_only",
  "mcp_refresh_mode": "disabled",
  "staged_connector_mode": "staged_only",
  "current_session_surface": {
    "git_remote_live": true,
    "docker_cli": true,
    "docker_container_running": true,
    "postgres_ready": true,
    "gh_available": false,
    "node_available": false,
    "npx_available": false
  },
  "connector_hardening_state": "PASS",
  "autonomy_mode": "bounded_manual",
  "knowledge_graph_state": "PASS",
  "dashboard_state": "PASS",
  "future_readiness_state": "PASS",
  "materialization_level_desired": "l2_persistent_dev",
  "materialization_level_actual": "readiness_only",
  "persistent_target_count": 4,
  "command_surface_state": "PASS",
  "council_state": "PASS",
  "provisional_agent_count": 0,
  "group_chat_state": "PASS",
  "duo_chat_count": 15,
  "identity_authority_state": "PASS",
  "memory_mirror_state": "PASS",
  "late_step_autonomy_state": "PASS",
  "recovery_parent_run": "",
  "recovery_mode": "recover_profile",
  "dirty_tree_state": {
    "available": true,
    "staged_count": 0,
    "unstaged_count": 1780,
    "untracked_count": 2327,
    "dirty": true
  },
  "storage_prune_delta_mb": 25.48,
  "resumed_step_count": 0,
  "config": {
    "step_timeout_sec": 0,
    "profile": "recover",
    "profile_source": "--profile",
    "include_version_scan": false,
    "include_skill_install": false,
    "include_curated_skill_catalog": false,
    "include_public_api_refresh": false,
    "include_mcp_refresh": false,
    "include_staged_connectors": false,
    "include_live_writes": false,
    "offline_only": false,
    "live_network_mode": "offline_default",
    "mcp_refresh_mode": "disabled",
    "staged_connector_mode": "staged_only",
    "active_materialization_mode": "read_only",
    "materialization_level": "l2_persistent_dev",
    "soft_fail_network": false,
    "fail_on_warn": true,
    "achievement_target_steps": 0,
    "quick_mode": false,
    "body_benchmark_mode": "off",
    "include_body_benchmark": false,
    "resume_failed_only": false,
    "resume_from_status": ""
  },
  "results": [
    {
      "label": "trinity extension catalog validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:53:55.065597+00:00",
      "finished_at_utc": "2026-03-16T00:53:56.961864+00:00",
      "duration_sec": 1.907,
      "command": "python3 scripts/trinity_extension_catalog_validator.py --fail-on-warn"
    },
    {
      "label": "trinity command book validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:53:56.962860+00:00",
      "finished_at_utc": "2026-03-16T00:54:00.644003+00:00",
      "duration_sec": 3.671,
      "command": "python3 scripts/trinity_command_book_validator.py --fail-on-warn"
    },
    {
      "label": "trinity api book validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:00.645007+00:00",
      "finished_at_utc": "2026-03-16T00:54:01.871821+00:00",
      "duration_sec": 1.235,
      "command": "python3 scripts/trinity_api_book_validator.py --fail-on-warn"
    },
    {
      "label": "trinity agent council validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:01.871821+00:00",
      "finished_at_utc": "2026-03-16T00:54:03.150156+00:00",
      "duration_sec": 1.281,
      "command": "python3 scripts/trinity_agent_council_v10_validator.py --fail-on-warn"
    },
    {
      "label": "trinity materialization ladder validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:03.150156+00:00",
      "finished_at_utc": "2026-03-16T00:54:03.603671+00:00",
      "duration_sec": 0.453,
      "command": "python3 scripts/trinity_materialization_ladder_validator.py --fail-on-warn"
    },
    {
      "label": "trinity expansion manifest validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:03.603671+00:00",
      "finished_at_utc": "2026-03-16T00:54:11.519410+00:00",
      "duration_sec": 7.906,
      "command": "python3 scripts/trinity_expansion_manifest_validator.py --fail-on-warn"
    },
    {
      "label": "trinity memory bank validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:11.519410+00:00",
      "finished_at_utc": "2026-03-16T00:54:11.974195+00:00",
      "duration_sec": 0.469,
      "command": "python3 scripts/trinity_memory_bank_validator.py --fail-on-warn"
    },
    {
      "label": "trinity storage prune dry-run",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:11.974195+00:00",
      "finished_at_utc": "2026-03-16T00:54:30.297893+00:00",
      "duration_sec": 18.313,
      "command": "python3 scripts/trinity_storage_retention.py --keep-stamps 2 --keep-archives 3 --dry-run"
    },
    {
      "label": "trinity api manifest validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:30.298572+00:00",
      "finished_at_utc": "2026-03-16T00:54:31.644041+00:00",
      "duration_sec": 1.343,
      "command": "python3 scripts/trinity_api_source_manifest_validator.py --fail-on-warn"
    },
    {
      "label": "trinity public research validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:31.644805+00:00",
      "finished_at_utc": "2026-03-16T00:54:32.245059+00:00",
      "duration_sec": 0.61,
      "command": "python3 scripts/validate_trinity_public_research.py --fail-on-warn"
    },
    {
      "label": "trinity public signal board (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:32.245059+00:00",
      "finished_at_utc": "2026-03-16T00:54:33.118453+00:00",
      "duration_sec": 0.875,
      "command": "python3 scripts/trinity_public_signal_board.py --fail-on-warn"
    },
    {
      "label": "gmut canon validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:33.119007+00:00",
      "finished_at_utc": "2026-03-16T00:54:33.439475+00:00",
      "duration_sec": 0.312,
      "command": "python3 scripts/grand_mandala_canon_validator.py --fail-on-warn"
    },
    {
      "label": "legacy reconstruction validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:33.439475+00:00",
      "finished_at_utc": "2026-03-16T00:54:33.715640+00:00",
      "duration_sec": 0.282,
      "command": "python3 scripts/legacy_reconstruction_validator.py --fail-on-warn"
    },
    {
      "label": "expansion: canonical_gmut_latex_v13_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:33.715640+00:00",
      "finished_at_utc": "2026-03-16T00:54:35.573855+00:00",
      "duration_sec": 1.859,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id canonical_gmut_latex_v13_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: canonical_gmut_latex_v13_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:35.574466+00:00",
      "finished_at_utc": "2026-03-16T00:54:36.686372+00:00",
      "duration_sec": 1.109,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id canonical_gmut_latex_v13_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: mind_falsification_matrix_v13_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:36.686372+00:00",
      "finished_at_utc": "2026-03-16T00:54:37.733429+00:00",
      "duration_sec": 1.047,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id mind_falsification_matrix_v13_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: mind_falsification_matrix_v13_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:37.733429+00:00",
      "finished_at_utc": "2026-03-16T00:54:38.743029+00:00",
      "duration_sec": 1.016,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id mind_falsification_matrix_v13_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: public_source_refresh_v13_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:38.743029+00:00",
      "finished_at_utc": "2026-03-16T00:54:39.744651+00:00",
      "duration_sec": 1.0,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id public_source_refresh_v13_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: public_source_refresh_v13_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:39.747677+00:00",
      "finished_at_utc": "2026-03-16T00:54:40.758791+00:00",
      "duration_sec": 1.015,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id public_source_refresh_v13_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: heart_governance_alignment_v13_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:40.758791+00:00",
      "finished_at_utc": "2026-03-16T00:54:41.794981+00:00",
      "duration_sec": 1.032,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id heart_governance_alignment_v13_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: heart_governance_alignment_v13_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:41.794981+00:00",
      "finished_at_utc": "2026-03-16T00:54:42.775226+00:00",
      "duration_sec": 0.984,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id heart_governance_alignment_v13_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: supplemental_reflection_bridge_v13_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:42.775226+00:00",
      "finished_at_utc": "2026-03-16T00:54:43.776378+00:00",
      "duration_sec": 1.0,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id supplemental_reflection_bridge_v13_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: supplemental_reflection_bridge_v13_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:43.777406+00:00",
      "finished_at_utc": "2026-03-16T00:54:47.262740+00:00",
      "duration_sec": 3.484,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id supplemental_reflection_bridge_v13_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: legacy_module_inventory_v13_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:47.262740+00:00",
      "finished_at_utc": "2026-03-16T00:54:48.559704+00:00",
      "duration_sec": 1.297,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id legacy_module_inventory_v13_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: legacy_module_inventory_v13_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:48.560722+00:00",
      "finished_at_utc": "2026-03-16T00:54:50.783813+00:00",
      "duration_sec": 2.219,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id legacy_module_inventory_v13_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: kairotic_body_reconstruction_v13_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:50.783813+00:00",
      "finished_at_utc": "2026-03-16T00:54:52.551534+00:00",
      "duration_sec": 1.766,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id kairotic_body_reconstruction_v13_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: kairotic_body_reconstruction_v13_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:52.552534+00:00",
      "finished_at_utc": "2026-03-16T00:54:53.859197+00:00",
      "duration_sec": 1.312,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id kairotic_body_reconstruction_v13_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: api_surface_book_v13_sync_bridge (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:53.859197+00:00",
      "finished_at_utc": "2026-03-16T00:54:55.784037+00:00",
      "duration_sec": 1.922,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id api_surface_book_v13_sync_bridge --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: api_surface_book_v13_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:55.784037+00:00",
      "finished_at_utc": "2026-03-16T00:54:56.957482+00:00",
      "duration_sec": 1.172,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id api_surface_book_v13_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: api_surface_book_v13_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:56.957482+00:00",
      "finished_at_utc": "2026-03-16T00:54:58.485256+00:00",
      "duration_sec": 1.531,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id api_surface_book_v13_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: trinity_control_tower_v13_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:58.485256+00:00",
      "finished_at_utc": "2026-03-16T00:54:59.521150+00:00",
      "duration_sec": 1.031,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v13_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: trinity_control_tower_v13_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:54:59.521150+00:00",
      "finished_at_utc": "2026-03-16T00:55:00.650214+00:00",
      "duration_sec": 1.141,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v13_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "trinity mandala scoreboard",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:55:01.006660+00:00",
      "finished_at_utc": "2026-03-16T00:55:03.940755+00:00",
      "duration_sec": 2.922,
      "command": "python3 scripts/trinity_mandala_scoreboard.py --fail-on-warn --suite-status docs/system-suite-status.json"
    }
  ]
}
```

