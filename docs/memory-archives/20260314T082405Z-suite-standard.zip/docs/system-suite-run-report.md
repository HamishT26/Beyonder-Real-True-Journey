# Trinity System Suite Run Report

Generated: 2026-03-14T07:51:46.391514+00:00
Step timeout (s): disabled
Profile: recover
Profile source: --profile
Include version scan: False
Include skill install: False
Include curated skill catalog: False
Include public api refresh: False
Include mcp refresh: False
Include staged connectors: False
Include live writes: False
Materialization level desired: l2_persistent_dev
Offline only: False
Live network mode: offline_default
MCP refresh mode: disabled
Staged connector mode: staged_only
Active materialization mode: read_only
Soft-fail network: False
Fail on warn: True
Achievement target steps: disabled
Quick mode: False
Body benchmark mode: off
Status JSON path: docs\system-suite-status.json

This report runs currently available repo systems and records command outputs.

## trinity extension catalog validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_extension_catalog_validator.py --fail-on-warn`
- started: `2026-03-14T07:51:46.392166+00:00`
- finished: `2026-03-14T07:51:47.139487+00:00`
- duration_sec: `0.750`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-extension-catalog-validation-latest.json
latest_md=docs\trinity-extension-catalog-validation-latest.md
```

## trinity command book validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_command_book_validator.py --fail-on-warn`
- started: `2026-03-14T07:51:47.140482+00:00`
- finished: `2026-03-14T07:51:50.184669+00:00`
- duration_sec: `3.047`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-command-book-validation-latest.json
latest_md=docs\trinity-command-book-validation-latest.md
```

## trinity api book validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_api_book_validator.py --fail-on-warn`
- started: `2026-03-14T07:51:50.184669+00:00`
- finished: `2026-03-14T07:51:50.683283+00:00`
- duration_sec: `0.500`
```text

```

## trinity agent council validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_agent_council_v10_validator.py --fail-on-warn`
- started: `2026-03-14T07:51:50.683283+00:00`
- finished: `2026-03-14T07:51:51.475056+00:00`
- duration_sec: `0.782`
```text
overall_status=PASS
effective_success=True
latest_json=docs/trinity-agent-council-validation-latest.json
latest_md=docs/trinity-agent-council-validation-latest.md
```

## trinity materialization ladder validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_materialization_ladder_validator.py --fail-on-warn`
- started: `2026-03-14T07:51:51.475056+00:00`
- finished: `2026-03-14T07:51:53.268631+00:00`
- duration_sec: `1.796`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-materialization-ladder-validation-latest.json
latest_md=docs\trinity-materialization-ladder-validation-latest.md
```

## trinity expansion manifest validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_manifest_validator.py --fail-on-warn`
- started: `2026-03-14T07:51:53.268631+00:00`
- finished: `2026-03-14T07:51:57.775646+00:00`
- duration_sec: `4.516`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion-manifest-validation-latest.json
latest_md=docs\trinity-expansion-manifest-validation-latest.md
```

## trinity memory bank validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_memory_bank_validator.py --fail-on-warn`
- started: `2026-03-14T07:51:57.775646+00:00`
- finished: `2026-03-14T07:51:58.728955+00:00`
- duration_sec: `0.953`
```text

```

## trinity storage prune dry-run
- status: **PASS**
- command: `python3 scripts/trinity_storage_retention.py --keep-stamps 2 --keep-archives 3 --dry-run`
- started: `2026-03-14T07:51:58.728955+00:00`
- finished: `2026-03-14T07:51:59.393254+00:00`
- duration_sec: `0.656`
```text
deleted_files=55
reclaimed_mb=0.23
free_gib_delta=0.0
```

## trinity api manifest validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_api_source_manifest_validator.py --fail-on-warn`
- started: `2026-03-14T07:51:59.393254+00:00`
- finished: `2026-03-14T07:52:01.722523+00:00`
- duration_sec: `2.329`
```text
overall_status=PASS
api_count=7
```

## trinity public research validation (enforce)
- status: **PASS**
- command: `python3 scripts/validate_trinity_public_research.py --fail-on-warn`
- started: `2026-03-14T07:52:01.722523+00:00`
- finished: `2026-03-14T07:52:02.990130+00:00`
- duration_sec: `1.265`
```text
overall_status=PASS
timestamped_json=docs\trinity-public-research-runs\20260314T075202Z-trinity-public-research-validation.json
timestamped_md=docs\trinity-public-research-runs\20260314T075202Z-trinity-public-research-validation.md
latest_json=docs\trinity-public-research-validation-latest.json
latest_md=docs\trinity-public-research-validation-latest.md
```

## trinity public signal board (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_public_signal_board.py --fail-on-warn`
- started: `2026-03-14T07:52:02.990130+00:00`
- finished: `2026-03-14T07:52:03.983389+00:00`
- duration_sec: `1.000`
```text
overall_status=PASS
timestamped_json=docs\trinity-public-signal-runs\20260314T075203Z-trinity-public-signal-board.json
timestamped_md=docs\trinity-public-signal-runs\20260314T075203Z-trinity-public-signal-board.md
latest_json=docs\trinity-public-signal-board-latest.json
latest_md=docs\trinity-public-signal-board-latest.md
```

## expansion: storage_prune_governor_v12_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id storage_prune_governor_v12_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:03.984414+00:00`
- finished: `2026-03-14T07:52:06.569366+00:00`
- duration_sec: `2.578`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\storage-prune-governor-v12-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075206Z-storage-prune-governor-v12-surface-audit.json
latest_md=docs\trinity-expansion\storage-prune-governor-v12-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075206Z-storage-prune-governor-v12-surface-audit.md
```

## expansion: storage_prune_governor_v12_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id storage_prune_governor_v12_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:06.569366+00:00`
- finished: `2026-03-14T07:52:08.211654+00:00`
- duration_sec: `1.657`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\storage-prune-governor-v12-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075208Z-storage-prune-governor-v12-gate.json
latest_md=docs\trinity-expansion\storage-prune-governor-v12-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075208Z-storage-prune-governor-v12-gate.md
```

## expansion: artifact_retention_rebuild_v12_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id artifact_retention_rebuild_v12_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:08.215674+00:00`
- finished: `2026-03-14T07:52:10.488431+00:00`
- duration_sec: `2.265`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\artifact-retention-rebuild-v12-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075210Z-artifact-retention-rebuild-v12-surface-audit.json
latest_md=docs\trinity-expansion\artifact-retention-rebuild-v12-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075210Z-artifact-retention-rebuild-v12-surface-audit.md
```

## expansion: artifact_retention_rebuild_v12_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id artifact_retention_rebuild_v12_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:10.488431+00:00`
- finished: `2026-03-14T07:52:12.543238+00:00`
- duration_sec: `2.063`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\artifact-retention-rebuild-v12-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075212Z-artifact-retention-rebuild-v12-gate.json
latest_md=docs\trinity-expansion\artifact-retention-rebuild-v12-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075212Z-artifact-retention-rebuild-v12-gate.md
```

## expansion: docker_runtime_truth_v12_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id docker_runtime_truth_v12_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:12.543238+00:00`
- finished: `2026-03-14T07:52:19.254539+00:00`
- duration_sec: `6.703`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\docker-runtime-truth-v12-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075218Z-docker-runtime-truth-v12-surface-audit.json
latest_md=docs\trinity-expansion\docker-runtime-truth-v12-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075218Z-docker-runtime-truth-v12-surface-audit.md
```

## expansion: docker_runtime_truth_v12_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id docker_runtime_truth_v12_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:19.254539+00:00`
- finished: `2026-03-14T07:52:21.926989+00:00`
- duration_sec: `2.672`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\docker-runtime-truth-v12-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075221Z-docker-runtime-truth-v12-gate.json
latest_md=docs\trinity-expansion\docker-runtime-truth-v12-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075221Z-docker-runtime-truth-v12-gate.md
```

## expansion: google_drive_hold_guard_v12_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id google_drive_hold_guard_v12_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:21.926989+00:00`
- finished: `2026-03-14T07:52:23.304138+00:00`
- duration_sec: `1.375`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\google-drive-hold-guard-v12-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075223Z-google-drive-hold-guard-v12-surface-audit.json
latest_md=docs\trinity-expansion\google-drive-hold-guard-v12-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075223Z-google-drive-hold-guard-v12-surface-audit.md
```

## expansion: google_drive_hold_guard_v12_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id google_drive_hold_guard_v12_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:23.305682+00:00`
- finished: `2026-03-14T07:52:25.671937+00:00`
- duration_sec: `2.360`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\google-drive-hold-guard-v12-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075225Z-google-drive-hold-guard-v12-gate.json
latest_md=docs\trinity-expansion\google-drive-hold-guard-v12-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075225Z-google-drive-hold-guard-v12-gate.md
```

## expansion: council_continuity_wellbeing_v12_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id council_continuity_wellbeing_v12_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:25.673257+00:00`
- finished: `2026-03-14T07:52:28.688810+00:00`
- duration_sec: `3.015`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\council-continuity-wellbeing-v12-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075228Z-council-continuity-wellbeing-v12-surface-audit.json
latest_md=docs\trinity-expansion\council-continuity-wellbeing-v12-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075228Z-council-continuity-wellbeing-v12-surface-audit.md
```

## expansion: council_continuity_wellbeing_v12_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id council_continuity_wellbeing_v12_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:28.688810+00:00`
- finished: `2026-03-14T07:52:30.286116+00:00`
- duration_sec: `1.594`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\council-continuity-wellbeing-v12-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075230Z-council-continuity-wellbeing-v12-gate.json
latest_md=docs\trinity-expansion\council-continuity-wellbeing-v12-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075230Z-council-continuity-wellbeing-v12-gate.md
```

## expansion: journey_log_absorption_v12_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id journey_log_absorption_v12_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:30.286116+00:00`
- finished: `2026-03-14T07:52:32.010931+00:00`
- duration_sec: `1.734`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\journey-log-absorption-v12-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075231Z-journey-log-absorption-v12-surface-audit.json
latest_md=docs\trinity-expansion\journey-log-absorption-v12-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075231Z-journey-log-absorption-v12-surface-audit.md
```

## expansion: journey_log_absorption_v12_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id journey_log_absorption_v12_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:32.010931+00:00`
- finished: `2026-03-14T07:52:34.573025+00:00`
- duration_sec: `2.563`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\journey-log-absorption-v12-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075234Z-journey-log-absorption-v12-gate.json
latest_md=docs\trinity-expansion\journey-log-absorption-v12-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075234Z-journey-log-absorption-v12-gate.md
```

## expansion: public_source_refresh_v12_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id public_source_refresh_v12_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:34.573547+00:00`
- finished: `2026-03-14T07:52:36.503987+00:00`
- duration_sec: `1.922`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\public-source-refresh-v12-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075236Z-public-source-refresh-v12-surface-audit.json
latest_md=docs\trinity-expansion\public-source-refresh-v12-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075236Z-public-source-refresh-v12-surface-audit.md
```

## expansion: public_source_refresh_v12_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id public_source_refresh_v12_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:36.503987+00:00`
- finished: `2026-03-14T07:52:38.451964+00:00`
- duration_sec: `1.953`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\public-source-refresh-v12-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075238Z-public-source-refresh-v12-gate.json
latest_md=docs\trinity-expansion\public-source-refresh-v12-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075238Z-public-source-refresh-v12-gate.md
```

## expansion: gmut_research_fabric_v12_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id gmut_research_fabric_v12_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:38.451964+00:00`
- finished: `2026-03-14T07:52:40.456158+00:00`
- duration_sec: `2.000`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\gmut-research-fabric-v12-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075240Z-gmut-research-fabric-v12-surface-audit.json
latest_md=docs\trinity-expansion\gmut-research-fabric-v12-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075240Z-gmut-research-fabric-v12-surface-audit.md
```

## expansion: gmut_research_fabric_v12_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id gmut_research_fabric_v12_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:40.456158+00:00`
- finished: `2026-03-14T07:52:42.739065+00:00`
- duration_sec: `2.281`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\gmut-research-fabric-v12-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075242Z-gmut-research-fabric-v12-gate.json
latest_md=docs\trinity-expansion\gmut-research-fabric-v12-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075242Z-gmut-research-fabric-v12-gate.md
```

## expansion: freedid_governance_fabric_v12_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id freedid_governance_fabric_v12_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:42.739065+00:00`
- finished: `2026-03-14T07:52:44.356557+00:00`
- duration_sec: `1.625`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\freedid-governance-fabric-v12-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075244Z-freedid-governance-fabric-v12-surface-audit.json
latest_md=docs\trinity-expansion\freedid-governance-fabric-v12-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075244Z-freedid-governance-fabric-v12-surface-audit.md
```

## expansion: freedid_governance_fabric_v12_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id freedid_governance_fabric_v12_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:44.356557+00:00`
- finished: `2026-03-14T07:52:46.317122+00:00`
- duration_sec: `1.953`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\freedid-governance-fabric-v12-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075246Z-freedid-governance-fabric-v12-gate.json
latest_md=docs\trinity-expansion\freedid-governance-fabric-v12-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075246Z-freedid-governance-fabric-v12-gate.md
```

## expansion: trinity_control_tower_v12_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v12_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:46.317122+00:00`
- finished: `2026-03-14T07:52:47.983535+00:00`
- duration_sec: `1.672`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\trinity-control-tower-v12-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075247Z-trinity-control-tower-v12-surface-audit.json
latest_md=docs\trinity-expansion\trinity-control-tower-v12-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075247Z-trinity-control-tower-v12-surface-audit.md
```

## expansion: trinity_control_tower_v12_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v12_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:47.983535+00:00`
- finished: `2026-03-14T07:52:50.004420+00:00`
- duration_sec: `2.016`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\trinity-control-tower-v12-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075249Z-trinity-control-tower-v12-gate.json
latest_md=docs\trinity-expansion\trinity-control-tower-v12-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075249Z-trinity-control-tower-v12-gate.md
```

## expansion: api_surface_book_v12_sync_bridge (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id api_surface_book_v12_sync_bridge --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:50.004988+00:00`
- finished: `2026-03-14T07:52:51.971363+00:00`
- duration_sec: `1.969`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\api-surface-book-v12-sync-bridge-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075251Z-api-surface-book-v12-sync-bridge.json
latest_md=docs\trinity-expansion\api-surface-book-v12-sync-bridge-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075251Z-api-surface-book-v12-sync-bridge.md
```

## expansion: api_surface_book_v12_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id api_surface_book_v12_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:51.972042+00:00`
- finished: `2026-03-14T07:52:53.437269+00:00`
- duration_sec: `1.468`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\api-surface-book-v12-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075253Z-api-surface-book-v12-surface-audit.json
latest_md=docs\trinity-expansion\api-surface-book-v12-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075253Z-api-surface-book-v12-surface-audit.md
```

## expansion: api_surface_book_v12_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id api_surface_book_v12_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-14T07:52:53.437778+00:00`
- finished: `2026-03-14T07:52:55.713192+00:00`
- duration_sec: `2.282`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\api-surface-book-v12-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260314T075255Z-api-surface-book-v12-gate.json
latest_md=docs\trinity-expansion\api-surface-book-v12-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260314T075255Z-api-surface-book-v12-gate.md
```

## trinity mandala scoreboard
- status: **PASS**
- command: `python3 scripts/trinity_mandala_scoreboard.py --fail-on-warn --suite-status docs/system-suite-status.json`
- started: `2026-03-14T07:52:56.006935+00:00`
- finished: `2026-03-14T07:52:58.837195+00:00`
- duration_sec: `2.844`
```text
hybrid_os_status=PASS
timestamped_json=docs\trinity-mandala-runs\20260314T075256Z-trinity-mandala-scoreboard.json
timestamped_md=docs\trinity-mandala-runs\20260314T075256Z-trinity-mandala-scoreboard.md
latest_json=docs\trinity-mandala-scoreboard-latest.json
latest_md=docs\trinity-mandala-scoreboard-latest.md
```

## Overall status
- Effective success: **True**
- PASS: **35**
- WARN: **0**
- TIMEOUT: **0**
- FAIL: **0**
- Expansion systems total: **23**
- Expansion systems passed: **23**
- Collab pack count: **112**
- Materialization pack count: **16**
- Materialization level desired: **l2_persistent_dev**
- Materialization level actual: **persistent_dev**
- Persistent target count: **4**
- Command surface state: **PASS**
- Council state: **PASS**
- Provisional agent count: **0**
- Group chat state: **PASS**
- Duo chat count: **15**
- Identity authority state: **PASS**
- Memory mirror state: **PASS**
- Late-step autonomy state: **PASS**
- Eligible live write connectors: **filesystem, github, linear, notion, postgres**
- Promoted live write connectors: **github, linear, notion, postgres**
- Blocked promotions: **filesystem**
- Achieved steps: **35**
- Achievement gate met: **True**
- Suite started: `2026-03-14T07:51:46.391514+00:00`
- Suite finished: `2026-03-14T07:52:58.839167+00:00`
- Suite duration_sec: `72.454`

## Machine-readable summary
```json
{
  "generated_utc": "2026-03-14T07:53:21.154213+00:00",
  "suite_started_at_utc": "2026-03-14T07:51:46.391514+00:00",
  "suite_finished_at_utc": "2026-03-14T07:52:58.839167+00:00",
  "suite_duration_sec": 72.454,
  "effective_success": true,
  "achieved_steps": 35,
  "achievement_gate_met": true,
  "counts": {
    "pass": 35,
    "warn": 0,
    "timeout": 0,
    "fail": 0
  },
  "expansion_systems_total": 23,
  "expansion_systems_passed": 23,
  "collab_pack_count": 112,
  "materialization_pack_count": 16,
  "verified_mcp_connectors": [
    "figma",
    "github",
    "linear",
    "notion",
    "postgres"
  ],
  "eligible_live_write_connectors": [
    "filesystem",
    "github",
    "linear",
    "notion",
    "postgres"
  ],
  "promoted_live_write_connectors": [
    "github",
    "linear",
    "notion",
    "postgres"
  ],
  "blocked_promotions": [
    "filesystem"
  ],
  "active_materialization_mode": "read_only",
  "mcp_refresh_mode": "disabled",
  "staged_connector_mode": "staged_only",
  "current_session_surface": {
    "git_remote_live": true,
    "docker_cli": true,
    "docker_container_running": true,
    "postgres_ready": true,
    "gh_available": false,
    "node_available": false,
    "npx_available": false
  },
  "connector_hardening_state": "PASS",
  "autonomy_mode": "bounded_manual",
  "knowledge_graph_state": "PASS",
  "dashboard_state": "PASS",
  "future_readiness_state": "PASS",
  "materialization_level_desired": "l2_persistent_dev",
  "materialization_level_actual": "persistent_dev",
  "persistent_target_count": 4,
  "command_surface_state": "PASS",
  "council_state": "PASS",
  "provisional_agent_count": 0,
  "group_chat_state": "PASS",
  "duo_chat_count": 15,
  "identity_authority_state": "PASS",
  "memory_mirror_state": "PASS",
  "late_step_autonomy_state": "PASS",
  "recovery_parent_run": "",
  "recovery_mode": "recover_profile",
  "dirty_tree_state": {
    "available": true,
    "staged_count": 0,
    "unstaged_count": 7202,
    "untracked_count": 517,
    "dirty": true
  },
  "storage_prune_delta_mb": 0.23,
  "resumed_step_count": 0,
  "config": {
    "step_timeout_sec": 0,
    "profile": "recover",
    "profile_source": "--profile",
    "include_version_scan": false,
    "include_skill_install": false,
    "include_curated_skill_catalog": false,
    "include_public_api_refresh": false,
    "include_mcp_refresh": false,
    "include_staged_connectors": false,
    "include_live_writes": false,
    "offline_only": false,
    "live_network_mode": "offline_default",
    "mcp_refresh_mode": "disabled",
    "staged_connector_mode": "staged_only",
    "active_materialization_mode": "read_only",
    "materialization_level": "l2_persistent_dev",
    "soft_fail_network": false,
    "fail_on_warn": true,
    "achievement_target_steps": 0,
    "quick_mode": false,
    "body_benchmark_mode": "off",
    "include_body_benchmark": false,
    "resume_failed_only": false,
    "resume_from_status": ""
  },
  "results": [
    {
      "label": "trinity extension catalog validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:51:46.392166+00:00",
      "finished_at_utc": "2026-03-14T07:51:47.139487+00:00",
      "duration_sec": 0.75,
      "command": "python3 scripts/trinity_extension_catalog_validator.py --fail-on-warn"
    },
    {
      "label": "trinity command book validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:51:47.140482+00:00",
      "finished_at_utc": "2026-03-14T07:51:50.184669+00:00",
      "duration_sec": 3.047,
      "command": "python3 scripts/trinity_command_book_validator.py --fail-on-warn"
    },
    {
      "label": "trinity api book validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:51:50.184669+00:00",
      "finished_at_utc": "2026-03-14T07:51:50.683283+00:00",
      "duration_sec": 0.5,
      "command": "python3 scripts/trinity_api_book_validator.py --fail-on-warn"
    },
    {
      "label": "trinity agent council validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:51:50.683283+00:00",
      "finished_at_utc": "2026-03-14T07:51:51.475056+00:00",
      "duration_sec": 0.782,
      "command": "python3 scripts/trinity_agent_council_v10_validator.py --fail-on-warn"
    },
    {
      "label": "trinity materialization ladder validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:51:51.475056+00:00",
      "finished_at_utc": "2026-03-14T07:51:53.268631+00:00",
      "duration_sec": 1.796,
      "command": "python3 scripts/trinity_materialization_ladder_validator.py --fail-on-warn"
    },
    {
      "label": "trinity expansion manifest validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:51:53.268631+00:00",
      "finished_at_utc": "2026-03-14T07:51:57.775646+00:00",
      "duration_sec": 4.516,
      "command": "python3 scripts/trinity_expansion_manifest_validator.py --fail-on-warn"
    },
    {
      "label": "trinity memory bank validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:51:57.775646+00:00",
      "finished_at_utc": "2026-03-14T07:51:58.728955+00:00",
      "duration_sec": 0.953,
      "command": "python3 scripts/trinity_memory_bank_validator.py --fail-on-warn"
    },
    {
      "label": "trinity storage prune dry-run",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:51:58.728955+00:00",
      "finished_at_utc": "2026-03-14T07:51:59.393254+00:00",
      "duration_sec": 0.656,
      "command": "python3 scripts/trinity_storage_retention.py --keep-stamps 2 --keep-archives 3 --dry-run"
    },
    {
      "label": "trinity api manifest validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:51:59.393254+00:00",
      "finished_at_utc": "2026-03-14T07:52:01.722523+00:00",
      "duration_sec": 2.329,
      "command": "python3 scripts/trinity_api_source_manifest_validator.py --fail-on-warn"
    },
    {
      "label": "trinity public research validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:01.722523+00:00",
      "finished_at_utc": "2026-03-14T07:52:02.990130+00:00",
      "duration_sec": 1.265,
      "command": "python3 scripts/validate_trinity_public_research.py --fail-on-warn"
    },
    {
      "label": "trinity public signal board (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:02.990130+00:00",
      "finished_at_utc": "2026-03-14T07:52:03.983389+00:00",
      "duration_sec": 1.0,
      "command": "python3 scripts/trinity_public_signal_board.py --fail-on-warn"
    },
    {
      "label": "expansion: storage_prune_governor_v12_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:03.984414+00:00",
      "finished_at_utc": "2026-03-14T07:52:06.569366+00:00",
      "duration_sec": 2.578,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id storage_prune_governor_v12_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: storage_prune_governor_v12_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:06.569366+00:00",
      "finished_at_utc": "2026-03-14T07:52:08.211654+00:00",
      "duration_sec": 1.657,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id storage_prune_governor_v12_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: artifact_retention_rebuild_v12_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:08.215674+00:00",
      "finished_at_utc": "2026-03-14T07:52:10.488431+00:00",
      "duration_sec": 2.265,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id artifact_retention_rebuild_v12_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: artifact_retention_rebuild_v12_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:10.488431+00:00",
      "finished_at_utc": "2026-03-14T07:52:12.543238+00:00",
      "duration_sec": 2.063,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id artifact_retention_rebuild_v12_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: docker_runtime_truth_v12_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:12.543238+00:00",
      "finished_at_utc": "2026-03-14T07:52:19.254539+00:00",
      "duration_sec": 6.703,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id docker_runtime_truth_v12_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: docker_runtime_truth_v12_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:19.254539+00:00",
      "finished_at_utc": "2026-03-14T07:52:21.926989+00:00",
      "duration_sec": 2.672,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id docker_runtime_truth_v12_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: google_drive_hold_guard_v12_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:21.926989+00:00",
      "finished_at_utc": "2026-03-14T07:52:23.304138+00:00",
      "duration_sec": 1.375,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id google_drive_hold_guard_v12_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: google_drive_hold_guard_v12_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:23.305682+00:00",
      "finished_at_utc": "2026-03-14T07:52:25.671937+00:00",
      "duration_sec": 2.36,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id google_drive_hold_guard_v12_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: council_continuity_wellbeing_v12_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:25.673257+00:00",
      "finished_at_utc": "2026-03-14T07:52:28.688810+00:00",
      "duration_sec": 3.015,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id council_continuity_wellbeing_v12_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: council_continuity_wellbeing_v12_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:28.688810+00:00",
      "finished_at_utc": "2026-03-14T07:52:30.286116+00:00",
      "duration_sec": 1.594,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id council_continuity_wellbeing_v12_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: journey_log_absorption_v12_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:30.286116+00:00",
      "finished_at_utc": "2026-03-14T07:52:32.010931+00:00",
      "duration_sec": 1.734,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id journey_log_absorption_v12_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: journey_log_absorption_v12_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:32.010931+00:00",
      "finished_at_utc": "2026-03-14T07:52:34.573025+00:00",
      "duration_sec": 2.563,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id journey_log_absorption_v12_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: public_source_refresh_v12_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:34.573547+00:00",
      "finished_at_utc": "2026-03-14T07:52:36.503987+00:00",
      "duration_sec": 1.922,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id public_source_refresh_v12_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: public_source_refresh_v12_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:36.503987+00:00",
      "finished_at_utc": "2026-03-14T07:52:38.451964+00:00",
      "duration_sec": 1.953,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id public_source_refresh_v12_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: gmut_research_fabric_v12_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:38.451964+00:00",
      "finished_at_utc": "2026-03-14T07:52:40.456158+00:00",
      "duration_sec": 2.0,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id gmut_research_fabric_v12_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: gmut_research_fabric_v12_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:40.456158+00:00",
      "finished_at_utc": "2026-03-14T07:52:42.739065+00:00",
      "duration_sec": 2.281,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id gmut_research_fabric_v12_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: freedid_governance_fabric_v12_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:42.739065+00:00",
      "finished_at_utc": "2026-03-14T07:52:44.356557+00:00",
      "duration_sec": 1.625,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id freedid_governance_fabric_v12_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: freedid_governance_fabric_v12_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:44.356557+00:00",
      "finished_at_utc": "2026-03-14T07:52:46.317122+00:00",
      "duration_sec": 1.953,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id freedid_governance_fabric_v12_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: trinity_control_tower_v12_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:46.317122+00:00",
      "finished_at_utc": "2026-03-14T07:52:47.983535+00:00",
      "duration_sec": 1.672,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v12_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: trinity_control_tower_v12_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:47.983535+00:00",
      "finished_at_utc": "2026-03-14T07:52:50.004420+00:00",
      "duration_sec": 2.016,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v12_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: api_surface_book_v12_sync_bridge (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:50.004988+00:00",
      "finished_at_utc": "2026-03-14T07:52:51.971363+00:00",
      "duration_sec": 1.969,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id api_surface_book_v12_sync_bridge --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: api_surface_book_v12_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:51.972042+00:00",
      "finished_at_utc": "2026-03-14T07:52:53.437269+00:00",
      "duration_sec": 1.468,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id api_surface_book_v12_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: api_surface_book_v12_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:53.437778+00:00",
      "finished_at_utc": "2026-03-14T07:52:55.713192+00:00",
      "duration_sec": 2.282,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id api_surface_book_v12_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "trinity mandala scoreboard",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-14T07:52:56.006935+00:00",
      "finished_at_utc": "2026-03-14T07:52:58.837195+00:00",
      "duration_sec": 2.844,
      "command": "python3 scripts/trinity_mandala_scoreboard.py --fail-on-warn --suite-status docs/system-suite-status.json"
    }
  ]
}
```

