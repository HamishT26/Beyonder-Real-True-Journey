# Trinity System Suite Run Report

Generated: 2026-03-16T00:32:27.643021+00:00
Step timeout (s): disabled
Profile: recover
Profile source: --profile
Include version scan: False
Include skill install: False
Include curated skill catalog: False
Include public api refresh: False
Include mcp refresh: False
Include staged connectors: False
Include live writes: False
Materialization level desired: l2_persistent_dev
Offline only: False
Live network mode: offline_default
MCP refresh mode: disabled
Staged connector mode: staged_only
Active materialization mode: read_only
Soft-fail network: False
Fail on warn: True
Achievement target steps: disabled
Quick mode: False
Body benchmark mode: off
Status JSON path: docs\system-suite-status.json

This report runs currently available repo systems and records command outputs.

## trinity extension catalog validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_extension_catalog_validator.py --fail-on-warn`
- started: `2026-03-16T00:32:27.644022+00:00`
- finished: `2026-03-16T00:32:29.201125+00:00`
- duration_sec: `1.547`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-extension-catalog-validation-latest.json
latest_md=docs\trinity-extension-catalog-validation-latest.md
```

## trinity command book validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_command_book_validator.py --fail-on-warn`
- started: `2026-03-16T00:32:29.201544+00:00`
- finished: `2026-03-16T00:32:33.680291+00:00`
- duration_sec: `4.485`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-command-book-validation-latest.json
latest_md=docs\trinity-command-book-validation-latest.md
```

## trinity api book validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_api_book_validator.py --fail-on-warn`
- started: `2026-03-16T00:32:33.680291+00:00`
- finished: `2026-03-16T00:32:34.282247+00:00`
- duration_sec: `0.593`
```text

```

## trinity agent council validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_agent_council_v10_validator.py --fail-on-warn`
- started: `2026-03-16T00:32:34.282247+00:00`
- finished: `2026-03-16T00:32:35.677867+00:00`
- duration_sec: `1.407`
```text
overall_status=PASS
effective_success=True
latest_json=docs/trinity-agent-council-validation-latest.json
latest_md=docs/trinity-agent-council-validation-latest.md
```

## trinity materialization ladder validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_materialization_ladder_validator.py --fail-on-warn`
- started: `2026-03-16T00:32:35.677867+00:00`
- finished: `2026-03-16T00:32:36.390766+00:00`
- duration_sec: `0.703`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-materialization-ladder-validation-latest.json
latest_md=docs\trinity-materialization-ladder-validation-latest.md
```

## trinity expansion manifest validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_manifest_validator.py --fail-on-warn`
- started: `2026-03-16T00:32:36.390766+00:00`
- finished: `2026-03-16T00:32:42.410786+00:00`
- duration_sec: `6.031`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion-manifest-validation-latest.json
latest_md=docs\trinity-expansion-manifest-validation-latest.md
```

## trinity memory bank validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_memory_bank_validator.py --fail-on-warn`
- started: `2026-03-16T00:32:42.410786+00:00`
- finished: `2026-03-16T00:32:42.839968+00:00`
- duration_sec: `0.422`
```text

```

## trinity storage prune dry-run
- status: **PASS**
- command: `python3 scripts/trinity_storage_retention.py --keep-stamps 2 --keep-archives 3 --dry-run`
- started: `2026-03-16T00:32:42.840484+00:00`
- finished: `2026-03-16T00:32:56.958389+00:00`
- duration_sec: `14.125`
```text
deleted_files=14920
reclaimed_mb=24.67
free_gib_delta=0.0
```

## trinity api manifest validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_api_source_manifest_validator.py --fail-on-warn`
- started: `2026-03-16T00:32:56.959386+00:00`
- finished: `2026-03-16T00:32:57.694702+00:00`
- duration_sec: `0.734`
```text
overall_status=PASS
api_count=7
```

## trinity public research validation (enforce)
- status: **PASS**
- command: `python3 scripts/validate_trinity_public_research.py --fail-on-warn`
- started: `2026-03-16T00:32:57.694702+00:00`
- finished: `2026-03-16T00:32:58.340546+00:00`
- duration_sec: `0.641`
```text
overall_status=PASS
timestamped_json=docs\trinity-public-research-runs\20260316T003258Z-trinity-public-research-validation.json
timestamped_md=docs\trinity-public-research-runs\20260316T003258Z-trinity-public-research-validation.md
latest_json=docs\trinity-public-research-validation-latest.json
latest_md=docs\trinity-public-research-validation-latest.md
```

## trinity public signal board (enforce)
- status: **FAIL**
- command: `python3 scripts/trinity_public_signal_board.py --fail-on-warn`
- started: `2026-03-16T00:32:58.340546+00:00`
- finished: `2026-03-16T00:32:59.221793+00:00`
- duration_sec: `0.875`
```text
overall_status=WARN
timestamped_json=docs\trinity-public-signal-runs\20260316T003258Z-trinity-public-signal-board.json
timestamped_md=docs\trinity-public-signal-runs\20260316T003258Z-trinity-public-signal-board.md
latest_json=docs\trinity-public-signal-board-latest.json
latest_md=docs\trinity-public-signal-board-latest.md
```

## gmut canon validation (enforce)
- status: **PASS**
- command: `python3 scripts/grand_mandala_canon_validator.py --fail-on-warn`
- started: `2026-03-16T00:32:59.221793+00:00`
- finished: `2026-03-16T00:32:59.620812+00:00`
- duration_sec: `0.391`
```text
gmut_canon_validation=PASS
```

## legacy reconstruction validation (enforce)
- status: **PASS**
- command: `python3 scripts/legacy_reconstruction_validator.py --fail-on-warn`
- started: `2026-03-16T00:32:59.621818+00:00`
- finished: `2026-03-16T00:33:00.012821+00:00`
- duration_sec: `0.391`
```text
legacy_reconstruction_validation=PASS
```

## expansion: canonical_gmut_latex_v13_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id canonical_gmut_latex_v13_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:33:00.012821+00:00`
- finished: `2026-03-16T00:33:01.754845+00:00`
- duration_sec: `1.750`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\canonical-gmut-latex-v13-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T003301Z-canonical-gmut-latex-v13-surface-audit.json
latest_md=docs\trinity-expansion\canonical-gmut-latex-v13-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T003301Z-canonical-gmut-latex-v13-surface-audit.md
```

## expansion: canonical_gmut_latex_v13_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id canonical_gmut_latex_v13_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:33:01.754845+00:00`
- finished: `2026-03-16T00:33:03.249816+00:00`
- duration_sec: `1.484`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\canonical-gmut-latex-v13-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T003303Z-canonical-gmut-latex-v13-gate.json
latest_md=docs\trinity-expansion\canonical-gmut-latex-v13-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T003303Z-canonical-gmut-latex-v13-gate.md
```

## expansion: mind_falsification_matrix_v13_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id mind_falsification_matrix_v13_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:33:03.249816+00:00`
- finished: `2026-03-16T00:33:04.721734+00:00`
- duration_sec: `1.469`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\mind-falsification-matrix-v13-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T003304Z-mind-falsification-matrix-v13-surface-audit.json
latest_md=docs\trinity-expansion\mind-falsification-matrix-v13-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T003304Z-mind-falsification-matrix-v13-surface-audit.md
```

## expansion: mind_falsification_matrix_v13_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id mind_falsification_matrix_v13_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:33:04.721734+00:00`
- finished: `2026-03-16T00:33:06.015965+00:00`
- duration_sec: `1.297`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\mind-falsification-matrix-v13-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T003305Z-mind-falsification-matrix-v13-gate.json
latest_md=docs\trinity-expansion\mind-falsification-matrix-v13-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T003305Z-mind-falsification-matrix-v13-gate.md
```

## expansion: public_source_refresh_v13_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id public_source_refresh_v13_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:33:06.015965+00:00`
- finished: `2026-03-16T00:33:07.508835+00:00`
- duration_sec: `1.500`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\public-source-refresh-v13-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T003307Z-public-source-refresh-v13-surface-audit.json
latest_md=docs\trinity-expansion\public-source-refresh-v13-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T003307Z-public-source-refresh-v13-surface-audit.md
```

## expansion: public_source_refresh_v13_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id public_source_refresh_v13_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:33:07.508835+00:00`
- finished: `2026-03-16T00:33:08.959618+00:00`
- duration_sec: `1.453`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\public-source-refresh-v13-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T003308Z-public-source-refresh-v13-gate.json
latest_md=docs\trinity-expansion\public-source-refresh-v13-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T003308Z-public-source-refresh-v13-gate.md
```

## expansion: heart_governance_alignment_v13_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id heart_governance_alignment_v13_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:33:08.959618+00:00`
- finished: `2026-03-16T00:33:10.448358+00:00`
- duration_sec: `1.484`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\heart-governance-alignment-v13-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T003310Z-heart-governance-alignment-v13-surface-audit.json
latest_md=docs\trinity-expansion\heart-governance-alignment-v13-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T003310Z-heart-governance-alignment-v13-surface-audit.md
```

## expansion: heart_governance_alignment_v13_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id heart_governance_alignment_v13_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:33:10.449362+00:00`
- finished: `2026-03-16T00:33:12.310008+00:00`
- duration_sec: `1.860`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\heart-governance-alignment-v13-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T003312Z-heart-governance-alignment-v13-gate.json
latest_md=docs\trinity-expansion\heart-governance-alignment-v13-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T003312Z-heart-governance-alignment-v13-gate.md
```

## expansion: supplemental_reflection_bridge_v13_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id supplemental_reflection_bridge_v13_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:33:12.311019+00:00`
- finished: `2026-03-16T00:33:13.598740+00:00`
- duration_sec: `1.296`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\supplemental-reflection-bridge-v13-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T003313Z-supplemental-reflection-bridge-v13-surface-audit.json
latest_md=docs\trinity-expansion\supplemental-reflection-bridge-v13-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T003313Z-supplemental-reflection-bridge-v13-surface-audit.md
```

## expansion: supplemental_reflection_bridge_v13_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id supplemental_reflection_bridge_v13_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:33:13.599499+00:00`
- finished: `2026-03-16T00:33:15.377126+00:00`
- duration_sec: `1.766`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\supplemental-reflection-bridge-v13-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T003315Z-supplemental-reflection-bridge-v13-gate.json
latest_md=docs\trinity-expansion\supplemental-reflection-bridge-v13-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T003315Z-supplemental-reflection-bridge-v13-gate.md
```

## expansion: legacy_module_inventory_v13_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id legacy_module_inventory_v13_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:33:15.377883+00:00`
- finished: `2026-03-16T00:33:18.734566+00:00`
- duration_sec: `3.359`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\legacy-module-inventory-v13-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T003316Z-legacy-module-inventory-v13-surface-audit.json
latest_md=docs\trinity-expansion\legacy-module-inventory-v13-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T003316Z-legacy-module-inventory-v13-surface-audit.md
```

## expansion: legacy_module_inventory_v13_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id legacy_module_inventory_v13_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:33:18.735568+00:00`
- finished: `2026-03-16T00:33:19.779163+00:00`
- duration_sec: `1.047`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\legacy-module-inventory-v13-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T003319Z-legacy-module-inventory-v13-gate.json
latest_md=docs\trinity-expansion\legacy-module-inventory-v13-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T003319Z-legacy-module-inventory-v13-gate.md
```

## expansion: kairotic_body_reconstruction_v13_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id kairotic_body_reconstruction_v13_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:33:19.779163+00:00`
- finished: `2026-03-16T00:33:22.365058+00:00`
- duration_sec: `2.594`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\kairotic-body-reconstruction-v13-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T003320Z-kairotic-body-reconstruction-v13-surface-audit.json
latest_md=docs\trinity-expansion\kairotic-body-reconstruction-v13-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T003320Z-kairotic-body-reconstruction-v13-surface-audit.md
```

## expansion: kairotic_body_reconstruction_v13_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id kairotic_body_reconstruction_v13_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:33:22.365058+00:00`
- finished: `2026-03-16T00:33:25.760160+00:00`
- duration_sec: `3.391`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\kairotic-body-reconstruction-v13-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T003325Z-kairotic-body-reconstruction-v13-gate.json
latest_md=docs\trinity-expansion\kairotic-body-reconstruction-v13-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T003325Z-kairotic-body-reconstruction-v13-gate.md
```

## expansion: api_surface_book_v13_sync_bridge (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id api_surface_book_v13_sync_bridge --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:33:25.760160+00:00`
- finished: `2026-03-16T00:33:27.965783+00:00`
- duration_sec: `2.203`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\api-surface-book-v13-sync-bridge-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T003327Z-api-surface-book-v13-sync-bridge.json
latest_md=docs\trinity-expansion\api-surface-book-v13-sync-bridge-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T003327Z-api-surface-book-v13-sync-bridge.md
```

## expansion: api_surface_book_v13_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id api_surface_book_v13_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:33:27.965783+00:00`
- finished: `2026-03-16T00:33:29.840691+00:00`
- duration_sec: `1.875`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\api-surface-book-v13-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T003329Z-api-surface-book-v13-surface-audit.json
latest_md=docs\trinity-expansion\api-surface-book-v13-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T003329Z-api-surface-book-v13-surface-audit.md
```

## expansion: api_surface_book_v13_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id api_surface_book_v13_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:33:29.841206+00:00`
- finished: `2026-03-16T00:33:31.329060+00:00`
- duration_sec: `1.484`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\api-surface-book-v13-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T003331Z-api-surface-book-v13-gate.json
latest_md=docs\trinity-expansion\api-surface-book-v13-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T003331Z-api-surface-book-v13-gate.md
```

## expansion: trinity_control_tower_v13_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v13_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:33:31.329060+00:00`
- finished: `2026-03-16T00:33:32.557186+00:00`
- duration_sec: `1.235`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\trinity-control-tower-v13-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T003332Z-trinity-control-tower-v13-surface-audit.json
latest_md=docs\trinity-expansion\trinity-control-tower-v13-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T003332Z-trinity-control-tower-v13-surface-audit.md
```

## expansion: trinity_control_tower_v13_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v13_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-16T00:33:32.557186+00:00`
- finished: `2026-03-16T00:33:33.997981+00:00`
- duration_sec: `1.437`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\trinity-control-tower-v13-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260316T003333Z-trinity-control-tower-v13-gate.json
latest_md=docs\trinity-expansion\trinity-control-tower-v13-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260316T003333Z-trinity-control-tower-v13-gate.md
```

## trinity mandala scoreboard
- status: **FAIL**
- command: `python3 scripts/trinity_mandala_scoreboard.py --fail-on-warn --suite-status docs/system-suite-status.json`
- started: `2026-03-16T00:33:34.045515+00:00`
- finished: `2026-03-16T00:33:40.379620+00:00`
- duration_sec: `6.344`
```text
hybrid_os_status=FAIL
timestamped_json=docs\trinity-mandala-runs\20260316T003334Z-trinity-mandala-scoreboard.json
timestamped_md=docs\trinity-mandala-runs\20260316T003334Z-trinity-mandala-scoreboard.md
latest_json=docs\trinity-mandala-scoreboard-latest.json
latest_md=docs\trinity-mandala-scoreboard-latest.md
```

## Overall status
- Effective success: **False**
- PASS: **31**
- WARN: **0**
- TIMEOUT: **0**
- FAIL: **2**
- Expansion systems total: **19**
- Expansion systems passed: **19**
- Collab pack count: **121**
- Materialization pack count: **16**
- Materialization level desired: **l2_persistent_dev**
- Materialization level actual: **readiness_only**
- Persistent target count: **4**
- Command surface state: **PASS**
- Council state: **PASS**
- Provisional agent count: **0**
- Group chat state: **PASS**
- Duo chat count: **15**
- Identity authority state: **PASS**
- Memory mirror state: **PASS**
- Late-step autonomy state: **PASS**
- Eligible live write connectors: **filesystem, github, linear, notion, postgres**
- Promoted live write connectors: **github, linear, notion, postgres**
- Blocked promotions: **filesystem**
- Achieved steps: **31**
- Achievement gate met: **True**
- Suite started: `2026-03-16T00:32:27.643021+00:00`
- Suite finished: `2026-03-16T00:33:40.395925+00:00`
- Suite duration_sec: `72.750`

## Machine-readable summary
```json
{
  "generated_utc": "2026-03-16T00:33:56.105794+00:00",
  "suite_started_at_utc": "2026-03-16T00:32:27.643021+00:00",
  "suite_finished_at_utc": "2026-03-16T00:33:40.395925+00:00",
  "suite_duration_sec": 72.75,
  "effective_success": false,
  "achieved_steps": 31,
  "achievement_gate_met": true,
  "counts": {
    "pass": 31,
    "warn": 0,
    "timeout": 0,
    "fail": 2
  },
  "expansion_systems_total": 19,
  "expansion_systems_passed": 19,
  "collab_pack_count": 121,
  "materialization_pack_count": 16,
  "verified_mcp_connectors": [
    "figma",
    "github",
    "linear",
    "notion",
    "postgres"
  ],
  "eligible_live_write_connectors": [
    "filesystem",
    "github",
    "linear",
    "notion",
    "postgres"
  ],
  "promoted_live_write_connectors": [
    "github",
    "linear",
    "notion",
    "postgres"
  ],
  "blocked_promotions": [
    "filesystem"
  ],
  "active_materialization_mode": "read_only",
  "mcp_refresh_mode": "disabled",
  "staged_connector_mode": "staged_only",
  "current_session_surface": {
    "git_remote_live": true,
    "docker_cli": true,
    "docker_container_running": true,
    "postgres_ready": true,
    "gh_available": false,
    "node_available": false,
    "npx_available": false
  },
  "connector_hardening_state": "PASS",
  "autonomy_mode": "bounded_manual",
  "knowledge_graph_state": "PASS",
  "dashboard_state": "PASS",
  "future_readiness_state": "PASS",
  "materialization_level_desired": "l2_persistent_dev",
  "materialization_level_actual": "readiness_only",
  "persistent_target_count": 4,
  "command_surface_state": "PASS",
  "council_state": "PASS",
  "provisional_agent_count": 0,
  "group_chat_state": "PASS",
  "duo_chat_count": 15,
  "identity_authority_state": "PASS",
  "memory_mirror_state": "PASS",
  "late_step_autonomy_state": "PASS",
  "recovery_parent_run": "",
  "recovery_mode": "recover_profile",
  "dirty_tree_state": {
    "available": true,
    "staged_count": 0,
    "unstaged_count": 1750,
    "untracked_count": 2206,
    "dirty": true
  },
  "storage_prune_delta_mb": 24.67,
  "resumed_step_count": 0,
  "config": {
    "step_timeout_sec": 0,
    "profile": "recover",
    "profile_source": "--profile",
    "include_version_scan": false,
    "include_skill_install": false,
    "include_curated_skill_catalog": false,
    "include_public_api_refresh": false,
    "include_mcp_refresh": false,
    "include_staged_connectors": false,
    "include_live_writes": false,
    "offline_only": false,
    "live_network_mode": "offline_default",
    "mcp_refresh_mode": "disabled",
    "staged_connector_mode": "staged_only",
    "active_materialization_mode": "read_only",
    "materialization_level": "l2_persistent_dev",
    "soft_fail_network": false,
    "fail_on_warn": true,
    "achievement_target_steps": 0,
    "quick_mode": false,
    "body_benchmark_mode": "off",
    "include_body_benchmark": false,
    "resume_failed_only": false,
    "resume_from_status": ""
  },
  "results": [
    {
      "label": "trinity extension catalog validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:32:27.644022+00:00",
      "finished_at_utc": "2026-03-16T00:32:29.201125+00:00",
      "duration_sec": 1.547,
      "command": "python3 scripts/trinity_extension_catalog_validator.py --fail-on-warn"
    },
    {
      "label": "trinity command book validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:32:29.201544+00:00",
      "finished_at_utc": "2026-03-16T00:32:33.680291+00:00",
      "duration_sec": 4.485,
      "command": "python3 scripts/trinity_command_book_validator.py --fail-on-warn"
    },
    {
      "label": "trinity api book validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:32:33.680291+00:00",
      "finished_at_utc": "2026-03-16T00:32:34.282247+00:00",
      "duration_sec": 0.593,
      "command": "python3 scripts/trinity_api_book_validator.py --fail-on-warn"
    },
    {
      "label": "trinity agent council validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:32:34.282247+00:00",
      "finished_at_utc": "2026-03-16T00:32:35.677867+00:00",
      "duration_sec": 1.407,
      "command": "python3 scripts/trinity_agent_council_v10_validator.py --fail-on-warn"
    },
    {
      "label": "trinity materialization ladder validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:32:35.677867+00:00",
      "finished_at_utc": "2026-03-16T00:32:36.390766+00:00",
      "duration_sec": 0.703,
      "command": "python3 scripts/trinity_materialization_ladder_validator.py --fail-on-warn"
    },
    {
      "label": "trinity expansion manifest validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:32:36.390766+00:00",
      "finished_at_utc": "2026-03-16T00:32:42.410786+00:00",
      "duration_sec": 6.031,
      "command": "python3 scripts/trinity_expansion_manifest_validator.py --fail-on-warn"
    },
    {
      "label": "trinity memory bank validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:32:42.410786+00:00",
      "finished_at_utc": "2026-03-16T00:32:42.839968+00:00",
      "duration_sec": 0.422,
      "command": "python3 scripts/trinity_memory_bank_validator.py --fail-on-warn"
    },
    {
      "label": "trinity storage prune dry-run",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:32:42.840484+00:00",
      "finished_at_utc": "2026-03-16T00:32:56.958389+00:00",
      "duration_sec": 14.125,
      "command": "python3 scripts/trinity_storage_retention.py --keep-stamps 2 --keep-archives 3 --dry-run"
    },
    {
      "label": "trinity api manifest validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:32:56.959386+00:00",
      "finished_at_utc": "2026-03-16T00:32:57.694702+00:00",
      "duration_sec": 0.734,
      "command": "python3 scripts/trinity_api_source_manifest_validator.py --fail-on-warn"
    },
    {
      "label": "trinity public research validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:32:57.694702+00:00",
      "finished_at_utc": "2026-03-16T00:32:58.340546+00:00",
      "duration_sec": 0.641,
      "command": "python3 scripts/validate_trinity_public_research.py --fail-on-warn"
    },
    {
      "label": "trinity public signal board (enforce)",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:32:58.340546+00:00",
      "finished_at_utc": "2026-03-16T00:32:59.221793+00:00",
      "duration_sec": 0.875,
      "command": "python3 scripts/trinity_public_signal_board.py --fail-on-warn"
    },
    {
      "label": "gmut canon validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:32:59.221793+00:00",
      "finished_at_utc": "2026-03-16T00:32:59.620812+00:00",
      "duration_sec": 0.391,
      "command": "python3 scripts/grand_mandala_canon_validator.py --fail-on-warn"
    },
    {
      "label": "legacy reconstruction validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:32:59.621818+00:00",
      "finished_at_utc": "2026-03-16T00:33:00.012821+00:00",
      "duration_sec": 0.391,
      "command": "python3 scripts/legacy_reconstruction_validator.py --fail-on-warn"
    },
    {
      "label": "expansion: canonical_gmut_latex_v13_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:33:00.012821+00:00",
      "finished_at_utc": "2026-03-16T00:33:01.754845+00:00",
      "duration_sec": 1.75,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id canonical_gmut_latex_v13_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: canonical_gmut_latex_v13_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:33:01.754845+00:00",
      "finished_at_utc": "2026-03-16T00:33:03.249816+00:00",
      "duration_sec": 1.484,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id canonical_gmut_latex_v13_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: mind_falsification_matrix_v13_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:33:03.249816+00:00",
      "finished_at_utc": "2026-03-16T00:33:04.721734+00:00",
      "duration_sec": 1.469,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id mind_falsification_matrix_v13_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: mind_falsification_matrix_v13_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:33:04.721734+00:00",
      "finished_at_utc": "2026-03-16T00:33:06.015965+00:00",
      "duration_sec": 1.297,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id mind_falsification_matrix_v13_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: public_source_refresh_v13_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:33:06.015965+00:00",
      "finished_at_utc": "2026-03-16T00:33:07.508835+00:00",
      "duration_sec": 1.5,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id public_source_refresh_v13_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: public_source_refresh_v13_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:33:07.508835+00:00",
      "finished_at_utc": "2026-03-16T00:33:08.959618+00:00",
      "duration_sec": 1.453,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id public_source_refresh_v13_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: heart_governance_alignment_v13_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:33:08.959618+00:00",
      "finished_at_utc": "2026-03-16T00:33:10.448358+00:00",
      "duration_sec": 1.484,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id heart_governance_alignment_v13_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: heart_governance_alignment_v13_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:33:10.449362+00:00",
      "finished_at_utc": "2026-03-16T00:33:12.310008+00:00",
      "duration_sec": 1.86,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id heart_governance_alignment_v13_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: supplemental_reflection_bridge_v13_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:33:12.311019+00:00",
      "finished_at_utc": "2026-03-16T00:33:13.598740+00:00",
      "duration_sec": 1.296,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id supplemental_reflection_bridge_v13_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: supplemental_reflection_bridge_v13_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:33:13.599499+00:00",
      "finished_at_utc": "2026-03-16T00:33:15.377126+00:00",
      "duration_sec": 1.766,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id supplemental_reflection_bridge_v13_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: legacy_module_inventory_v13_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:33:15.377883+00:00",
      "finished_at_utc": "2026-03-16T00:33:18.734566+00:00",
      "duration_sec": 3.359,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id legacy_module_inventory_v13_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: legacy_module_inventory_v13_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:33:18.735568+00:00",
      "finished_at_utc": "2026-03-16T00:33:19.779163+00:00",
      "duration_sec": 1.047,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id legacy_module_inventory_v13_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: kairotic_body_reconstruction_v13_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:33:19.779163+00:00",
      "finished_at_utc": "2026-03-16T00:33:22.365058+00:00",
      "duration_sec": 2.594,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id kairotic_body_reconstruction_v13_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: kairotic_body_reconstruction_v13_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:33:22.365058+00:00",
      "finished_at_utc": "2026-03-16T00:33:25.760160+00:00",
      "duration_sec": 3.391,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id kairotic_body_reconstruction_v13_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: api_surface_book_v13_sync_bridge (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:33:25.760160+00:00",
      "finished_at_utc": "2026-03-16T00:33:27.965783+00:00",
      "duration_sec": 2.203,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id api_surface_book_v13_sync_bridge --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: api_surface_book_v13_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:33:27.965783+00:00",
      "finished_at_utc": "2026-03-16T00:33:29.840691+00:00",
      "duration_sec": 1.875,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id api_surface_book_v13_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: api_surface_book_v13_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:33:29.841206+00:00",
      "finished_at_utc": "2026-03-16T00:33:31.329060+00:00",
      "duration_sec": 1.484,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id api_surface_book_v13_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: trinity_control_tower_v13_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:33:31.329060+00:00",
      "finished_at_utc": "2026-03-16T00:33:32.557186+00:00",
      "duration_sec": 1.235,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v13_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: trinity_control_tower_v13_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:33:32.557186+00:00",
      "finished_at_utc": "2026-03-16T00:33:33.997981+00:00",
      "duration_sec": 1.437,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v13_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "trinity mandala scoreboard",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-16T00:33:34.045515+00:00",
      "finished_at_utc": "2026-03-16T00:33:40.379620+00:00",
      "duration_sec": 6.344,
      "command": "python3 scripts/trinity_mandala_scoreboard.py --fail-on-warn --suite-status docs/system-suite-status.json"
    }
  ]
}
```

