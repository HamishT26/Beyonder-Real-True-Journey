# Trinity System Suite Run Report

Generated: 2026-03-06T01:18:25.641588+00:00
Step timeout (s): disabled
Profile: standard
Profile source: --profile
Include version scan: False
Include skill install: False
Include curated skill catalog: False
Soft-fail network: False
Fail on warn: True
Achievement target steps: disabled
Quick mode: False
Body benchmark mode: enforce
Status JSON path: docs\system-suite-status.json

This report runs currently available repo systems and records command outputs.

## v29 module map generation
- status: **FAIL**
- command: `python3 scripts/generate_v29_module_map.py`
- started: `2026-03-06T01:18:25.641588+00:00`
- finished: `2026-03-06T01:18:26.276807+00:00`
- duration_sec: `0.640`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## simulation sweep
- status: **FAIL**
- command: `python3 run_simulation.py --gammas 0.0 0.02 0.05 0.1`
- started: `2026-03-06T01:18:26.276807+00:00`
- finished: `2026-03-06T01:18:26.488051+00:00`
- duration_sec: `0.203`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## body benchmark guardrail check (enforce)
- status: **FAIL**
- command: `python3 body_track_runner.py --gammas 0.0 0.02 0.05 --benchmark-profile standard --profile-policy docs/body-profile-policy-v1.json --fail-on-benchmark`
- started: `2026-03-06T01:18:26.488051+00:00`
- finished: `2026-03-06T01:18:26.671799+00:00`
- duration_sec: `0.188`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## body benchmark trend guard (enforce)
- status: **FAIL**
- command: `python3 scripts/body_benchmark_trend_guard.py --trend-profile standard --profile-policy docs/body-profile-policy-v1.json --fail-on-warn`
- started: `2026-03-06T01:18:26.671799+00:00`
- finished: `2026-03-06T01:18:26.877051+00:00`
- duration_sec: `0.203`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## body profile calibration report
- status: **FAIL**
- command: `python3 scripts/body_profile_calibration_report.py --profile-context standard`
- started: `2026-03-06T01:18:26.877051+00:00`
- finished: `2026-03-06T01:18:27.066674+00:00`
- duration_sec: `0.187`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## body policy delta report (enforce)
- status: **FAIL**
- command: `python3 scripts/body_profile_policy_delta_report.py --policy-json docs/body-profile-policy-v1.json --apply --fail-on-warn`
- started: `2026-03-06T01:18:27.066674+00:00`
- finished: `2026-03-06T01:18:27.247093+00:00`
- duration_sec: `0.188`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## body policy stress-window report (enforce)
- status: **FAIL**
- command: `python3 scripts/body_policy_stress_window_report.py --policy-json docs/body-profile-policy-v1.json --fail-on-warn`
- started: `2026-03-06T01:18:27.247093+00:00`
- finished: `2026-03-06T01:18:27.414617+00:00`
- duration_sec: `0.172`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## gmut comparator metrics
- status: **FAIL**
- command: `python3 scripts/gmut_comparator_metrics.py`
- started: `2026-03-06T01:18:27.414617+00:00`
- finished: `2026-03-06T01:18:27.799224+00:00`
- duration_sec: `0.375`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## gmut external-anchor exclusion note
- status: **FAIL**
- command: `python3 scripts/gmut_external_anchor_exclusion_note.py --anchor-input docs/mind-track-external-anchor-canonical-inputs-v1.json`
- started: `2026-03-06T01:18:27.799224+00:00`
- finished: `2026-03-06T01:18:28.154997+00:00`
- duration_sec: `0.359`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## gmut anchor trace validation (enforce)
- status: **FAIL**
- command: `python3 scripts/gmut_anchor_trace_validator.py --fail-on-warn`
- started: `2026-03-06T01:18:28.154997+00:00`
- finished: `2026-03-06T01:18:28.332494+00:00`
- duration_sec: `0.172`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## full orchestrator demo
- status: **FAIL**
- command: `python3 trinity_orchestrator_full.py`
- started: `2026-03-06T01:18:28.332494+00:00`
- finished: `2026-03-06T01:18:28.944560+00:00`
- duration_sec: `0.625`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## vector transmutation
- status: **FAIL**
- command: `python3 scripts/trinity_vector_transmuter.py --passphrase suite-demo-passphrase --out docs/trinity-vector-profile.json`
- started: `2026-03-06T01:18:28.944560+00:00`
- finished: `2026-03-06T01:18:29.140531+00:00`
- duration_sec: `0.188`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## qcit coordination engine
- status: **FAIL**
- command: `python3 scripts/qcit_coordination_engine.py --out docs/qcit-coordination-report.json`
- started: `2026-03-06T01:18:29.140531+00:00`
- finished: `2026-03-06T01:18:29.356880+00:00`
- duration_sec: `0.218`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## quantum energy transmutation engine
- status: **FAIL**
- command: `python3 scripts/quantum_energy_transmutation_engine.py --out docs/quantum-energy-transmutation-report.json`
- started: `2026-03-06T01:18:29.356880+00:00`
- finished: `2026-03-06T01:18:29.580932+00:00`
- duration_sec: `0.219`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## qcit/quantum report validation
- status: **FAIL**
- command: `python3 scripts/validate_transmutation_reports.py --qcit docs/qcit-coordination-report.json --quantum docs/quantum-energy-transmutation-report.json`
- started: `2026-03-06T01:18:29.580932+00:00`
- finished: `2026-03-06T01:18:29.788869+00:00`
- duration_sec: `0.219`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## minimum-disclosure verifier (GOV-002)
- status: **FAIL**
- command: `python3 freed_id_minimum_disclosure_verifier.py`
- started: `2026-03-06T01:18:29.788869+00:00`
- finished: `2026-03-06T01:18:30.004323+00:00`
- duration_sec: `0.203`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## minimum-disclosure live-path verifier (GOV-002)
- status: **FAIL**
- command: `python3 freed_id_minimum_disclosure_live_path_verifier.py`
- started: `2026-03-06T01:18:30.004323+00:00`
- finished: `2026-03-06T01:18:30.199672+00:00`
- duration_sec: `0.203`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## minimum-disclosure adversarial verifier (GOV-002)
- status: **FAIL**
- command: `python3 freed_id_minimum_disclosure_adversarial_verifier.py`
- started: `2026-03-06T01:18:30.201683+00:00`
- finished: `2026-03-06T01:18:30.415081+00:00`
- duration_sec: `0.219`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## dispute/recourse verifier (GOV-004)
- status: **FAIL**
- command: `python3 freed_id_dispute_recourse_verifier.py`
- started: `2026-03-06T01:18:30.415081+00:00`
- finished: `2026-03-06T01:18:30.673050+00:00`
- duration_sec: `0.250`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## dispute/recourse adversarial verifier (GOV-004)
- status: **FAIL**
- command: `python3 freed_id_dispute_recourse_adversarial_verifier.py`
- started: `2026-03-06T01:18:30.673050+00:00`
- finished: `2026-03-06T01:18:30.912382+00:00`
- duration_sec: `0.250`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## token/credit zip converter
- status: **FAIL**
- command: `python3 scripts/trinity_token_credit_zip_converter.py --use-reserve-first --regeneration-multiplier 3.0 --target-reimbursement-ratio 1.0 --zip-snapshot --zip-label token-credit-suite --out docs/token-credit-bank-report.json --ledger docs/token-credit-bank-ledger.jsonl`
- started: `2026-03-06T01:18:30.917538+00:00`
- finished: `2026-03-06T01:18:31.130050+00:00`
- duration_sec: `0.219`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## cache/waste regenerator
- status: **FAIL**
- command: `python3 scripts/cache_waste_regenerator.py --out docs/cache-waste-regenerator-report.json --purge --prune-empty-dirs`
- started: `2026-03-06T01:18:31.130050+00:00`
- finished: `2026-03-06T01:18:31.355746+00:00`
- duration_sec: `0.218`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## cache/waste report validation
- status: **FAIL**
- command: `python3 scripts/validate_cache_waste_report.py --cache docs/cache-waste-regenerator-report.json`
- started: `2026-03-06T01:18:31.355746+00:00`
- finished: `2026-03-06T01:18:31.639725+00:00`
- duration_sec: `0.282`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## energy bank system
- status: **FAIL**
- command: `python3 scripts/trinity_energy_bank_system.py --token-report docs/token-credit-bank-report.json --cache-report docs/cache-waste-regenerator-report.json --reserve-growth 1.0 --reserve-cap-multiplier 10.0 --auto-max-cap --cap-ceiling 100.0 --out docs/energy-bank-report.json --state docs/energy-bank-state.json`
- started: `2026-03-06T01:18:31.639725+00:00`
- finished: `2026-03-06T01:18:32.026727+00:00`
- duration_sec: `0.390`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## token/energy report validation
- status: **FAIL**
- command: `python3 scripts/validate_token_energy_reports.py --token docs/token-credit-bank-report.json --energy docs/energy-bank-report.json`
- started: `2026-03-06T01:18:32.026727+00:00`
- finished: `2026-03-06T01:18:32.407854+00:00`
- duration_sec: `0.375`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## gyroscopic hybrid zip converter
- status: **FAIL**
- command: `python3 scripts/gyroscopic_hybrid_zip_converter_generator.py --label gyroscopic-suite-cycle --out docs/gyroscopic-hybrid-zip-report.json`
- started: `2026-03-06T01:18:32.407854+00:00`
- finished: `2026-03-06T01:18:32.981859+00:00`
- duration_sec: `0.578`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## memory integrity check (strict)
- status: **FAIL**
- command: `python3 scripts/aurelis_memory_integrity_check.py --strict`
- started: `2026-03-06T01:18:32.981859+00:00`
- finished: `2026-03-06T01:18:33.643727+00:00`
- duration_sec: `0.657`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## continuity cycle tick (dry-run status)
- status: **FAIL**
- command: `python3 scripts/aurelis_cycle_tick.py --user-message 'suite dry-run' --assistant-reflection 'Suite integration check for cycle tick' --progress-snapshot 'Validated dry-run status reporting in suite' --next-step 'Run normal tick from operator flow' --query cycle --query-limit 2 --dry-run --no-report --step-timeout-sec 0 --json-status docs/aurelis-cycle-tick-status.json`
- started: `2026-03-06T01:18:33.643727+00:00`
- finished: `2026-03-06T01:18:34.069470+00:00`
- duration_sec: `0.437`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## zip memory/data snapshot
- status: **FAIL**
- command: `python3 scripts/trinity_zip_memory_converter.py archive --label suite-standard`
- started: `2026-03-06T01:18:34.069470+00:00`
- finished: `2026-03-06T01:18:34.305605+00:00`
- duration_sec: `0.234`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## v33 structural OCR validation snapshot
- status: **FAIL**
- command: `bash -lc 'strings -n 8 '"'"'Beyonder-Real-True Journey v33 (Arielis) (2).pdf'"'"' | rg -n '"'"'Core Modules|Orchestrator|DID Method|Quantum|Freed|GMUT|Cosmic Bill'"'"' | head -n 20'`
- started: `2026-03-06T01:18:34.305605+00:00`
- finished: `2026-03-06T01:18:34.545375+00:00`
- duration_sec: `0.235`
```text
Python was not found; run without arguments to install from the Microsoft Store, or disable this shortcut from Settings > Apps > Advanced app settings > App execution aliases.
```

## Overall status
- Effective success: **False**
- PASS: **0**
- WARN: **0**
- TIMEOUT: **0**
- FAIL: **30**
- Achieved steps: **0**
- Achievement gate met: **True**
- Suite started: `2026-03-06T01:18:25.641588+00:00`
- Suite finished: `2026-03-06T01:18:34.545375+00:00`
- Suite duration_sec: `8.906`

## Machine-readable summary
```json
{
  "generated_utc": "2026-03-06T01:18:34.545375+00:00",
  "suite_started_at_utc": "2026-03-06T01:18:25.641588+00:00",
  "suite_finished_at_utc": "2026-03-06T01:18:34.545375+00:00",
  "suite_duration_sec": 8.906,
  "effective_success": false,
  "achieved_steps": 0,
  "achievement_gate_met": true,
  "counts": {
    "pass": 0,
    "warn": 0,
    "timeout": 0,
    "fail": 30
  },
  "config": {
    "step_timeout_sec": 0,
    "profile": "standard",
    "profile_source": "--profile",
    "include_version_scan": false,
    "include_skill_install": false,
    "include_curated_skill_catalog": false,
    "soft_fail_network": false,
    "fail_on_warn": true,
    "achievement_target_steps": 0,
    "quick_mode": false,
    "body_benchmark_mode": "enforce",
    "include_body_benchmark": true
  },
  "results": [
    {
      "label": "v29 module map generation",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:25.641588+00:00",
      "finished_at_utc": "2026-03-06T01:18:26.276807+00:00",
      "duration_sec": 0.64,
      "command": "python3 scripts/generate_v29_module_map.py"
    },
    {
      "label": "simulation sweep",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:26.276807+00:00",
      "finished_at_utc": "2026-03-06T01:18:26.488051+00:00",
      "duration_sec": 0.203,
      "command": "python3 run_simulation.py --gammas 0.0 0.02 0.05 0.1"
    },
    {
      "label": "body benchmark guardrail check (enforce)",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:26.488051+00:00",
      "finished_at_utc": "2026-03-06T01:18:26.671799+00:00",
      "duration_sec": 0.188,
      "command": "python3 body_track_runner.py --gammas 0.0 0.02 0.05 --benchmark-profile standard --profile-policy docs/body-profile-policy-v1.json --fail-on-benchmark"
    },
    {
      "label": "body benchmark trend guard (enforce)",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:26.671799+00:00",
      "finished_at_utc": "2026-03-06T01:18:26.877051+00:00",
      "duration_sec": 0.203,
      "command": "python3 scripts/body_benchmark_trend_guard.py --trend-profile standard --profile-policy docs/body-profile-policy-v1.json --fail-on-warn"
    },
    {
      "label": "body profile calibration report",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:26.877051+00:00",
      "finished_at_utc": "2026-03-06T01:18:27.066674+00:00",
      "duration_sec": 0.187,
      "command": "python3 scripts/body_profile_calibration_report.py --profile-context standard"
    },
    {
      "label": "body policy delta report (enforce)",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:27.066674+00:00",
      "finished_at_utc": "2026-03-06T01:18:27.247093+00:00",
      "duration_sec": 0.188,
      "command": "python3 scripts/body_profile_policy_delta_report.py --policy-json docs/body-profile-policy-v1.json --apply --fail-on-warn"
    },
    {
      "label": "body policy stress-window report (enforce)",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:27.247093+00:00",
      "finished_at_utc": "2026-03-06T01:18:27.414617+00:00",
      "duration_sec": 0.172,
      "command": "python3 scripts/body_policy_stress_window_report.py --policy-json docs/body-profile-policy-v1.json --fail-on-warn"
    },
    {
      "label": "gmut comparator metrics",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:27.414617+00:00",
      "finished_at_utc": "2026-03-06T01:18:27.799224+00:00",
      "duration_sec": 0.375,
      "command": "python3 scripts/gmut_comparator_metrics.py"
    },
    {
      "label": "gmut external-anchor exclusion note",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:27.799224+00:00",
      "finished_at_utc": "2026-03-06T01:18:28.154997+00:00",
      "duration_sec": 0.359,
      "command": "python3 scripts/gmut_external_anchor_exclusion_note.py --anchor-input docs/mind-track-external-anchor-canonical-inputs-v1.json"
    },
    {
      "label": "gmut anchor trace validation (enforce)",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:28.154997+00:00",
      "finished_at_utc": "2026-03-06T01:18:28.332494+00:00",
      "duration_sec": 0.172,
      "command": "python3 scripts/gmut_anchor_trace_validator.py --fail-on-warn"
    },
    {
      "label": "full orchestrator demo",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:28.332494+00:00",
      "finished_at_utc": "2026-03-06T01:18:28.944560+00:00",
      "duration_sec": 0.625,
      "command": "python3 trinity_orchestrator_full.py"
    },
    {
      "label": "vector transmutation",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:28.944560+00:00",
      "finished_at_utc": "2026-03-06T01:18:29.140531+00:00",
      "duration_sec": 0.188,
      "command": "python3 scripts/trinity_vector_transmuter.py --passphrase suite-demo-passphrase --out docs/trinity-vector-profile.json"
    },
    {
      "label": "qcit coordination engine",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:29.140531+00:00",
      "finished_at_utc": "2026-03-06T01:18:29.356880+00:00",
      "duration_sec": 0.218,
      "command": "python3 scripts/qcit_coordination_engine.py --out docs/qcit-coordination-report.json"
    },
    {
      "label": "quantum energy transmutation engine",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:29.356880+00:00",
      "finished_at_utc": "2026-03-06T01:18:29.580932+00:00",
      "duration_sec": 0.219,
      "command": "python3 scripts/quantum_energy_transmutation_engine.py --out docs/quantum-energy-transmutation-report.json"
    },
    {
      "label": "qcit/quantum report validation",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:29.580932+00:00",
      "finished_at_utc": "2026-03-06T01:18:29.788869+00:00",
      "duration_sec": 0.219,
      "command": "python3 scripts/validate_transmutation_reports.py --qcit docs/qcit-coordination-report.json --quantum docs/quantum-energy-transmutation-report.json"
    },
    {
      "label": "minimum-disclosure verifier (GOV-002)",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:29.788869+00:00",
      "finished_at_utc": "2026-03-06T01:18:30.004323+00:00",
      "duration_sec": 0.203,
      "command": "python3 freed_id_minimum_disclosure_verifier.py"
    },
    {
      "label": "minimum-disclosure live-path verifier (GOV-002)",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:30.004323+00:00",
      "finished_at_utc": "2026-03-06T01:18:30.199672+00:00",
      "duration_sec": 0.203,
      "command": "python3 freed_id_minimum_disclosure_live_path_verifier.py"
    },
    {
      "label": "minimum-disclosure adversarial verifier (GOV-002)",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:30.201683+00:00",
      "finished_at_utc": "2026-03-06T01:18:30.415081+00:00",
      "duration_sec": 0.219,
      "command": "python3 freed_id_minimum_disclosure_adversarial_verifier.py"
    },
    {
      "label": "dispute/recourse verifier (GOV-004)",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:30.415081+00:00",
      "finished_at_utc": "2026-03-06T01:18:30.673050+00:00",
      "duration_sec": 0.25,
      "command": "python3 freed_id_dispute_recourse_verifier.py"
    },
    {
      "label": "dispute/recourse adversarial verifier (GOV-004)",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:30.673050+00:00",
      "finished_at_utc": "2026-03-06T01:18:30.912382+00:00",
      "duration_sec": 0.25,
      "command": "python3 freed_id_dispute_recourse_adversarial_verifier.py"
    },
    {
      "label": "token/credit zip converter",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:30.917538+00:00",
      "finished_at_utc": "2026-03-06T01:18:31.130050+00:00",
      "duration_sec": 0.219,
      "command": "python3 scripts/trinity_token_credit_zip_converter.py --use-reserve-first --regeneration-multiplier 3.0 --target-reimbursement-ratio 1.0 --zip-snapshot --zip-label token-credit-suite --out docs/token-credit-bank-report.json --ledger docs/token-credit-bank-ledger.jsonl"
    },
    {
      "label": "cache/waste regenerator",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:31.130050+00:00",
      "finished_at_utc": "2026-03-06T01:18:31.355746+00:00",
      "duration_sec": 0.218,
      "command": "python3 scripts/cache_waste_regenerator.py --out docs/cache-waste-regenerator-report.json --purge --prune-empty-dirs"
    },
    {
      "label": "cache/waste report validation",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:31.355746+00:00",
      "finished_at_utc": "2026-03-06T01:18:31.639725+00:00",
      "duration_sec": 0.282,
      "command": "python3 scripts/validate_cache_waste_report.py --cache docs/cache-waste-regenerator-report.json"
    },
    {
      "label": "energy bank system",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:31.639725+00:00",
      "finished_at_utc": "2026-03-06T01:18:32.026727+00:00",
      "duration_sec": 0.39,
      "command": "python3 scripts/trinity_energy_bank_system.py --token-report docs/token-credit-bank-report.json --cache-report docs/cache-waste-regenerator-report.json --reserve-growth 1.0 --reserve-cap-multiplier 10.0 --auto-max-cap --cap-ceiling 100.0 --out docs/energy-bank-report.json --state docs/energy-bank-state.json"
    },
    {
      "label": "token/energy report validation",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:32.026727+00:00",
      "finished_at_utc": "2026-03-06T01:18:32.407854+00:00",
      "duration_sec": 0.375,
      "command": "python3 scripts/validate_token_energy_reports.py --token docs/token-credit-bank-report.json --energy docs/energy-bank-report.json"
    },
    {
      "label": "gyroscopic hybrid zip converter",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:32.407854+00:00",
      "finished_at_utc": "2026-03-06T01:18:32.981859+00:00",
      "duration_sec": 0.578,
      "command": "python3 scripts/gyroscopic_hybrid_zip_converter_generator.py --label gyroscopic-suite-cycle --out docs/gyroscopic-hybrid-zip-report.json"
    },
    {
      "label": "memory integrity check (strict)",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:32.981859+00:00",
      "finished_at_utc": "2026-03-06T01:18:33.643727+00:00",
      "duration_sec": 0.657,
      "command": "python3 scripts/aurelis_memory_integrity_check.py --strict"
    },
    {
      "label": "continuity cycle tick (dry-run status)",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:33.643727+00:00",
      "finished_at_utc": "2026-03-06T01:18:34.069470+00:00",
      "duration_sec": 0.437,
      "command": "python3 scripts/aurelis_cycle_tick.py --user-message 'suite dry-run' --assistant-reflection 'Suite integration check for cycle tick' --progress-snapshot 'Validated dry-run status reporting in suite' --next-step 'Run normal tick from operator flow' --query cycle --query-limit 2 --dry-run --no-report --step-timeout-sec 0 --json-status docs/aurelis-cycle-tick-status.json"
    },
    {
      "label": "zip memory/data snapshot",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:34.069470+00:00",
      "finished_at_utc": "2026-03-06T01:18:34.305605+00:00",
      "duration_sec": 0.234,
      "command": "python3 scripts/trinity_zip_memory_converter.py archive --label suite-standard"
    },
    {
      "label": "v33 structural OCR validation snapshot",
      "status": "FAIL",
      "ok": false,
      "effective_success": false,
      "timed_out": false,
      "started_at_utc": "2026-03-06T01:18:34.305605+00:00",
      "finished_at_utc": "2026-03-06T01:18:34.545375+00:00",
      "duration_sec": 0.235,
      "command": "bash -lc 'strings -n 8 '\"'\"'Beyonder-Real-True Journey v33 (Arielis) (2).pdf'\"'\"' | rg -n '\"'\"'Core Modules|Orchestrator|DID Method|Quantum|Freed|GMUT|Cosmic Bill'\"'\"' | head -n 20'"
    }
  ]
}
```

