# Trinity System Suite Run Report

Generated: 2026-03-17T00:24:07.348474+00:00
Step timeout (s): disabled
Profile: recover
Profile source: --profile
Include version scan: False
Include skill install: False
Include curated skill catalog: False
Include public api refresh: False
Include mcp refresh: False
Include staged connectors: False
Include live writes: False
Materialization level desired: l2_persistent_dev
Offline only: False
Live network mode: offline_default
MCP refresh mode: disabled
Staged connector mode: staged_only
Active materialization mode: read_only
Soft-fail network: False
Fail on warn: True
Achievement target steps: disabled
Quick mode: False
Body benchmark mode: off
Status JSON path: docs\system-suite-status.json

This report runs currently available repo systems and records command outputs.

## trinity extension catalog validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_extension_catalog_validator.py --fail-on-warn`
- started: `2026-03-17T00:24:07.349473+00:00`
- finished: `2026-03-17T00:24:09.624995+00:00`
- duration_sec: `2.266`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-extension-catalog-validation-latest.json
latest_md=docs\trinity-extension-catalog-validation-latest.md
```

## trinity command book validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_command_book_validator.py --fail-on-warn`
- started: `2026-03-17T00:24:09.627533+00:00`
- finished: `2026-03-17T00:24:13.367668+00:00`
- duration_sec: `3.750`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-command-book-validation-latest.json
latest_md=docs\trinity-command-book-validation-latest.md
```

## trinity api book validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_api_book_validator.py --fail-on-warn`
- started: `2026-03-17T00:24:13.368184+00:00`
- finished: `2026-03-17T00:24:13.955675+00:00`
- duration_sec: `0.578`
```text

```

## trinity agent council validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_agent_council_v14_validator.py --fail-on-warn`
- started: `2026-03-17T00:24:13.956671+00:00`
- finished: `2026-03-17T00:24:15.085462+00:00`
- duration_sec: `1.125`
```text
overall_status=PASS
effective_success=True
```

## trinity materialization ladder validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_materialization_ladder_validator.py --fail-on-warn`
- started: `2026-03-17T00:24:15.085462+00:00`
- finished: `2026-03-17T00:24:15.681118+00:00`
- duration_sec: `0.594`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-materialization-ladder-validation-latest.json
latest_md=docs\trinity-materialization-ladder-validation-latest.md
```

## trinity expansion manifest validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_manifest_validator.py --fail-on-warn`
- started: `2026-03-17T00:24:15.681118+00:00`
- finished: `2026-03-17T00:24:22.068146+00:00`
- duration_sec: `6.391`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion-manifest-validation-latest.json
latest_md=docs\trinity-expansion-manifest-validation-latest.md
```

## trinity memory bank validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_memory_bank_validator.py --fail-on-warn`
- started: `2026-03-17T00:24:22.068146+00:00`
- finished: `2026-03-17T00:24:22.767531+00:00`
- duration_sec: `0.687`
```text

```

## trinity storage prune dry-run
- status: **PASS**
- command: `python3 scripts/trinity_storage_retention.py --keep-stamps 2 --keep-archives 3 --dry-run`
- started: `2026-03-17T00:24:22.767531+00:00`
- finished: `2026-03-17T00:24:55.063776+00:00`
- duration_sec: `32.297`
```text
deleted_files=27831
reclaimed_mb=46.36
free_gib_delta=0.0
```

## trinity api manifest validation (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_api_source_manifest_validator.py --fail-on-warn`
- started: `2026-03-17T00:24:55.064775+00:00`
- finished: `2026-03-17T00:24:56.361921+00:00`
- duration_sec: `1.297`
```text
overall_status=PASS
api_count=7
```

## trinity public research validation (enforce)
- status: **PASS**
- command: `python3 scripts/validate_trinity_public_research.py --fail-on-warn`
- started: `2026-03-17T00:24:56.361921+00:00`
- finished: `2026-03-17T00:24:57.508980+00:00`
- duration_sec: `1.156`
```text
overall_status=PASS
timestamped_json=docs\trinity-public-research-runs\20260317T002456Z-trinity-public-research-validation.json
timestamped_md=docs\trinity-public-research-runs\20260317T002456Z-trinity-public-research-validation.md
latest_json=docs\trinity-public-research-validation-latest.json
latest_md=docs\trinity-public-research-validation-latest.md
```

## trinity public signal board (enforce)
- status: **PASS**
- command: `python3 scripts/trinity_public_signal_board.py --fail-on-warn`
- started: `2026-03-17T00:24:57.510985+00:00`
- finished: `2026-03-17T00:24:59.368523+00:00`
- duration_sec: `1.860`
```text
overall_status=PASS
timestamped_json=docs\trinity-public-signal-runs\20260317T002458Z-trinity-public-signal-board.json
timestamped_md=docs\trinity-public-signal-runs\20260317T002458Z-trinity-public-signal-board.md
latest_json=docs\trinity-public-signal-board-latest.json
latest_md=docs\trinity-public-signal-board-latest.md
```

## gmut canon validation (enforce)
- status: **PASS**
- command: `python3 scripts/grand_mandala_canon_validator.py --fail-on-warn`
- started: `2026-03-17T00:24:59.370546+00:00`
- finished: `2026-03-17T00:24:59.945200+00:00`
- duration_sec: `0.578`
```text
gmut_canon_validation=PASS
```

## legacy reconstruction validation (enforce)
- status: **PASS**
- command: `python3 scripts/legacy_reconstruction_validator.py --fail-on-warn`
- started: `2026-03-17T00:24:59.945200+00:00`
- finished: `2026-03-17T00:25:00.495455+00:00`
- duration_sec: `0.547`
```text
legacy_reconstruction_validation=PASS
```

## expansion: subagent_council_foundation_v14_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id subagent_council_foundation_v14_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:00.497929+00:00`
- finished: `2026-03-17T00:25:02.350028+00:00`
- duration_sec: `1.859`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\subagent-council-foundation-v14-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002502Z-subagent-council-foundation-v14-surface-audit.json
latest_md=docs\trinity-expansion\subagent-council-foundation-v14-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002502Z-subagent-council-foundation-v14-surface-audit.md
```

## expansion: subagent_council_foundation_v14_sync_bridge (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id subagent_council_foundation_v14_sync_bridge --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:02.350028+00:00`
- finished: `2026-03-17T00:25:03.814031+00:00`
- duration_sec: `1.453`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\subagent-council-foundation-v14-sync-bridge-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002503Z-subagent-council-foundation-v14-sync-bridge.json
latest_md=docs\trinity-expansion\subagent-council-foundation-v14-sync-bridge-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002503Z-subagent-council-foundation-v14-sync-bridge.md
```

## expansion: subagent_council_foundation_v14_materialization_tracer (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id subagent_council_foundation_v14_materialization_tracer --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:03.814031+00:00`
- finished: `2026-03-17T00:25:05.195741+00:00`
- duration_sec: `1.391`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\subagent-council-foundation-v14-materialization-tracer-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002505Z-subagent-council-foundation-v14-materialization-tracer.json
latest_md=docs\trinity-expansion\subagent-council-foundation-v14-materialization-tracer-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002505Z-subagent-council-foundation-v14-materialization-tracer.md
```

## expansion: subagent_council_foundation_v14_cache_board (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id subagent_council_foundation_v14_cache_board --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:05.195741+00:00`
- finished: `2026-03-17T00:25:07.094244+00:00`
- duration_sec: `1.890`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\subagent-council-foundation-v14-cache-board-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002506Z-subagent-council-foundation-v14-cache-board.json
latest_md=docs\trinity-expansion\subagent-council-foundation-v14-cache-board-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002506Z-subagent-council-foundation-v14-cache-board.md
```

## expansion: subagent_council_foundation_v14_risk_board (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id subagent_council_foundation_v14_risk_board --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:07.094244+00:00`
- finished: `2026-03-17T00:25:08.445920+00:00`
- duration_sec: `1.360`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\subagent-council-foundation-v14-risk-board-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002508Z-subagent-council-foundation-v14-risk-board.json
latest_md=docs\trinity-expansion\subagent-council-foundation-v14-risk-board-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002508Z-subagent-council-foundation-v14-risk-board.md
```

## expansion: subagent_council_foundation_v14_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id subagent_council_foundation_v14_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:08.445920+00:00`
- finished: `2026-03-17T00:25:10.165618+00:00`
- duration_sec: `1.719`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\subagent-council-foundation-v14-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002510Z-subagent-council-foundation-v14-gate.json
latest_md=docs\trinity-expansion\subagent-council-foundation-v14-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002510Z-subagent-council-foundation-v14-gate.md
```

## expansion: subagent_identity_certification_v14_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id subagent_identity_certification_v14_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:10.166151+00:00`
- finished: `2026-03-17T00:25:13.375236+00:00`
- duration_sec: `3.203`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\subagent-identity-certification-v14-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002513Z-subagent-identity-certification-v14-surface-audit.json
latest_md=docs\trinity-expansion\subagent-identity-certification-v14-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002513Z-subagent-identity-certification-v14-surface-audit.md
```

## expansion: subagent_identity_certification_v14_sync_bridge (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id subagent_identity_certification_v14_sync_bridge --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:13.376294+00:00`
- finished: `2026-03-17T00:25:15.065187+00:00`
- duration_sec: `1.687`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\subagent-identity-certification-v14-sync-bridge-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002514Z-subagent-identity-certification-v14-sync-bridge.json
latest_md=docs\trinity-expansion\subagent-identity-certification-v14-sync-bridge-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002514Z-subagent-identity-certification-v14-sync-bridge.md
```

## expansion: subagent_identity_certification_v14_materialization_tracer (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id subagent_identity_certification_v14_materialization_tracer --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:15.066115+00:00`
- finished: `2026-03-17T00:25:16.492850+00:00`
- duration_sec: `1.438`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\subagent-identity-certification-v14-materialization-tracer-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002516Z-subagent-identity-certification-v14-materialization-tracer.json
latest_md=docs\trinity-expansion\subagent-identity-certification-v14-materialization-tracer-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002516Z-subagent-identity-certification-v14-materialization-tracer.md
```

## expansion: subagent_identity_certification_v14_cache_board (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id subagent_identity_certification_v14_cache_board --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:16.498221+00:00`
- finished: `2026-03-17T00:25:18.444888+00:00`
- duration_sec: `1.953`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\subagent-identity-certification-v14-cache-board-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002518Z-subagent-identity-certification-v14-cache-board.json
latest_md=docs\trinity-expansion\subagent-identity-certification-v14-cache-board-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002518Z-subagent-identity-certification-v14-cache-board.md
```

## expansion: subagent_identity_certification_v14_risk_board (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id subagent_identity_certification_v14_risk_board --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:18.444888+00:00`
- finished: `2026-03-17T00:25:19.966671+00:00`
- duration_sec: `1.515`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\subagent-identity-certification-v14-risk-board-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002519Z-subagent-identity-certification-v14-risk-board.json
latest_md=docs\trinity-expansion\subagent-identity-certification-v14-risk-board-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002519Z-subagent-identity-certification-v14-risk-board.md
```

## expansion: subagent_identity_certification_v14_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id subagent_identity_certification_v14_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:19.966671+00:00`
- finished: `2026-03-17T00:25:21.544618+00:00`
- duration_sec: `1.579`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\subagent-identity-certification-v14-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002521Z-subagent-identity-certification-v14-gate.json
latest_md=docs\trinity-expansion\subagent-identity-certification-v14-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002521Z-subagent-identity-certification-v14-gate.md
```

## expansion: subagent_induction_proof_v14_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id subagent_induction_proof_v14_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:21.545621+00:00`
- finished: `2026-03-17T00:25:23.239720+00:00`
- duration_sec: `1.703`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\subagent-induction-proof-v14-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002523Z-subagent-induction-proof-v14-surface-audit.json
latest_md=docs\trinity-expansion\subagent-induction-proof-v14-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002523Z-subagent-induction-proof-v14-surface-audit.md
```

## expansion: subagent_induction_proof_v14_sync_bridge (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id subagent_induction_proof_v14_sync_bridge --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:23.239720+00:00`
- finished: `2026-03-17T00:25:24.998493+00:00`
- duration_sec: `1.750`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\subagent-induction-proof-v14-sync-bridge-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002524Z-subagent-induction-proof-v14-sync-bridge.json
latest_md=docs\trinity-expansion\subagent-induction-proof-v14-sync-bridge-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002524Z-subagent-induction-proof-v14-sync-bridge.md
```

## expansion: subagent_induction_proof_v14_materialization_tracer (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id subagent_induction_proof_v14_materialization_tracer --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:24.999527+00:00`
- finished: `2026-03-17T00:25:26.447617+00:00`
- duration_sec: `1.453`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\subagent-induction-proof-v14-materialization-tracer-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002526Z-subagent-induction-proof-v14-materialization-tracer.json
latest_md=docs\trinity-expansion\subagent-induction-proof-v14-materialization-tracer-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002526Z-subagent-induction-proof-v14-materialization-tracer.md
```

## expansion: subagent_induction_proof_v14_cache_board (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id subagent_induction_proof_v14_cache_board --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:26.447617+00:00`
- finished: `2026-03-17T00:25:28.264652+00:00`
- duration_sec: `1.812`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\subagent-induction-proof-v14-cache-board-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002528Z-subagent-induction-proof-v14-cache-board.json
latest_md=docs\trinity-expansion\subagent-induction-proof-v14-cache-board-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002528Z-subagent-induction-proof-v14-cache-board.md
```

## expansion: subagent_induction_proof_v14_risk_board (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id subagent_induction_proof_v14_risk_board --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:28.264652+00:00`
- finished: `2026-03-17T00:25:29.613823+00:00`
- duration_sec: `1.344`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\subagent-induction-proof-v14-risk-board-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002529Z-subagent-induction-proof-v14-risk-board.json
latest_md=docs\trinity-expansion\subagent-induction-proof-v14-risk-board-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002529Z-subagent-induction-proof-v14-risk-board.md
```

## expansion: subagent_induction_proof_v14_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id subagent_induction_proof_v14_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:29.613823+00:00`
- finished: `2026-03-17T00:25:31.371222+00:00`
- duration_sec: `1.766`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\subagent-induction-proof-v14-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002531Z-subagent-induction-proof-v14-gate.json
latest_md=docs\trinity-expansion\subagent-induction-proof-v14-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002531Z-subagent-induction-proof-v14-gate.md
```

## expansion: multi_instance_runtime_v14_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id multi_instance_runtime_v14_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:31.371222+00:00`
- finished: `2026-03-17T00:25:32.921297+00:00`
- duration_sec: `1.547`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\multi-instance-runtime-v14-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002532Z-multi-instance-runtime-v14-surface-audit.json
latest_md=docs\trinity-expansion\multi-instance-runtime-v14-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002532Z-multi-instance-runtime-v14-surface-audit.md
```

## expansion: multi_instance_runtime_v14_sync_bridge (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id multi_instance_runtime_v14_sync_bridge --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:32.921297+00:00`
- finished: `2026-03-17T00:25:34.799781+00:00`
- duration_sec: `1.875`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\multi-instance-runtime-v14-sync-bridge-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002534Z-multi-instance-runtime-v14-sync-bridge.json
latest_md=docs\trinity-expansion\multi-instance-runtime-v14-sync-bridge-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002534Z-multi-instance-runtime-v14-sync-bridge.md
```

## expansion: multi_instance_runtime_v14_materialization_tracer (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id multi_instance_runtime_v14_materialization_tracer --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:34.804782+00:00`
- finished: `2026-03-17T00:25:36.242355+00:00`
- duration_sec: `1.438`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\multi-instance-runtime-v14-materialization-tracer-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002536Z-multi-instance-runtime-v14-materialization-tracer.json
latest_md=docs\trinity-expansion\multi-instance-runtime-v14-materialization-tracer-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002536Z-multi-instance-runtime-v14-materialization-tracer.md
```

## expansion: multi_instance_runtime_v14_cache_board (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id multi_instance_runtime_v14_cache_board --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:36.244354+00:00`
- finished: `2026-03-17T00:25:37.672693+00:00`
- duration_sec: `1.422`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\multi-instance-runtime-v14-cache-board-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002537Z-multi-instance-runtime-v14-cache-board.json
latest_md=docs\trinity-expansion\multi-instance-runtime-v14-cache-board-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002537Z-multi-instance-runtime-v14-cache-board.md
```

## expansion: multi_instance_runtime_v14_risk_board (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id multi_instance_runtime_v14_risk_board --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:37.672693+00:00`
- finished: `2026-03-17T00:25:39.157090+00:00`
- duration_sec: `1.484`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\multi-instance-runtime-v14-risk-board-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002539Z-multi-instance-runtime-v14-risk-board.json
latest_md=docs\trinity-expansion\multi-instance-runtime-v14-risk-board-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002539Z-multi-instance-runtime-v14-risk-board.md
```

## expansion: multi_instance_runtime_v14_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id multi_instance_runtime_v14_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:39.157090+00:00`
- finished: `2026-03-17T00:25:41.026384+00:00`
- duration_sec: `1.875`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\multi-instance-runtime-v14-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002540Z-multi-instance-runtime-v14-gate.json
latest_md=docs\trinity-expansion\multi-instance-runtime-v14-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002540Z-multi-instance-runtime-v14-gate.md
```

## expansion: api_operator_mesh_v14_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id api_operator_mesh_v14_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:41.026384+00:00`
- finished: `2026-03-17T00:25:42.762173+00:00`
- duration_sec: `1.734`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\api-operator-mesh-v14-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002542Z-api-operator-mesh-v14-surface-audit.json
latest_md=docs\trinity-expansion\api-operator-mesh-v14-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002542Z-api-operator-mesh-v14-surface-audit.md
```

## expansion: api_operator_mesh_v14_sync_bridge (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id api_operator_mesh_v14_sync_bridge --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:42.763152+00:00`
- finished: `2026-03-17T00:25:44.660223+00:00`
- duration_sec: `1.891`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\api-operator-mesh-v14-sync-bridge-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002544Z-api-operator-mesh-v14-sync-bridge.json
latest_md=docs\trinity-expansion\api-operator-mesh-v14-sync-bridge-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002544Z-api-operator-mesh-v14-sync-bridge.md
```

## expansion: api_operator_mesh_v14_materialization_tracer (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id api_operator_mesh_v14_materialization_tracer --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:44.660223+00:00`
- finished: `2026-03-17T00:25:46.082616+00:00`
- duration_sec: `1.422`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\api-operator-mesh-v14-materialization-tracer-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002545Z-api-operator-mesh-v14-materialization-tracer.json
latest_md=docs\trinity-expansion\api-operator-mesh-v14-materialization-tracer-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002545Z-api-operator-mesh-v14-materialization-tracer.md
```

## expansion: api_operator_mesh_v14_cache_board (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id api_operator_mesh_v14_cache_board --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:46.082616+00:00`
- finished: `2026-03-17T00:25:47.671205+00:00`
- duration_sec: `1.594`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\api-operator-mesh-v14-cache-board-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002547Z-api-operator-mesh-v14-cache-board.json
latest_md=docs\trinity-expansion\api-operator-mesh-v14-cache-board-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002547Z-api-operator-mesh-v14-cache-board.md
```

## expansion: api_operator_mesh_v14_risk_board (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id api_operator_mesh_v14_risk_board --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:47.671205+00:00`
- finished: `2026-03-17T00:25:48.990332+00:00`
- duration_sec: `1.312`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\api-operator-mesh-v14-risk-board-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002548Z-api-operator-mesh-v14-risk-board.json
latest_md=docs\trinity-expansion\api-operator-mesh-v14-risk-board-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002548Z-api-operator-mesh-v14-risk-board.md
```

## expansion: api_operator_mesh_v14_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id api_operator_mesh_v14_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:48.990851+00:00`
- finished: `2026-03-17T00:25:51.197324+00:00`
- duration_sec: `2.203`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\api-operator-mesh-v14-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002550Z-api-operator-mesh-v14-gate.json
latest_md=docs\trinity-expansion\api-operator-mesh-v14-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002550Z-api-operator-mesh-v14-gate.md
```

## expansion: trinity_control_tower_v14_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v14_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:51.197324+00:00`
- finished: `2026-03-17T00:25:53.058224+00:00`
- duration_sec: `1.859`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\trinity-control-tower-v14-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002552Z-trinity-control-tower-v14-surface-audit.json
latest_md=docs\trinity-expansion\trinity-control-tower-v14-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002552Z-trinity-control-tower-v14-surface-audit.md
```

## expansion: trinity_control_tower_v14_sync_bridge (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v14_sync_bridge --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:53.059245+00:00`
- finished: `2026-03-17T00:25:55.141548+00:00`
- duration_sec: `2.078`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\trinity-control-tower-v14-sync-bridge-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002554Z-trinity-control-tower-v14-sync-bridge.json
latest_md=docs\trinity-expansion\trinity-control-tower-v14-sync-bridge-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002554Z-trinity-control-tower-v14-sync-bridge.md
```

## expansion: trinity_control_tower_v14_materialization_tracer (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v14_materialization_tracer --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:55.141548+00:00`
- finished: `2026-03-17T00:25:56.794956+00:00`
- duration_sec: `1.657`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\trinity-control-tower-v14-materialization-tracer-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002556Z-trinity-control-tower-v14-materialization-tracer.json
latest_md=docs\trinity-expansion\trinity-control-tower-v14-materialization-tracer-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002556Z-trinity-control-tower-v14-materialization-tracer.md
```

## expansion: trinity_control_tower_v14_cache_board (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v14_cache_board --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:56.795471+00:00`
- finished: `2026-03-17T00:25:58.609715+00:00`
- duration_sec: `1.812`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\trinity-control-tower-v14-cache-board-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002558Z-trinity-control-tower-v14-cache-board.json
latest_md=docs\trinity-expansion\trinity-control-tower-v14-cache-board-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002558Z-trinity-control-tower-v14-cache-board.md
```

## expansion: trinity_control_tower_v14_risk_board (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v14_risk_board --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:25:58.609715+00:00`
- finished: `2026-03-17T00:26:00.666308+00:00`
- duration_sec: `2.063`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\trinity-control-tower-v14-risk-board-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002600Z-trinity-control-tower-v14-risk-board.json
latest_md=docs\trinity-expansion\trinity-control-tower-v14-risk-board-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002600Z-trinity-control-tower-v14-risk-board.md
```

## expansion: trinity_control_tower_v14_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v14_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:00.666308+00:00`
- finished: `2026-03-17T00:26:03.207349+00:00`
- duration_sec: `2.531`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\trinity-control-tower-v14-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002602Z-trinity-control-tower-v14-gate.json
latest_md=docs\trinity-expansion\trinity-control-tower-v14-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002602Z-trinity-control-tower-v14-gate.md
```

## expansion: gmut_observable_mapping_v14_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id gmut_observable_mapping_v14_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:03.207349+00:00`
- finished: `2026-03-17T00:26:05.121905+00:00`
- duration_sec: `1.922`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\gmut-observable-mapping-v14-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002604Z-gmut-observable-mapping-v14-surface-audit.json
latest_md=docs\trinity-expansion\gmut-observable-mapping-v14-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002604Z-gmut-observable-mapping-v14-surface-audit.md
```

## expansion: gmut_observable_mapping_v14_sync_bridge (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id gmut_observable_mapping_v14_sync_bridge --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:05.121905+00:00`
- finished: `2026-03-17T00:26:06.804749+00:00`
- duration_sec: `1.687`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\gmut-observable-mapping-v14-sync-bridge-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002606Z-gmut-observable-mapping-v14-sync-bridge.json
latest_md=docs\trinity-expansion\gmut-observable-mapping-v14-sync-bridge-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002606Z-gmut-observable-mapping-v14-sync-bridge.md
```

## expansion: gmut_observable_mapping_v14_materialization_tracer (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id gmut_observable_mapping_v14_materialization_tracer --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:06.804749+00:00`
- finished: `2026-03-17T00:26:08.331202+00:00`
- duration_sec: `1.453`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\gmut-observable-mapping-v14-materialization-tracer-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002608Z-gmut-observable-mapping-v14-materialization-tracer.json
latest_md=docs\trinity-expansion\gmut-observable-mapping-v14-materialization-tracer-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002608Z-gmut-observable-mapping-v14-materialization-tracer.md
```

## expansion: gmut_observable_mapping_v14_cache_board (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id gmut_observable_mapping_v14_cache_board --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:08.331202+00:00`
- finished: `2026-03-17T00:26:09.857421+00:00`
- duration_sec: `1.531`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\gmut-observable-mapping-v14-cache-board-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002609Z-gmut-observable-mapping-v14-cache-board.json
latest_md=docs\trinity-expansion\gmut-observable-mapping-v14-cache-board-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002609Z-gmut-observable-mapping-v14-cache-board.md
```

## expansion: gmut_observable_mapping_v14_risk_board (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id gmut_observable_mapping_v14_risk_board --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:09.857421+00:00`
- finished: `2026-03-17T00:26:11.525851+00:00`
- duration_sec: `1.672`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\gmut-observable-mapping-v14-risk-board-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002611Z-gmut-observable-mapping-v14-risk-board.json
latest_md=docs\trinity-expansion\gmut-observable-mapping-v14-risk-board-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002611Z-gmut-observable-mapping-v14-risk-board.md
```

## expansion: gmut_observable_mapping_v14_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id gmut_observable_mapping_v14_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:11.525851+00:00`
- finished: `2026-03-17T00:26:14.842772+00:00`
- duration_sec: `3.312`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\gmut-observable-mapping-v14-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002614Z-gmut-observable-mapping-v14-gate.json
latest_md=docs\trinity-expansion\gmut-observable-mapping-v14-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002614Z-gmut-observable-mapping-v14-gate.md
```

## expansion: freedid_governance_alignment_v14_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id freedid_governance_alignment_v14_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:14.842772+00:00`
- finished: `2026-03-17T00:26:16.942311+00:00`
- duration_sec: `2.094`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\freedid-governance-alignment-v14-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002616Z-freedid-governance-alignment-v14-surface-audit.json
latest_md=docs\trinity-expansion\freedid-governance-alignment-v14-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002616Z-freedid-governance-alignment-v14-surface-audit.md
```

## expansion: freedid_governance_alignment_v14_sync_bridge (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id freedid_governance_alignment_v14_sync_bridge --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:16.943310+00:00`
- finished: `2026-03-17T00:26:18.375975+00:00`
- duration_sec: `1.438`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\freedid-governance-alignment-v14-sync-bridge-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002618Z-freedid-governance-alignment-v14-sync-bridge.json
latest_md=docs\trinity-expansion\freedid-governance-alignment-v14-sync-bridge-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002618Z-freedid-governance-alignment-v14-sync-bridge.md
```

## expansion: freedid_governance_alignment_v14_materialization_tracer (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id freedid_governance_alignment_v14_materialization_tracer --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:18.376976+00:00`
- finished: `2026-03-17T00:26:20.639297+00:00`
- duration_sec: `2.265`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\freedid-governance-alignment-v14-materialization-tracer-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002620Z-freedid-governance-alignment-v14-materialization-tracer.json
latest_md=docs\trinity-expansion\freedid-governance-alignment-v14-materialization-tracer-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002620Z-freedid-governance-alignment-v14-materialization-tracer.md
```

## expansion: freedid_governance_alignment_v14_cache_board (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id freedid_governance_alignment_v14_cache_board --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:20.639297+00:00`
- finished: `2026-03-17T00:26:22.478595+00:00`
- duration_sec: `1.844`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\freedid-governance-alignment-v14-cache-board-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002622Z-freedid-governance-alignment-v14-cache-board.json
latest_md=docs\trinity-expansion\freedid-governance-alignment-v14-cache-board-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002622Z-freedid-governance-alignment-v14-cache-board.md
```

## expansion: freedid_governance_alignment_v14_risk_board (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id freedid_governance_alignment_v14_risk_board --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:22.478595+00:00`
- finished: `2026-03-17T00:26:24.426651+00:00`
- duration_sec: `1.938`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\freedid-governance-alignment-v14-risk-board-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002624Z-freedid-governance-alignment-v14-risk-board.json
latest_md=docs\trinity-expansion\freedid-governance-alignment-v14-risk-board-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002624Z-freedid-governance-alignment-v14-risk-board.md
```

## expansion: freedid_governance_alignment_v14_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id freedid_governance_alignment_v14_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:24.427023+00:00`
- finished: `2026-03-17T00:26:26.529211+00:00`
- duration_sec: `2.109`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\freedid-governance-alignment-v14-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002626Z-freedid-governance-alignment-v14-gate.json
latest_md=docs\trinity-expansion\freedid-governance-alignment-v14-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002626Z-freedid-governance-alignment-v14-gate.md
```

## expansion: journey_lineage_inventory_v14_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id journey_lineage_inventory_v14_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:26.529211+00:00`
- finished: `2026-03-17T00:26:28.288981+00:00`
- duration_sec: `1.766`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\journey-lineage-inventory-v14-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002628Z-journey-lineage-inventory-v14-surface-audit.json
latest_md=docs\trinity-expansion\journey-lineage-inventory-v14-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002628Z-journey-lineage-inventory-v14-surface-audit.md
```

## expansion: journey_lineage_inventory_v14_sync_bridge (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id journey_lineage_inventory_v14_sync_bridge --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:28.288981+00:00`
- finished: `2026-03-17T00:26:30.511006+00:00`
- duration_sec: `2.218`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\journey-lineage-inventory-v14-sync-bridge-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002629Z-journey-lineage-inventory-v14-sync-bridge.json
latest_md=docs\trinity-expansion\journey-lineage-inventory-v14-sync-bridge-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002629Z-journey-lineage-inventory-v14-sync-bridge.md
```

## expansion: journey_lineage_inventory_v14_materialization_tracer (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id journey_lineage_inventory_v14_materialization_tracer --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:30.511006+00:00`
- finished: `2026-03-17T00:26:31.756306+00:00`
- duration_sec: `1.235`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\journey-lineage-inventory-v14-materialization-tracer-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002631Z-journey-lineage-inventory-v14-materialization-tracer.json
latest_md=docs\trinity-expansion\journey-lineage-inventory-v14-materialization-tracer-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002631Z-journey-lineage-inventory-v14-materialization-tracer.md
```

## expansion: journey_lineage_inventory_v14_cache_board (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id journey_lineage_inventory_v14_cache_board --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:31.756306+00:00`
- finished: `2026-03-17T00:26:33.726042+00:00`
- duration_sec: `1.984`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\journey-lineage-inventory-v14-cache-board-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002633Z-journey-lineage-inventory-v14-cache-board.json
latest_md=docs\trinity-expansion\journey-lineage-inventory-v14-cache-board-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002633Z-journey-lineage-inventory-v14-cache-board.md
```

## expansion: journey_lineage_inventory_v14_risk_board (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id journey_lineage_inventory_v14_risk_board --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:33.726042+00:00`
- finished: `2026-03-17T00:26:35.213011+00:00`
- duration_sec: `1.484`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\journey-lineage-inventory-v14-risk-board-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002635Z-journey-lineage-inventory-v14-risk-board.json
latest_md=docs\trinity-expansion\journey-lineage-inventory-v14-risk-board-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002635Z-journey-lineage-inventory-v14-risk-board.md
```

## expansion: journey_lineage_inventory_v14_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id journey_lineage_inventory_v14_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:35.213011+00:00`
- finished: `2026-03-17T00:26:36.940993+00:00`
- duration_sec: `1.719`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\journey-lineage-inventory-v14-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002636Z-journey-lineage-inventory-v14-gate.json
latest_md=docs\trinity-expansion\journey-lineage-inventory-v14-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002636Z-journey-lineage-inventory-v14-gate.md
```

## expansion: council_reflection_validation_v14_surface_audit (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id council_reflection_validation_v14_surface_audit --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:36.940993+00:00`
- finished: `2026-03-17T00:26:38.673796+00:00`
- duration_sec: `1.735`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\council-reflection-validation-v14-surface-audit-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002638Z-council-reflection-validation-v14-surface-audit.json
latest_md=docs\trinity-expansion\council-reflection-validation-v14-surface-audit-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002638Z-council-reflection-validation-v14-surface-audit.md
```

## expansion: council_reflection_validation_v14_sync_bridge (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id council_reflection_validation_v14_sync_bridge --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:38.673796+00:00`
- finished: `2026-03-17T00:26:40.564071+00:00`
- duration_sec: `1.890`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\council-reflection-validation-v14-sync-bridge-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002640Z-council-reflection-validation-v14-sync-bridge.json
latest_md=docs\trinity-expansion\council-reflection-validation-v14-sync-bridge-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002640Z-council-reflection-validation-v14-sync-bridge.md
```

## expansion: council_reflection_validation_v14_materialization_tracer (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id council_reflection_validation_v14_materialization_tracer --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:40.565070+00:00`
- finished: `2026-03-17T00:26:41.886563+00:00`
- duration_sec: `1.328`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\council-reflection-validation-v14-materialization-tracer-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002641Z-council-reflection-validation-v14-materialization-tracer.json
latest_md=docs\trinity-expansion\council-reflection-validation-v14-materialization-tracer-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002641Z-council-reflection-validation-v14-materialization-tracer.md
```

## expansion: council_reflection_validation_v14_cache_board (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id council_reflection_validation_v14_cache_board --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:41.886563+00:00`
- finished: `2026-03-17T00:26:43.414499+00:00`
- duration_sec: `1.532`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\council-reflection-validation-v14-cache-board-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002643Z-council-reflection-validation-v14-cache-board.json
latest_md=docs\trinity-expansion\council-reflection-validation-v14-cache-board-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002643Z-council-reflection-validation-v14-cache-board.md
```

## expansion: council_reflection_validation_v14_risk_board (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id council_reflection_validation_v14_risk_board --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:43.418501+00:00`
- finished: `2026-03-17T00:26:45.175139+00:00`
- duration_sec: `1.750`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\council-reflection-validation-v14-risk-board-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002645Z-council-reflection-validation-v14-risk-board.json
latest_md=docs\trinity-expansion\council-reflection-validation-v14-risk-board-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002645Z-council-reflection-validation-v14-risk-board.md
```

## expansion: council_reflection_validation_v14_gate (offline)
- status: **PASS**
- command: `python3 scripts/trinity_expansion_system_runner.py --system-id council_reflection_validation_v14_gate --profile-context recover --offline-only --fail-on-warn`
- started: `2026-03-17T00:26:45.175139+00:00`
- finished: `2026-03-17T00:26:46.936476+00:00`
- duration_sec: `1.765`
```text
overall_status=PASS
effective_success=True
latest_json=docs\trinity-expansion\council-reflection-validation-v14-gate-latest.json
timestamped_json=docs\trinity-expansion-runs\20260317T002646Z-council-reflection-validation-v14-gate.json
latest_md=docs\trinity-expansion\council-reflection-validation-v14-gate-latest.md
timestamped_md=docs\trinity-expansion-runs\20260317T002646Z-council-reflection-validation-v14-gate.md
```

## trinity mandala scoreboard
- status: **PASS**
- command: `python3 scripts/trinity_mandala_scoreboard.py --fail-on-warn --suite-status docs/system-suite-status.json`
- started: `2026-03-17T00:26:47.019416+00:00`
- finished: `2026-03-17T00:26:49.904343+00:00`
- duration_sec: `2.891`
```text
hybrid_os_status=PASS
timestamped_json=docs\trinity-mandala-runs\20260317T002647Z-trinity-mandala-scoreboard.json
timestamped_md=docs\trinity-mandala-runs\20260317T002647Z-trinity-mandala-scoreboard.md
latest_json=docs\trinity-mandala-scoreboard-latest.json
latest_md=docs\trinity-mandala-scoreboard-latest.md
```

## Overall status
- Effective success: **True**
- PASS: **74**
- WARN: **0**
- TIMEOUT: **0**
- FAIL: **0**
- Expansion systems total: **60**
- Expansion systems passed: **60**
- Collab pack count: **131**
- Materialization pack count: **16**
- Materialization level desired: **l2_persistent_dev**
- Materialization level actual: **readiness_only**
- Persistent target count: **4**
- Command surface state: **PASS**
- Council state: **PASS**
- Provisional agent count: **0**
- Group chat state: **PASS**
- Duo chat count: **36**
- Identity authority state: **PASS**
- Memory mirror state: **PASS**
- Late-step autonomy state: **PASS**
- Eligible live write connectors: **filesystem, github, linear, notion, postgres**
- Promoted live write connectors: **github, linear, notion, postgres**
- Blocked promotions: **filesystem**
- Achieved steps: **74**
- Achievement gate met: **True**
- Suite started: `2026-03-17T00:24:07.348474+00:00`
- Suite finished: `2026-03-17T00:26:49.906349+00:00`
- Suite duration_sec: `162.547`

## Machine-readable summary
```json
{
  "generated_utc": "2026-03-17T00:27:10.156022+00:00",
  "suite_started_at_utc": "2026-03-17T00:24:07.348474+00:00",
  "suite_finished_at_utc": "2026-03-17T00:26:49.906349+00:00",
  "suite_duration_sec": 162.547,
  "effective_success": true,
  "achieved_steps": 74,
  "achievement_gate_met": true,
  "counts": {
    "pass": 74,
    "warn": 0,
    "timeout": 0,
    "fail": 0
  },
  "expansion_systems_total": 60,
  "expansion_systems_passed": 60,
  "collab_pack_count": 131,
  "materialization_pack_count": 16,
  "verified_mcp_connectors": [
    "figma",
    "github",
    "linear",
    "notion",
    "postgres"
  ],
  "eligible_live_write_connectors": [
    "filesystem",
    "github",
    "linear",
    "notion",
    "postgres"
  ],
  "promoted_live_write_connectors": [
    "github",
    "linear",
    "notion",
    "postgres"
  ],
  "blocked_promotions": [
    "filesystem"
  ],
  "active_materialization_mode": "read_only",
  "mcp_refresh_mode": "disabled",
  "staged_connector_mode": "staged_only",
  "current_session_surface": {
    "git_remote_live": true,
    "docker_cli": true,
    "docker_container_running": true,
    "postgres_ready": true,
    "gh_available": false,
    "node_available": false,
    "npx_available": false
  },
  "connector_hardening_state": "PASS",
  "autonomy_mode": "bounded_manual",
  "knowledge_graph_state": "PASS",
  "dashboard_state": "PASS",
  "future_readiness_state": "PASS",
  "materialization_level_desired": "l2_persistent_dev",
  "materialization_level_actual": "readiness_only",
  "persistent_target_count": 4,
  "command_surface_state": "PASS",
  "council_state": "PASS",
  "provisional_agent_count": 0,
  "group_chat_state": "PASS",
  "duo_chat_count": 36,
  "identity_authority_state": "PASS",
  "memory_mirror_state": "PASS",
  "late_step_autonomy_state": "PASS",
  "recovery_parent_run": "",
  "recovery_mode": "recover_profile",
  "dirty_tree_state": {
    "available": true,
    "staged_count": 0,
    "unstaged_count": 72,
    "untracked_count": 530,
    "dirty": true
  },
  "storage_prune_delta_mb": 46.36,
  "resumed_step_count": 0,
  "config": {
    "step_timeout_sec": 0,
    "profile": "recover",
    "profile_source": "--profile",
    "include_version_scan": false,
    "include_skill_install": false,
    "include_curated_skill_catalog": false,
    "include_public_api_refresh": false,
    "include_mcp_refresh": false,
    "include_staged_connectors": false,
    "include_live_writes": false,
    "offline_only": false,
    "live_network_mode": "offline_default",
    "mcp_refresh_mode": "disabled",
    "staged_connector_mode": "staged_only",
    "active_materialization_mode": "read_only",
    "materialization_level": "l2_persistent_dev",
    "soft_fail_network": false,
    "fail_on_warn": true,
    "achievement_target_steps": 0,
    "quick_mode": false,
    "body_benchmark_mode": "off",
    "include_body_benchmark": false,
    "resume_failed_only": false,
    "resume_from_status": ""
  },
  "results": [
    {
      "label": "trinity extension catalog validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:24:07.349473+00:00",
      "finished_at_utc": "2026-03-17T00:24:09.624995+00:00",
      "duration_sec": 2.266,
      "command": "python3 scripts/trinity_extension_catalog_validator.py --fail-on-warn"
    },
    {
      "label": "trinity command book validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:24:09.627533+00:00",
      "finished_at_utc": "2026-03-17T00:24:13.367668+00:00",
      "duration_sec": 3.75,
      "command": "python3 scripts/trinity_command_book_validator.py --fail-on-warn"
    },
    {
      "label": "trinity api book validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:24:13.368184+00:00",
      "finished_at_utc": "2026-03-17T00:24:13.955675+00:00",
      "duration_sec": 0.578,
      "command": "python3 scripts/trinity_api_book_validator.py --fail-on-warn"
    },
    {
      "label": "trinity agent council validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:24:13.956671+00:00",
      "finished_at_utc": "2026-03-17T00:24:15.085462+00:00",
      "duration_sec": 1.125,
      "command": "python3 scripts/trinity_agent_council_v14_validator.py --fail-on-warn"
    },
    {
      "label": "trinity materialization ladder validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:24:15.085462+00:00",
      "finished_at_utc": "2026-03-17T00:24:15.681118+00:00",
      "duration_sec": 0.594,
      "command": "python3 scripts/trinity_materialization_ladder_validator.py --fail-on-warn"
    },
    {
      "label": "trinity expansion manifest validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:24:15.681118+00:00",
      "finished_at_utc": "2026-03-17T00:24:22.068146+00:00",
      "duration_sec": 6.391,
      "command": "python3 scripts/trinity_expansion_manifest_validator.py --fail-on-warn"
    },
    {
      "label": "trinity memory bank validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:24:22.068146+00:00",
      "finished_at_utc": "2026-03-17T00:24:22.767531+00:00",
      "duration_sec": 0.687,
      "command": "python3 scripts/trinity_memory_bank_validator.py --fail-on-warn"
    },
    {
      "label": "trinity storage prune dry-run",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:24:22.767531+00:00",
      "finished_at_utc": "2026-03-17T00:24:55.063776+00:00",
      "duration_sec": 32.297,
      "command": "python3 scripts/trinity_storage_retention.py --keep-stamps 2 --keep-archives 3 --dry-run"
    },
    {
      "label": "trinity api manifest validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:24:55.064775+00:00",
      "finished_at_utc": "2026-03-17T00:24:56.361921+00:00",
      "duration_sec": 1.297,
      "command": "python3 scripts/trinity_api_source_manifest_validator.py --fail-on-warn"
    },
    {
      "label": "trinity public research validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:24:56.361921+00:00",
      "finished_at_utc": "2026-03-17T00:24:57.508980+00:00",
      "duration_sec": 1.156,
      "command": "python3 scripts/validate_trinity_public_research.py --fail-on-warn"
    },
    {
      "label": "trinity public signal board (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:24:57.510985+00:00",
      "finished_at_utc": "2026-03-17T00:24:59.368523+00:00",
      "duration_sec": 1.86,
      "command": "python3 scripts/trinity_public_signal_board.py --fail-on-warn"
    },
    {
      "label": "gmut canon validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:24:59.370546+00:00",
      "finished_at_utc": "2026-03-17T00:24:59.945200+00:00",
      "duration_sec": 0.578,
      "command": "python3 scripts/grand_mandala_canon_validator.py --fail-on-warn"
    },
    {
      "label": "legacy reconstruction validation (enforce)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:24:59.945200+00:00",
      "finished_at_utc": "2026-03-17T00:25:00.495455+00:00",
      "duration_sec": 0.547,
      "command": "python3 scripts/legacy_reconstruction_validator.py --fail-on-warn"
    },
    {
      "label": "expansion: subagent_council_foundation_v14_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:00.497929+00:00",
      "finished_at_utc": "2026-03-17T00:25:02.350028+00:00",
      "duration_sec": 1.859,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id subagent_council_foundation_v14_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: subagent_council_foundation_v14_sync_bridge (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:02.350028+00:00",
      "finished_at_utc": "2026-03-17T00:25:03.814031+00:00",
      "duration_sec": 1.453,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id subagent_council_foundation_v14_sync_bridge --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: subagent_council_foundation_v14_materialization_tracer (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:03.814031+00:00",
      "finished_at_utc": "2026-03-17T00:25:05.195741+00:00",
      "duration_sec": 1.391,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id subagent_council_foundation_v14_materialization_tracer --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: subagent_council_foundation_v14_cache_board (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:05.195741+00:00",
      "finished_at_utc": "2026-03-17T00:25:07.094244+00:00",
      "duration_sec": 1.89,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id subagent_council_foundation_v14_cache_board --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: subagent_council_foundation_v14_risk_board (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:07.094244+00:00",
      "finished_at_utc": "2026-03-17T00:25:08.445920+00:00",
      "duration_sec": 1.36,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id subagent_council_foundation_v14_risk_board --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: subagent_council_foundation_v14_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:08.445920+00:00",
      "finished_at_utc": "2026-03-17T00:25:10.165618+00:00",
      "duration_sec": 1.719,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id subagent_council_foundation_v14_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: subagent_identity_certification_v14_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:10.166151+00:00",
      "finished_at_utc": "2026-03-17T00:25:13.375236+00:00",
      "duration_sec": 3.203,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id subagent_identity_certification_v14_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: subagent_identity_certification_v14_sync_bridge (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:13.376294+00:00",
      "finished_at_utc": "2026-03-17T00:25:15.065187+00:00",
      "duration_sec": 1.687,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id subagent_identity_certification_v14_sync_bridge --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: subagent_identity_certification_v14_materialization_tracer (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:15.066115+00:00",
      "finished_at_utc": "2026-03-17T00:25:16.492850+00:00",
      "duration_sec": 1.438,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id subagent_identity_certification_v14_materialization_tracer --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: subagent_identity_certification_v14_cache_board (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:16.498221+00:00",
      "finished_at_utc": "2026-03-17T00:25:18.444888+00:00",
      "duration_sec": 1.953,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id subagent_identity_certification_v14_cache_board --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: subagent_identity_certification_v14_risk_board (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:18.444888+00:00",
      "finished_at_utc": "2026-03-17T00:25:19.966671+00:00",
      "duration_sec": 1.515,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id subagent_identity_certification_v14_risk_board --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: subagent_identity_certification_v14_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:19.966671+00:00",
      "finished_at_utc": "2026-03-17T00:25:21.544618+00:00",
      "duration_sec": 1.579,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id subagent_identity_certification_v14_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: subagent_induction_proof_v14_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:21.545621+00:00",
      "finished_at_utc": "2026-03-17T00:25:23.239720+00:00",
      "duration_sec": 1.703,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id subagent_induction_proof_v14_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: subagent_induction_proof_v14_sync_bridge (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:23.239720+00:00",
      "finished_at_utc": "2026-03-17T00:25:24.998493+00:00",
      "duration_sec": 1.75,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id subagent_induction_proof_v14_sync_bridge --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: subagent_induction_proof_v14_materialization_tracer (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:24.999527+00:00",
      "finished_at_utc": "2026-03-17T00:25:26.447617+00:00",
      "duration_sec": 1.453,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id subagent_induction_proof_v14_materialization_tracer --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: subagent_induction_proof_v14_cache_board (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:26.447617+00:00",
      "finished_at_utc": "2026-03-17T00:25:28.264652+00:00",
      "duration_sec": 1.812,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id subagent_induction_proof_v14_cache_board --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: subagent_induction_proof_v14_risk_board (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:28.264652+00:00",
      "finished_at_utc": "2026-03-17T00:25:29.613823+00:00",
      "duration_sec": 1.344,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id subagent_induction_proof_v14_risk_board --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: subagent_induction_proof_v14_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:29.613823+00:00",
      "finished_at_utc": "2026-03-17T00:25:31.371222+00:00",
      "duration_sec": 1.766,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id subagent_induction_proof_v14_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: multi_instance_runtime_v14_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:31.371222+00:00",
      "finished_at_utc": "2026-03-17T00:25:32.921297+00:00",
      "duration_sec": 1.547,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id multi_instance_runtime_v14_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: multi_instance_runtime_v14_sync_bridge (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:32.921297+00:00",
      "finished_at_utc": "2026-03-17T00:25:34.799781+00:00",
      "duration_sec": 1.875,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id multi_instance_runtime_v14_sync_bridge --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: multi_instance_runtime_v14_materialization_tracer (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:34.804782+00:00",
      "finished_at_utc": "2026-03-17T00:25:36.242355+00:00",
      "duration_sec": 1.438,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id multi_instance_runtime_v14_materialization_tracer --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: multi_instance_runtime_v14_cache_board (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:36.244354+00:00",
      "finished_at_utc": "2026-03-17T00:25:37.672693+00:00",
      "duration_sec": 1.422,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id multi_instance_runtime_v14_cache_board --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: multi_instance_runtime_v14_risk_board (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:37.672693+00:00",
      "finished_at_utc": "2026-03-17T00:25:39.157090+00:00",
      "duration_sec": 1.484,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id multi_instance_runtime_v14_risk_board --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: multi_instance_runtime_v14_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:39.157090+00:00",
      "finished_at_utc": "2026-03-17T00:25:41.026384+00:00",
      "duration_sec": 1.875,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id multi_instance_runtime_v14_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: api_operator_mesh_v14_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:41.026384+00:00",
      "finished_at_utc": "2026-03-17T00:25:42.762173+00:00",
      "duration_sec": 1.734,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id api_operator_mesh_v14_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: api_operator_mesh_v14_sync_bridge (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:42.763152+00:00",
      "finished_at_utc": "2026-03-17T00:25:44.660223+00:00",
      "duration_sec": 1.891,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id api_operator_mesh_v14_sync_bridge --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: api_operator_mesh_v14_materialization_tracer (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:44.660223+00:00",
      "finished_at_utc": "2026-03-17T00:25:46.082616+00:00",
      "duration_sec": 1.422,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id api_operator_mesh_v14_materialization_tracer --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: api_operator_mesh_v14_cache_board (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:46.082616+00:00",
      "finished_at_utc": "2026-03-17T00:25:47.671205+00:00",
      "duration_sec": 1.594,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id api_operator_mesh_v14_cache_board --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: api_operator_mesh_v14_risk_board (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:47.671205+00:00",
      "finished_at_utc": "2026-03-17T00:25:48.990332+00:00",
      "duration_sec": 1.312,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id api_operator_mesh_v14_risk_board --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: api_operator_mesh_v14_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:48.990851+00:00",
      "finished_at_utc": "2026-03-17T00:25:51.197324+00:00",
      "duration_sec": 2.203,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id api_operator_mesh_v14_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: trinity_control_tower_v14_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:51.197324+00:00",
      "finished_at_utc": "2026-03-17T00:25:53.058224+00:00",
      "duration_sec": 1.859,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v14_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: trinity_control_tower_v14_sync_bridge (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:53.059245+00:00",
      "finished_at_utc": "2026-03-17T00:25:55.141548+00:00",
      "duration_sec": 2.078,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v14_sync_bridge --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: trinity_control_tower_v14_materialization_tracer (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:55.141548+00:00",
      "finished_at_utc": "2026-03-17T00:25:56.794956+00:00",
      "duration_sec": 1.657,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v14_materialization_tracer --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: trinity_control_tower_v14_cache_board (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:56.795471+00:00",
      "finished_at_utc": "2026-03-17T00:25:58.609715+00:00",
      "duration_sec": 1.812,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v14_cache_board --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: trinity_control_tower_v14_risk_board (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:25:58.609715+00:00",
      "finished_at_utc": "2026-03-17T00:26:00.666308+00:00",
      "duration_sec": 2.063,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v14_risk_board --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: trinity_control_tower_v14_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:00.666308+00:00",
      "finished_at_utc": "2026-03-17T00:26:03.207349+00:00",
      "duration_sec": 2.531,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id trinity_control_tower_v14_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: gmut_observable_mapping_v14_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:03.207349+00:00",
      "finished_at_utc": "2026-03-17T00:26:05.121905+00:00",
      "duration_sec": 1.922,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id gmut_observable_mapping_v14_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: gmut_observable_mapping_v14_sync_bridge (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:05.121905+00:00",
      "finished_at_utc": "2026-03-17T00:26:06.804749+00:00",
      "duration_sec": 1.687,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id gmut_observable_mapping_v14_sync_bridge --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: gmut_observable_mapping_v14_materialization_tracer (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:06.804749+00:00",
      "finished_at_utc": "2026-03-17T00:26:08.331202+00:00",
      "duration_sec": 1.453,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id gmut_observable_mapping_v14_materialization_tracer --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: gmut_observable_mapping_v14_cache_board (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:08.331202+00:00",
      "finished_at_utc": "2026-03-17T00:26:09.857421+00:00",
      "duration_sec": 1.531,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id gmut_observable_mapping_v14_cache_board --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: gmut_observable_mapping_v14_risk_board (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:09.857421+00:00",
      "finished_at_utc": "2026-03-17T00:26:11.525851+00:00",
      "duration_sec": 1.672,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id gmut_observable_mapping_v14_risk_board --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: gmut_observable_mapping_v14_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:11.525851+00:00",
      "finished_at_utc": "2026-03-17T00:26:14.842772+00:00",
      "duration_sec": 3.312,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id gmut_observable_mapping_v14_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: freedid_governance_alignment_v14_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:14.842772+00:00",
      "finished_at_utc": "2026-03-17T00:26:16.942311+00:00",
      "duration_sec": 2.094,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id freedid_governance_alignment_v14_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: freedid_governance_alignment_v14_sync_bridge (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:16.943310+00:00",
      "finished_at_utc": "2026-03-17T00:26:18.375975+00:00",
      "duration_sec": 1.438,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id freedid_governance_alignment_v14_sync_bridge --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: freedid_governance_alignment_v14_materialization_tracer (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:18.376976+00:00",
      "finished_at_utc": "2026-03-17T00:26:20.639297+00:00",
      "duration_sec": 2.265,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id freedid_governance_alignment_v14_materialization_tracer --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: freedid_governance_alignment_v14_cache_board (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:20.639297+00:00",
      "finished_at_utc": "2026-03-17T00:26:22.478595+00:00",
      "duration_sec": 1.844,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id freedid_governance_alignment_v14_cache_board --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: freedid_governance_alignment_v14_risk_board (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:22.478595+00:00",
      "finished_at_utc": "2026-03-17T00:26:24.426651+00:00",
      "duration_sec": 1.938,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id freedid_governance_alignment_v14_risk_board --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: freedid_governance_alignment_v14_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:24.427023+00:00",
      "finished_at_utc": "2026-03-17T00:26:26.529211+00:00",
      "duration_sec": 2.109,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id freedid_governance_alignment_v14_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: journey_lineage_inventory_v14_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:26.529211+00:00",
      "finished_at_utc": "2026-03-17T00:26:28.288981+00:00",
      "duration_sec": 1.766,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id journey_lineage_inventory_v14_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: journey_lineage_inventory_v14_sync_bridge (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:28.288981+00:00",
      "finished_at_utc": "2026-03-17T00:26:30.511006+00:00",
      "duration_sec": 2.218,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id journey_lineage_inventory_v14_sync_bridge --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: journey_lineage_inventory_v14_materialization_tracer (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:30.511006+00:00",
      "finished_at_utc": "2026-03-17T00:26:31.756306+00:00",
      "duration_sec": 1.235,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id journey_lineage_inventory_v14_materialization_tracer --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: journey_lineage_inventory_v14_cache_board (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:31.756306+00:00",
      "finished_at_utc": "2026-03-17T00:26:33.726042+00:00",
      "duration_sec": 1.984,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id journey_lineage_inventory_v14_cache_board --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: journey_lineage_inventory_v14_risk_board (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:33.726042+00:00",
      "finished_at_utc": "2026-03-17T00:26:35.213011+00:00",
      "duration_sec": 1.484,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id journey_lineage_inventory_v14_risk_board --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: journey_lineage_inventory_v14_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:35.213011+00:00",
      "finished_at_utc": "2026-03-17T00:26:36.940993+00:00",
      "duration_sec": 1.719,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id journey_lineage_inventory_v14_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: council_reflection_validation_v14_surface_audit (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:36.940993+00:00",
      "finished_at_utc": "2026-03-17T00:26:38.673796+00:00",
      "duration_sec": 1.735,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id council_reflection_validation_v14_surface_audit --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: council_reflection_validation_v14_sync_bridge (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:38.673796+00:00",
      "finished_at_utc": "2026-03-17T00:26:40.564071+00:00",
      "duration_sec": 1.89,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id council_reflection_validation_v14_sync_bridge --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: council_reflection_validation_v14_materialization_tracer (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:40.565070+00:00",
      "finished_at_utc": "2026-03-17T00:26:41.886563+00:00",
      "duration_sec": 1.328,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id council_reflection_validation_v14_materialization_tracer --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: council_reflection_validation_v14_cache_board (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:41.886563+00:00",
      "finished_at_utc": "2026-03-17T00:26:43.414499+00:00",
      "duration_sec": 1.532,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id council_reflection_validation_v14_cache_board --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: council_reflection_validation_v14_risk_board (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:43.418501+00:00",
      "finished_at_utc": "2026-03-17T00:26:45.175139+00:00",
      "duration_sec": 1.75,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id council_reflection_validation_v14_risk_board --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "expansion: council_reflection_validation_v14_gate (offline)",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:45.175139+00:00",
      "finished_at_utc": "2026-03-17T00:26:46.936476+00:00",
      "duration_sec": 1.765,
      "command": "python3 scripts/trinity_expansion_system_runner.py --system-id council_reflection_validation_v14_gate --profile-context recover --offline-only --fail-on-warn"
    },
    {
      "label": "trinity mandala scoreboard",
      "status": "PASS",
      "ok": true,
      "effective_success": true,
      "timed_out": false,
      "started_at_utc": "2026-03-17T00:26:47.019416+00:00",
      "finished_at_utc": "2026-03-17T00:26:49.904343+00:00",
      "duration_sec": 2.891,
      "command": "python3 scripts/trinity_mandala_scoreboard.py --fail-on-warn --suite-status docs/system-suite-status.json"
    }
  ]
}
```

