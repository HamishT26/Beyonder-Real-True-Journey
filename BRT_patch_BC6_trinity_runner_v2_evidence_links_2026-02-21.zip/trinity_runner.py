"""
trinity_runner.py
-----------------

Unified Trinity runner (Mind / Body / Heart) with stable artifact contract.

Runs:
- Body:  body_track_runner.py
- Mind:  mind_track_runner.py
- Heart: heart_track_runner.py

Writes:
- docs/trinity-runs/<stamp>-trinity.{json,md}
- docs/trinity-latest.{json,md}
- docs/trinity-history.jsonl (append-only)

Status semantics:
- PASS: all non-SKIP lanes PASS
- WARN: no lane FAIL, but at least one WARN/SKIP
- FAIL: any lane FAIL
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class Lane:
    lane: str
    command: List[str]
    returncode: int
    duration_seconds: float
    status: str  # PASS|WARN|FAIL|SKIP
    latest_json: Optional[str] = None
    latest_md: Optional[str] = None
    notes: Optional[str] = None


def _run(cmd: List[str]) -> tuple[int, float, str, str]:
    started = time.perf_counter()
    p = subprocess.run(cmd, capture_output=True, text=True, check=False)
    dur = time.perf_counter() - started
    return int(p.returncode), dur, (p.stdout or "").strip(), (p.stderr or "").strip()


def _read_json(path: Path) -> Optional[Dict[str, Any]]:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None


def _status_from_latest(latest: Optional[Dict[str, Any]]) -> Optional[str]:
    if not latest:
        return None
    s = latest.get("overall_status")
    if isinstance(s, str) and s:
        return s
    return None


def _lane_status_default(script_exists: bool, rc: int, derived: Optional[str]) -> str:
    if not script_exists:
        return "SKIP"
    if derived in ("PASS", "WARN", "FAIL"):
        return derived
    return "PASS" if rc == 0 else "FAIL"


def _overall(lanes: List[Lane]) -> str:
    if any(l.status == "FAIL" for l in lanes):
        return "FAIL"
    if all(l.status == "PASS" for l in lanes if l.status != "SKIP") and not any(l.status in ("WARN", "SKIP") for l in lanes):
        return "PASS"
    return "WARN"


def _md(payload: Dict[str, Any]) -> str:
    lines = [
        "# Trinity Unified Run Report",
        "",
        f"- generated_utc: `{payload['generated_utc']}`",
        f"- overall_status: **{payload['overall_status']}**",
        "",
        "## Lanes",
        "| lane | status | returncode | duration_seconds | latest_json | latest_md | command |",
        "|---|---|---:|---:|---|---|---|",
    ]
    for l in payload["lanes"]:
        cmd = " ".join(l.get("command", []))
        lines.append(
            f"| {l.get('lane')} | {l.get('status')} | {l.get('returncode')} | {float(l.get('duration_seconds',0.0)):.3f} | "
            f"{l.get('latest_json','-')} | {l.get('latest_md','-')} | `{cmd}` |"
        )
    if payload.get("evidence_links_latest_json"):
        lines += ["", "## Evidence links", f"- evidence_links_latest_json: `{payload['evidence_links_latest_json']}`"]
    return "\n".join(lines).strip() + "\n"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--reports-dir", default="docs/trinity-runs")
    ap.add_argument("--latest-json", default="docs/trinity-latest.json")
    ap.add_argument("--latest-md", default="docs/trinity-latest.md")
    ap.add_argument("--history-jsonl", default="docs/trinity-history.jsonl")

    ap.add_argument("--skip-body", action="store_true")
    ap.add_argument("--skip-mind", action="store_true")
    ap.add_argument("--skip-heart", action="store_true")

    ap.add_argument("--body-benchmark-profile", default="standard", choices=("quick", "standard", "strict"))
    ap.add_argument("--mind-gammas", type=float, nargs="+", default=[0.0, 0.05, 0.1, 0.2])

    ap.add_argument("--evidence-links-latest-json", default="docs/evidence-links-latest.json")
    args = ap.parse_args()

    root = Path(".")
    docs = root / "docs"
    docs.mkdir(exist_ok=True)

    reports_dir = root / args.reports_dir
    reports_dir.mkdir(parents=True, exist_ok=True)

    generated_utc = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    lanes: List[Lane] = []

    def run_lane(lane_name: str, script: str, cmd: List[str], latest_json: str, latest_md: str, skip: bool) -> None:
        sp = root / script
        if skip:
            lanes.append(Lane(lane=lane_name, command=cmd, returncode=0, duration_seconds=0.0, status="SKIP",
                              latest_json=latest_json, latest_md=latest_md, notes="skipped_by_flag"))
            return
        if not sp.exists():
            lanes.append(Lane(lane=lane_name, command=cmd, returncode=0, duration_seconds=0.0, status="SKIP",
                              latest_json=latest_json, latest_md=latest_md, notes="script_missing"))
            return
        rc, dur, _out, _err = _run(cmd)
        latest = _read_json(root / latest_json)
        derived = _status_from_latest(latest)
        status = _lane_status_default(True, rc, derived)
        lanes.append(Lane(lane=lane_name, command=cmd, returncode=rc, duration_seconds=dur, status=status,
                          latest_json=latest_json, latest_md=latest_md))

    # Body
    run_lane(
        "Body",
        "body_track_runner.py",
        [sys.executable, "body_track_runner.py", "--benchmark-profile", args.body_benchmark_profile, "--fail-on-benchmark"],
        "docs/body-track-smoke-latest.json",
        "docs/body-track-smoke-latest.md",
        args.skip_body,
    )

    # Mind
    run_lane(
        "Mind",
        "mind_track_runner.py",
        [sys.executable, "mind_track_runner.py", "--gammas", *[str(g) for g in args.mind_gammas]],
        "docs/mind-track-smoke-latest.json",
        "docs/mind-track-smoke-latest.md",
        args.skip_mind,
    )

    # Heart
    run_lane(
        "Heart",
        "heart_track_runner.py",
        [sys.executable, "heart_track_runner.py"],
        "docs/heart-track-smoke-latest.json",
        "docs/heart-track-smoke-latest.md",
        args.skip_heart,
    )

    overall_status = _overall(lanes)

    payload: Dict[str, Any] = {
        "generated_utc": generated_utc,
        "overall_status": overall_status,
        "lanes": [asdict(l) for l in lanes],
    }

    ev = root / args.evidence_links_latest_json
    if ev.exists():
        payload["evidence_links_latest_json"] = str(ev)

    timestamped_json = reports_dir / f"{stamp}-trinity.json"
    timestamped_md = reports_dir / f"{stamp}-trinity.md"
    latest_json = root / args.latest_json
    latest_md = root / args.latest_md
    history = root / args.history_jsonl

    latest_json.parent.mkdir(parents=True, exist_ok=True)
    latest_md.parent.mkdir(parents=True, exist_ok=True)
    history.parent.mkdir(parents=True, exist_ok=True)

    timestamped_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    timestamped_md.write_text(_md(payload), encoding="utf-8")
    latest_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    latest_md.write_text(_md(payload), encoding="utf-8")
    with history.open("a", encoding="utf-8") as h:
        h.write(json.dumps(payload) + "\n")

    print(f"overall_status={overall_status}")
    print(f"timestamped_json={timestamped_json}")
    print(f"timestamped_md={timestamped_md}")
    print(f"latest_json={latest_json}")
    print(f"latest_md={latest_md}")
    return 0 if overall_status in ("PASS", "WARN") else 1


if __name__ == "__main__":
    raise SystemExit(main())
