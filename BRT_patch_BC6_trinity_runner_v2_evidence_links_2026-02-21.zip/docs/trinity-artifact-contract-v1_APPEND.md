
## Evidence links (optional)
If present after a run:
- `docs/evidence-links-latest.json` — generated from `claim_to_pdf_links_v0.md` + registry + latest run.
- The Trinity payload may include `evidence_links_latest_json` pointing to it.

