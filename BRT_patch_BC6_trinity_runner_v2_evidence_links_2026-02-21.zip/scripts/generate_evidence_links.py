"""
scripts/generate_evidence_links.py
----------------------------------

Generate docs/evidence-links-latest.json from:
- docs/claim_to_pdf_links_v0.md   (human curated anchors)
- docs/journey_pdf_registry_v0.json (Drive PDF registry)
- docs/trinity-latest.json (runner outputs, optional)

This is deliberately simple and robust: it parses Markdown bullets/rows loosely
and produces a stable JSON object for downstream tooling.

Expected conventions in claim_to_pdf_links_v0.md:
- Each entry begins with an ID token like:
  - CLAIM-001:
  - GOV-005:
  - PRINCIPLE-001:
- Within the entry, include PDF references like:
  - PDF:v34 p12
  - PDF:v33 section "X"
"""

from __future__ import annotations

import argparse
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


ID_RE = re.compile(r"^\s*([A-Z]+-\d{3,})\s*:\s*(.+?)\s*$")
PDF_REF_RE = re.compile(r"\bPDF:(v\d+)\b([^\\n]*)", re.IGNORECASE)


def _read_json(path: Path) -> Optional[Dict[str, Any]]:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None


def _registry_map(registry: Dict[str, Any]) -> Dict[str, str]:
    m: Dict[str, str] = {}
    for e in registry.get("entries", []):
        v = str(e.get("version_label", "")).strip()
        url = str(e.get("drive_url", "")).strip()
        if v and url:
            m[v] = url
    return m


def _parse_links(md_text: str) -> List[Dict[str, Any]]:
    entries: List[Dict[str, Any]] = []
    current: Optional[Dict[str, Any]] = None

    for line in md_text.splitlines():
        m = ID_RE.match(line)
        if m:
            # flush
            if current:
                entries.append(current)
            _id = m.group(1).strip()
            title = m.group(2).strip()
            kind = "claim"
            if _id.startswith("GOV-"):
                kind = "control"
            elif _id.startswith("PRINCIPLE-"):
                kind = "principle"
            current = {"id": _id, "kind": kind, "title": title, "raw_lines": [line]}
            continue

        if current is not None:
            if line.strip() == "":
                current["raw_lines"].append(line)
            else:
                current["raw_lines"].append(line)

    if current:
        entries.append(current)

    return entries


def _anchors_for_entry(entry: Dict[str, Any], version_to_url: Dict[str, str], trinity_latest: Optional[Dict[str, Any]]) -> List[Dict[str, str]]:
    anchors: List[Dict[str, str]] = []
    raw = "\n".join(entry.get("raw_lines", []))

    for pm in PDF_REF_RE.finditer(raw):
        ver = pm.group(1).lower()  # v34
        tail = (pm.group(2) or "").strip()
        url = version_to_url.get(ver, "")
        ref = f"{ver} {tail}".strip()
        if url:
            anchors.append({"type": "pdf", "ref": url, "details": ref})
        else:
            anchors.append({"type": "pdf", "ref": ref, "details": "no_drive_url_in_registry"})

    # runner outputs: attach latest artifacts as a convenience
    if trinity_latest:
        anchors.append({"type": "runner_output", "ref": "docs/trinity-latest.json", "details": "latest unified run"})
        for lane in trinity_latest.get("lanes", []):
            lj = lane.get("latest_json")
            if lj:
                anchors.append({"type": "runner_output", "ref": str(lj), "details": f"{lane.get('lane')} latest json"})

    if not anchors:
        anchors.append({"type": "doc", "ref": "docs/claim_to_pdf_links_v0.md", "details": "no_pdf_refs_parsed"})

    return anchors


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--links-md", default="docs/claim_to_pdf_links_v0.md")
    ap.add_argument("--registry-json", default="docs/journey_pdf_registry_v0.json")
    ap.add_argument("--trinity-latest", default="docs/trinity-latest.json")
    ap.add_argument("--out-json", default="docs/evidence-links-latest.json")
    args = ap.parse_args()

    root = Path(".")
    links_path = root / args.links_md
    reg_path = root / args.registry_json
    tri_path = root / args.trinity_latest
    out_path = root / args.out_json

    reg = _read_json(reg_path) or {"entries": []}
    version_to_url = _registry_map(reg)
    tri = _read_json(tri_path)

    if not links_path.exists():
        payload = {"generated_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
                   "entries": []}
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        print(f"wrote={out_path} (empty; missing links md)")
        return 0

    entries_raw = _parse_links(links_path.read_text(encoding="utf-8"))
    out_entries: List[Dict[str, Any]] = []
    for e in entries_raw:
        anchors = _anchors_for_entry(e, version_to_url, tri)
        out_entries.append({
            "id": e["id"],
            "kind": e["kind"],
            "title": e["title"],
            "anchors": anchors
        })

    payload = {
        "generated_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "entries": out_entries
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(f"wrote={out_path} entries={len(out_entries)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
