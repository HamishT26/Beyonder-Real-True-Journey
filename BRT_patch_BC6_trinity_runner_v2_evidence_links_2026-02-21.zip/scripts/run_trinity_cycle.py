"""
scripts/run_trinity_cycle.py
----------------------------

One-command cycle runner:
- ensures docs dirs
- runs trinity_runner.py
- generates evidence-links-latest.json (if script present)
- appends a run registry entry (docs/run-registry.jsonl)
- renders a lightweight index page (docs/TRINITY_INDEX.md)
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, List, Optional


def _run(cmd: List[str]) -> int:
    p = subprocess.run(cmd, check=False)
    return int(p.returncode)


def _read_json(path: Path) -> Optional[Dict[str, Any]]:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None


def _render_index(history_jsonl: Path, out_md: Path, max_rows: int = 40) -> None:
    if not history_jsonl.exists():
        out_md.write_text("# Trinity Index\n\nNo runs yet.\n", encoding="utf-8")
        return
    rows = []
    for line in history_jsonl.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            continue

    rows = list(reversed(rows))[:max_rows]
    lines = [
        "# Trinity Index",
        "",
        f"Last updated: `{datetime.now(timezone.utc).replace(microsecond=0).isoformat()}`",
        "",
        "| generated_utc | overall_status | body | mind | heart | evidence_links |",
        "|---|---|---|---|---|---|",
    ]

    def lane_status(payload: Dict[str, Any], lane_name: str) -> str:
        for l in payload.get("lanes", []):
            if str(l.get("lane")) == lane_name:
                return str(l.get("status"))
        return "-"

    for r in rows:
        generated = str(r.get("generated_utc", "-"))
        overall = str(r.get("overall_status", "-"))
        body = lane_status(r, "Body")
        mind = lane_status(r, "Mind")
        heart = lane_status(r, "Heart")
        ev = r.get("evidence_links_latest_json", "-")
        lines.append(f"| {generated} | **{overall}** | {body} | {mind} | {heart} | {ev} |")

    out_md.write_text("\n".join(lines).strip() + "\n", encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", default="standard", choices=("quick", "standard", "strict"))
    ap.add_argument("--gammas", type=float, nargs="+", default=[0.0, 0.05, 0.1, 0.2])
    args = ap.parse_args()

    root = Path(".")
    docs = root / "docs"
    docs.mkdir(exist_ok=True)

    # Run Trinity
    cmd = [
        sys.executable,
        "trinity_runner.py",
        "--body-benchmark-profile",
        args.profile,
        "--mind-gammas",
        *[str(g) for g in args.gammas],
    ]
    rc = _run(cmd)

    # Generate evidence links (optional)
    ev_script = root / "scripts/generate_evidence_links.py"
    if ev_script.exists():
        _run([sys.executable, str(ev_script)])

    # Append registry entry (compact)
    latest = _read_json(docs / "trinity-latest.json") or {}
    run_registry = docs / "run-registry.jsonl"
    run_registry.parent.mkdir(parents=True, exist_ok=True)
    entry = {
        "generated_utc": latest.get("generated_utc") or datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "overall_status": latest.get("overall_status", "UNKNOWN"),
        "lanes": latest.get("lanes", []),
        "evidence_links_latest_json": latest.get("evidence_links_latest_json", "docs/evidence-links-latest.json"),
    }
    with run_registry.open("a", encoding="utf-8") as h:
        h.write(json.dumps(entry) + "\n")

    # Render index from trinity history (preferred) else run registry
    history = docs / "trinity-history.jsonl"
    index_out = docs / "TRINITY_INDEX.md"
    if history.exists():
        _render_index(history, index_out)
    else:
        _render_index(run_registry, index_out)

    return rc


if __name__ == "__main__":
    raise SystemExit(main())
