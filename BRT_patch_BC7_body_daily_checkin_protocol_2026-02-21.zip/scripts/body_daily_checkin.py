"""
scripts/body_daily_checkin.py
-----------------------------

Interactive daily body check-in that writes append-only JSONL and a latest snapshot.

Writes:
- docs/body-track-daily-checkins.jsonl   (append-only)
- docs/body-track-daily-latest.json      (latest snapshot)
- docs/body-track-daily-latest.md        (human summary)

Inputs:
- docs/body-track-daily-checkin-template.json (optional template)

No external dependencies.
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


def _now_utc() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _load_template(path: Path) -> Optional[Dict[str, Any]]:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None


def _prompt(field: Dict[str, Any]) -> Any:
    key = field.get("key")
    ftype = field.get("type")
    example = field.get("example")
    unit = field.get("unit")
    scale = field.get("scale")

    suffix = []
    if unit:
        suffix.append(unit)
    if scale:
        suffix.append(scale)
    if example is not None:
        suffix.append(f"e.g. {example}")
    suffix_str = f" ({', '.join(suffix)})" if suffix else ""

    while True:
        raw = input(f"{key}{suffix_str}: ").strip()
        if raw == "":
            return None
        if ftype == "int":
            try:
                return int(raw)
            except ValueError:
                print("Please enter an integer (or blank).")
        elif ftype == "number":
            try:
                return float(raw)
            except ValueError:
                print("Please enter a number (or blank).")
        else:
            return raw


def _render_md(payload: Dict[str, Any]) -> str:
    lines = [
        "# Body Daily Check-in (latest)",
        "",
        f"- generated_utc: `{payload.get('generated_utc','-')}`",
        "",
        "## Scores",
    ]
    fields = payload.get("fields", {})
    key_order = [
        "sleep_hours","sleep_quality","energy","mood","stress","hydration_litres","steps","protein_grams",
        "mobility_minutes","strength_minutes","cardio_minutes","pain_level",
    ]
    for k in key_order:
        if k in fields and fields[k] is not None:
            lines.append(f"- {k}: `{fields[k]}`")
    notes = fields.get("notes")
    if notes:
        lines += ["", "## Notes", notes]
    return "\n".join(lines).strip() + "\n"


def main() -> int:
    root = Path(".")
    docs = root / "docs"
    docs.mkdir(exist_ok=True)

    template_path = docs / "body-track-daily-checkin-template.json"
    template = _load_template(template_path) or {"fields": []}
    fields_list: List[Dict[str, Any]] = template.get("fields", [])

    print("Body Daily Check-in (blank to skip a field)")
    collected: Dict[str, Any] = {}
    for f in fields_list:
        key = str(f.get("key", "")).strip()
        if not key:
            continue
        collected[key] = _prompt(f)

    payload = {
        "generated_utc": _now_utc(),
        "version": "v1",
        "fields": collected,
    }

    jsonl_path = docs / "body-track-daily-checkins.jsonl"
    latest_json = docs / "body-track-daily-latest.json"
    latest_md = docs / "body-track-daily-latest.md"

    with jsonl_path.open("a", encoding="utf-8") as h:
        h.write(json.dumps(payload) + "\n")

    latest_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    latest_md.write_text(_render_md(payload), encoding="utf-8")

    print(f"wrote={jsonl_path}")
    print(f"wrote={latest_json}")
    print(f"wrote={latest_md}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
