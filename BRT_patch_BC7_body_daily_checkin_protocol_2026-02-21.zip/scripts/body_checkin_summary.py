"""
scripts/body_checkin_summary.py
-------------------------------

Summarize body daily check-ins into a rolling overview.

Reads:
- docs/body-track-daily-checkins.jsonl

Writes:
- docs/body-track-daily-summary-latest.json
- docs/body-track-daily-summary-latest.md
"""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


NUM_KEYS = [
    "sleep_hours", "sleep_quality", "energy", "mood", "stress",
    "hydration_litres", "steps", "protein_grams",
    "mobility_minutes", "strength_minutes", "cardio_minutes", "pain_level"
]


def _now_utc() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _mean(values: List[float]) -> Optional[float]:
    if not values:
        return None
    return sum(values) / float(len(values))


def _render_md(payload: Dict[str, Any]) -> str:
    lines = [
        "# Body Daily Summary (latest)",
        "",
        f"- generated_utc: `{payload.get('generated_utc','-')}`",
        f"- window_days: `{payload.get('window_days','-')}`",
        f"- samples: `{payload.get('samples','-')}`",
        "",
        "## Averages",
    ]
    avgs = payload.get("averages", {})
    for k, v in avgs.items():
        if v is not None:
            lines.append(f"- {k}: `{v:.3f}`")
    return "\n".join(lines).strip() + "\n"


def main() -> int:
    root = Path(".")
    docs = root / "docs"
    src = docs / "body-track-daily-checkins.jsonl"
    if not src.exists():
        print("missing: docs/body-track-daily-checkins.jsonl")
        return 0

    rows: List[Dict[str, Any]] = []
    for line in src.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            continue

    # Use last 7 entries as a simple rolling window
    window = rows[-7:]
    samples = len(window)

    series: Dict[str, List[float]] = {k: [] for k in NUM_KEYS}
    for r in window:
        fields = r.get("fields", {})
        for k in NUM_KEYS:
            v = fields.get(k)
            if isinstance(v, (int, float)):
                series[k].append(float(v))

    averages = {k: _mean(vs) for k, vs in series.items()}

    payload = {
        "generated_utc": _now_utc(),
        "window_days": 7,
        "samples": samples,
        "averages": averages,
    }

    out_json = docs / "body-track-daily-summary-latest.json"
    out_md = docs / "body-track-daily-summary-latest.md"
    out_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    out_md.write_text(_render_md(payload), encoding="utf-8")

    print(f"wrote={out_json}")
    print(f"wrote={out_md}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
