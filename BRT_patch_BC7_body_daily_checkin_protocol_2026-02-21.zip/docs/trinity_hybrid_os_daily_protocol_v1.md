# Trinity Hybrid OS Daily Protocol v1

generated: `2026-02-21T05:34:13Z`

This is the simplest daily cadence that keeps **Mind / Body / Heart** in sync without overload.

## 1) Body (2–5 minutes)
Run:
- `python scripts/body_daily_checkin.py`

Optional:
- `python scripts/body_checkin_summary.py`

Outputs:
- `docs/body-track-daily-latest.json/.md`
- `docs/body-track-daily-checkins.jsonl`
- `docs/body-track-daily-summary-latest.json/.md`

## 2) Trinity Run (1–3 minutes)
Run:
- `python scripts/run_trinity_cycle.py --profile standard`

Outputs:
- `docs/trinity-latest.json/.md`
- `docs/TRINITY_INDEX.md`
- lane smoke reports for Body/Mind/Heart

## 3) Heart reflection (30–90 seconds)
Answer one question in `docs/heart-notes.md` (optional):
- “What value did I protect today?”
- “Where did I trade clarity for speed?”
- “What boundary keeps the system safe?”

## 4) Mind reflection (30–90 seconds)
Answer one question in `docs/mind-notes.md` (optional):
- “What prediction can be tested next?”
- “What changed in my assumptions today?”

## 5) Archive (weekly or after milestones)
Zip the patch artifacts and upload to Drive `patches/`.
