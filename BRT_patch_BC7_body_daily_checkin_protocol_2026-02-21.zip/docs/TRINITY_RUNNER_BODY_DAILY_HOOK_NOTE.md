# Trinity Runner v2: Body Daily Hook (optional)

If `docs/body-track-daily-latest.json` exists, Trinity can include it as:
- `body_daily_latest_json`: "docs/body-track-daily-latest.json"

This is optional and safe to ignore if not present.
generated: `2026-02-21T05:34:13Z`
