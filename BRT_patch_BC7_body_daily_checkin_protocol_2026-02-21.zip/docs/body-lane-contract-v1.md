# Body Lane Contract v1

generated: `2026-02-21T05:34:13Z`

This defines the minimal contract for **Body** artifacts, so the Trinity runner can link them consistently.

## Daily check-in artifacts
- `docs/body-track-daily-latest.json`
- `docs/body-track-daily-latest.md`
- `docs/body-track-daily-checkins.jsonl` (append-only)
- `docs/body-track-daily-summary-latest.json` (optional)
- `docs/body-track-daily-summary-latest.md` (optional)

### body-track-daily-latest.json schema (minimum)
```json
{
  "generated_utc": "ISO-8601 UTC string",
  "version": "v1",
  "fields": {
    "sleep_hours": 7.5,
    "sleep_quality": 7,
    "energy": 6,
    "mood": 7,
    "stress": 4,
    "hydration_litres": 2.0,
    "steps": 8000,
    "protein_grams": 120,
    "mobility_minutes": 10,
    "strength_minutes": 20,
    "cardio_minutes": 15,
    "pain_level": 1,
    "notes": "string"
  }
}
```

## Relationship to existing body_track_runner.py
- The daily check-in is **subjective + lifestyle**.
- The existing runner is **objective + benchmark/test**.
- Both are valuable: the Trinity Hybrid OS uses both to correlate “how the body feels” with “what the system can do.”
