# Beyonder-Real-True_System — Drive Archive Index

This file is meant to live **inside** the Drive folder as the top “index”.

Drive folder:
- https://drive.google.com/drive/folders/1CiYdIhc2Anj7IMUQofS5I6Jjk0TgJjal

## What goes where
- `patches/` → patch bundles to apply into GitHub later
- `capsules/` → continuity capsules & session logs
- `runs/` → runner outputs (consider weekly zips)
- `pdfs/` → Journey PDFs + sources
- `exports/` → repomix snapshots, release bundles, backups

## Current upload targets (recommended)
Put these in `patches/`:
- `BRT_patch_trinity_mind_drive_registry_BC3_2026-02-21.zip`
- `BRT_drive_sync_kit_2026-02-21.zip`

## Cycle cadence suggestion
Daily (or per session):
1) run `python3 trinity_runner.py`
2) review `docs/trinity-latest.md`
3) if changes were made, package a patch zip
4) upload patch zip to Drive `patches/`
