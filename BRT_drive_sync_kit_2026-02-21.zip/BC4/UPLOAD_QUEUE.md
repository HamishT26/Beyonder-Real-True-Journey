# Upload Queue → Google Drive Archive

Target folder: https://drive.google.com/drive/folders/1CiYdIhc2Anj7IMUQofS5I6Jjk0TgJjal

## Priority 1 (today)
1. `BRT_patch_trinity_mind_drive_registry_BC3_2026-02-21.zip`
2. `BRT_patch_trinity_mind_drive_registry_2026-02-21.zip` (optional legacy)
3. `BRT_drive_sync_kit_2026-02-21.zip` (this kit)

## Verification checklist (after upload)
- Files visible in Drive under `patches/`
- Open each zip in Drive preview (or download once) to confirm integrity
- Keep at least one “latest” bundle (BC3) and one “history” bundle

## Suggested naming rule
`YYYY-MM-DD__BRT__<type>__<tag>.zip`
