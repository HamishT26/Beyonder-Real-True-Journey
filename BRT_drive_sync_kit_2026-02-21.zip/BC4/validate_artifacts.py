#!/usr/bin/env python3
"""Validate runner artifacts against JSON Schemas.

Usage:
  python3 validate_artifacts.py --trinity docs/trinity-latest.json
  python3 validate_artifacts.py --mind docs/mind-track-smoke-latest.json
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import jsonschema

ROOT = Path(__file__).resolve().parent
SCHEMAS = ROOT / "schemas"

def _load(path: Path) -> object:
    return json.loads(path.read_text(encoding="utf-8"))

def _validate(instance: object, schema_path: Path) -> None:
    schema = _load(schema_path)
    jsonschema.validate(instance=instance, schema=schema)

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--trinity", type=str, default=None, help="Path to trinity-latest.json")
    parser.add_argument("--mind", type=str, default=None, help="Path to mind-track-smoke-latest.json")
    args = parser.parse_args()

    ok = True
    if args.trinity:
        p = Path(args.trinity)
        try:
            _validate(_load(p), SCHEMAS / "trinity_run_schema_v1.json")
            print(f"PASS trinity schema: {p}")
        except Exception as exc:
            ok = False
            print(f"FAIL trinity schema: {p} -> {exc}")
    if args.mind:
        p = Path(args.mind)
        try:
            _validate(_load(p), SCHEMAS / "mind_track_smoke_schema_v1.json")
            print(f"PASS mind schema: {p}")
        except Exception as exc:
            ok = False
            print(f"FAIL mind schema: {p} -> {exc}")

    return 0 if ok else 1

if __name__ == "__main__":
    raise SystemExit(main())
