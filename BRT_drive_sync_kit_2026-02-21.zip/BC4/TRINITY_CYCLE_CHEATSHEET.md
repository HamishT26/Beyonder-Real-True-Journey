# Trinity Cycle Cheatsheet

## One-cycle run
1) `python3 body_track_runner.py --benchmark-profile standard --fail-on-benchmark`
2) `python3 mind_track_runner.py`
3) `python3 freed_id_control_verifier.py`
4) `python3 freed_id_minimum_disclosure_verifier.py`
5) `python3 trinity_runner.py`

## What to inspect
- `docs/trinity-latest.md` (summary)
- Body: `docs/body-track-smoke-latest.md`
- Mind: `docs/mind-track-smoke-latest.md`
- Heart: `docs/heart-track-governance-latest.md`, `docs/heart-track-min-disclosure-latest.md`

## If anything fails
- Treat FAIL as “stop and fix”
- Treat WARN as “investigate; can proceed if understood”
- Treat SKIP as “missing lane; apply patch or add inputs”
