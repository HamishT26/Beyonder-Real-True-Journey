# Trinity Index (Single Pane of Glass)

This page is meant to be the “one place” you check each cycle.

## Run entrypoints
- Body lane: `python3 body_track_runner.py`
- Heart lane (minimum): `python3 freed_id_control_verifier.py` + `python3 freed_id_minimum_disclosure_verifier.py`
- Mind lane: `python3 mind_track_runner.py`
- Unified: `python3 trinity_runner.py`

## Latest artifacts (expected)
### Body
- `docs/body-track-smoke-latest.json`
- `docs/body-track-smoke-latest.md`
- `docs/body-track-metrics-latest.json`
- `docs/body-track-benchmark-latest.json`

### Mind
- `docs/mind-track-smoke-latest.json`
- `docs/mind-track-smoke-latest.md`
- `docs/mind-track-metrics-latest.json`

### Heart
- `docs/heart-track-governance-latest.json`
- `docs/heart-track-governance-latest.md`
- `docs/heart-track-min-disclosure-latest.json`
- `docs/heart-track-min-disclosure-latest.md`

### Trinity (unified)
- `docs/trinity-latest.json`
- `docs/trinity-latest.md`
- `docs/trinity-history.jsonl`

## Evidence rule
No claim maturity upgrade without:
- runnable code OR
- test/verifier output OR
- cited external dataset ingestion step.
