# Beyonder-Real-True_System Drive Folder Structure (v1)

Root: `Beyonder-Real-True_System/` (Drive folder id `1CiYdIhc2Anj7IMUQofS5I6Jjk0TgJjal`)

## Subfolders
- `patches/`
  - patch zips that you later apply/commit into GitHub.
- `capsules/`
  - continuity capsules, session logs, identity/role anchors.
- `runs/`
  - runner outputs. Suggested: zip weekly/monthly to avoid file explosion.
- `pdfs/`
  - Journey PDFs and other sources.
- `exports/`
  - repomix exports, “release” bundles, snapshots.

## Conventions
- Always keep one “latest” zip in `patches/` and archive older ones.
- Prefer timestamp prefixes: `20260221T061500Z-...`
