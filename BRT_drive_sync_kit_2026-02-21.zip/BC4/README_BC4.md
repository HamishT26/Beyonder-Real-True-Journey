# BC4: Drive Archive Sync + Trinity Index (2026-02-21 NZ)

This capsule extends the B+C work by:
- binding the canonical Google Drive archive folder for Beyonder-Real-True_System,
- providing a recommended Drive folder structure,
- providing an upload queue + verification checklist,
- adding a Trinity "index" page (single pane of glass),
- adding a lightweight helper to run a Trinity cycle and print next actions.

## Canonical Drive archive
- Folder: Beyonder-Real-True_System/
- ID: `1CiYdIhc2Anj7IMUQofS5I6Jjk0TgJjal`
- URL: https://drive.google.com/drive/folders/1CiYdIhc2Anj7IMUQofS5I6Jjk0TgJjal

## Recommended Drive structure (create these subfolders inside the folder)
- `patches/` (zip patches to commit later)
- `capsules/` (continuity capsules)
- `runs/` (timestamped runner outputs, optionally zipped weekly)
- `pdfs/` (Journey PDFs, source documents)
- `exports/` (repomix snapshots, release bundles)

## Local workspace
- Canonical local archive root: `/mnt/data/Beyonder-Real-True_System/`
