#!/usr/bin/env python3
"""Run a Trinity cycle and print next actions.

This is a thin wrapper that:
- runs `trinity_runner.py` (if present),
- prints where the latest artifacts should be,
- reminds to upload patch bundles to Drive.
"""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

def main() -> int:
    repo_root = Path(".")
    runner = repo_root / "trinity_runner.py"
    if not runner.exists():
        print("SKIP: trinity_runner.py not found in repo yet (apply patch first).")
        print("Next: add mind_track_runner.py + trinity_runner.py then rerun.")
        return 0

    cmd = [sys.executable, str(runner)]
    completed = subprocess.run(cmd, check=False)
    print("")
    print("Expected latest artifacts:")
    for p in [
        "docs/trinity-latest.json",
        "docs/trinity-latest.md",
        "docs/body-track-smoke-latest.json",
        "docs/mind-track-smoke-latest.json",
        "docs/heart-track-governance-latest.json",
    ]:
        print(f"- {p}")
    return completed.returncode

if __name__ == "__main__":
    raise SystemExit(main())
