#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path

def main() -> int:
    path = Path("docs/journey_pdf_registry_v0.json")
    if not path.exists():
        print(f"Missing: {path}")
        return 1
    payload = json.loads(path.read_text(encoding="utf-8"))
    entries = payload.get("entries", [])
    if not isinstance(entries, list) or not entries:
        print("No entries.")
        return 1

    lines = []
    lines.append("# Journey PDF Registry (Rendered)\n")
    lines.append("| version | agent | title | drive_file_id | drive_url | ingestion_status |")
    lines.append("|---|---|---|---|---|---|")
    for e in entries:
        version = str(e.get("version_label",""))
        agent = str(e.get("agent_name",""))
        title = str(e.get("title",""))
        fid = str(e.get("drive_file_id",""))
        url = str(e.get("drive_url",""))
        status = str(e.get("ingestion_status",""))
        lines.append(f"| {version} | {agent} | {title} | {fid} | {url} | {status} |")

    out = Path("docs/journey_pdf_registry_v0.md")
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"wrote {out}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
