"""
trinity_runner.py
-----------------

Unified Trinity runner (Mind / Body / Heart).

Runs:
- Body:  body_track_runner.py
- Mind:  mind_track_runner.py
- Heart: freed_id_control_verifier.py (GOV-005) + freed_id_minimum_disclosure_verifier.py (GOV-002)

Then writes a single Trinity summary:
- docs/trinity-runs/<stamp>-trinity.{json,md}
- docs/trinity-latest.{json,md}
- docs/trinity-history.jsonl
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional


@dataclass
class LaneResult:
    lane: str
    command: List[str]
    returncode: int
    duration_seconds: float
    status: str
    latest_json: Optional[str] = None
    latest_md: Optional[str] = None


def _run(cmd: List[str]) -> tuple[int, float, str, str]:
    started = time.perf_counter()
    completed = subprocess.run(cmd, capture_output=True, text=True, check=False)
    duration = time.perf_counter() - started
    return completed.returncode, duration, (completed.stdout or "").strip(), (completed.stderr or "").strip()


def _read_json_if_exists(path: Path) -> Optional[Dict[str, object]]:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None


def _derive_status(default: str, latest_payload: Optional[Dict[str, object]]) -> str:
    if not latest_payload:
        return default
    return str(latest_payload.get("overall_status", default))


def _build_markdown(generated_utc: str, overall_status: str, lanes: List[LaneResult]) -> str:
    lines = [
        "# Trinity Unified Run Report",
        "",
        f"- generated_utc: `{generated_utc}`",
        f"- overall_status: **{overall_status}**",
        "",
        "## Lanes",
        "| lane | status | returncode | duration_seconds | latest_json | latest_md | command |",
        "|---|---|---:|---:|---|---|---|",
    ]
    for lane in lanes:
        lines.append(
            f"| {lane.lane} | {lane.status} | {lane.returncode} | {lane.duration_seconds:.3f} | "
            f"{lane.latest_json or '-'} | {lane.latest_md or '-'} | `{' '.join(lane.command)}` |"
        )
    return "\n".join(lines).strip() + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Run unified Trinity (Mind/Body/Heart) runner.")
    parser.add_argument("--reports-dir", default="docs/trinity-runs")
    parser.add_argument("--latest-json", default="docs/trinity-latest.json")
    parser.add_argument("--latest-md", default="docs/trinity-latest.md")
    parser.add_argument("--history-jsonl", default="docs/trinity-history.jsonl")

    parser.add_argument("--body-benchmark-profile", default="standard", choices=("quick", "standard", "strict"))
    parser.add_argument("--mind-gammas", type=float, nargs="+", default=[0.0, 0.05, 0.1, 0.2])
    args = parser.parse_args()

    root = Path(".")
    reports_dir = root / args.reports_dir
    reports_dir.mkdir(parents=True, exist_ok=True)

    generated_utc = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    lanes: List[LaneResult] = []

    body_cmd = [
        sys.executable,
        "body_track_runner.py",
        "--benchmark-profile",
        args.body_benchmark_profile,
        "--fail-on-benchmark",
    ]
    rc, dur, _out, _err = _run(body_cmd)
    body_latest = _read_json_if_exists(root / "docs/body-track-smoke-latest.json")
    lanes.append(
        LaneResult(
            lane="Body",
            command=body_cmd,
            returncode=rc,
            duration_seconds=dur,
            status=_derive_status("UNKNOWN", body_latest),
            latest_json="docs/body-track-smoke-latest.json",
            latest_md="docs/body-track-smoke-latest.md",
        )
    )

    mind_cmd = [sys.executable, "mind_track_runner.py", "--gammas", *[str(g) for g in args.mind_gammas]]
    rc, dur, _out, _err = _run(mind_cmd)
    mind_latest = _read_json_if_exists(root / "docs/mind-track-smoke-latest.json")
    lanes.append(
        LaneResult(
            lane="Mind",
            command=mind_cmd,
            returncode=rc,
            duration_seconds=dur,
            status=_derive_status("UNKNOWN", mind_latest),
            latest_json="docs/mind-track-smoke-latest.json",
            latest_md="docs/mind-track-smoke-latest.md",
        )
    )

    heart_gov_cmd = [sys.executable, "freed_id_control_verifier.py"]
    rc, dur, _out, _err = _run(heart_gov_cmd)
    gov_latest = _read_json_if_exists(root / "docs/heart-track-governance-latest.json")
    lanes.append(
        LaneResult(
            lane="Heart(GOV-005)",
            command=heart_gov_cmd,
            returncode=rc,
            duration_seconds=dur,
            status=_derive_status("UNKNOWN", gov_latest),
            latest_json="docs/heart-track-governance-latest.json",
            latest_md="docs/heart-track-governance-latest.md",
        )
    )

    heart_min_cmd = [sys.executable, "freed_id_minimum_disclosure_verifier.py"]
    rc, dur, _out, _err = _run(heart_min_cmd)
    min_latest = _read_json_if_exists(root / "docs/heart-track-min-disclosure-latest.json")
    lanes.append(
        LaneResult(
            lane="Heart(GOV-002)",
            command=heart_min_cmd,
            returncode=rc,
            duration_seconds=dur,
            status=_derive_status("UNKNOWN", min_latest),
            latest_json="docs/heart-track-min-disclosure-latest.json",
            latest_md="docs/heart-track-min-disclosure-latest.md",
        )
    )

    overall_status = "PASS" if all(l.status == "PASS" for l in lanes) else "FAIL"
    payload = {"generated_utc": generated_utc, "overall_status": overall_status, "lanes": [asdict(l) for l in lanes]}
    markdown = _build_markdown(generated_utc, overall_status, lanes)

    timestamped_json = reports_dir / f"{stamp}-trinity.json"
    timestamped_md = reports_dir / f"{stamp}-trinity.md"
    latest_json = root / args.latest_json
    latest_md = root / args.latest_md
    history = root / args.history_jsonl

    latest_json.parent.mkdir(parents=True, exist_ok=True)
    latest_md.parent.mkdir(parents=True, exist_ok=True)
    history.parent.mkdir(parents=True, exist_ok=True)

    timestamped_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    timestamped_md.write_text(markdown, encoding="utf-8")
    latest_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    latest_md.write_text(markdown, encoding="utf-8")
    with history.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload) + "\n")

    print(f"overall_status={overall_status}")
    print(f"timestamped_json={timestamped_json}")
    print(f"timestamped_md={timestamped_md}")
    print(f"latest_json={latest_json}")
    print(f"latest_md={latest_md}")
    print(f"history_jsonl={history}")
    return 0 if overall_status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
