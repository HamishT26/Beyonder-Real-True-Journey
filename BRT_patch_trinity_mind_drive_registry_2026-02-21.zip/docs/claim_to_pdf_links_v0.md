# Claim ↔ PDF Evidence Links v0

Purpose: tie each claim/control to a specific PDF source location (page/section/quote) and to a runnable check.

How to use:
1) Add a row with PDF version + Drive file ID.
2) Fill `page_ref` and a short `quote` (or section heading).
3) Fill `linked_runner_or_test` with the repo artifact that operationalizes the claim.

| item_id | lane | pdf_version | drive_file_id | page_ref | quote_or_section | evidence_tag | linked_runner_or_test |
|---|---|---|---|---|---|---|---|
| GMUT-002 | Mind | v34 | 1lrGqLuEqjVvm-UCOLw3pUhBbbp3Z4Hj- | TBD | TBD | open_gap | mind_track_runner.py (gamma sweep) |
| GMUT-007 | Mind | v33 | 1T1a2aCPc21EclU1itu6nmBNk92UfAQo6 | TBD | TBD | confirmed_evidence | run_simulation.py / trinity_simulation_engine.py |
| GOV-005 | Heart | v33 | 1T1a2aCPc21EclU1itu6nmBNk92UfAQo6 | TBD | TBD | confirmed_evidence | freed_id_control_verifier.py |
| GOV-002 | Heart | v33 | 1T1a2aCPc21EclU1itu6nmBNk92UfAQo6 | TBD | TBD | confirmed_evidence | freed_id_minimum_disclosure_verifier.py |
