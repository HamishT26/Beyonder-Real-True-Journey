# Draft Patch: Trinity Runner + Mind Track + Drive→Repo PDF Registry (2026-02-21)

This patch is designed to be pasted into the repo when you have laptop time.

## Adds (new files)
- `mind_track_runner.py` — Mind lane runner (GMUT gamma sweep + optional anchor checks)
- `trinity_runner.py` — unified Mind/Body/Heart runner that calls existing runners/verifiers
- `docs/mind-runner-report-template.md`
- `docs/trinity-runner-report-template.md`
- `docs/journey_pdf_registry_v0.json` — Drive file registry for Journey PDFs
- `scripts/journey_pdf_registry_validator.py` — tiny validator for the registry JSON

## How to apply (when ready)
1. Copy each file into the matching path in the repo.
2. Run:
   - `python3 scripts/journey_pdf_registry_validator.py`
   - `python3 mind_track_runner.py`
   - `python3 trinity_runner.py --body-benchmark-profile standard`

## Notes
- Mind runner compiles a few scripts (`scripts/gmut_anchor_trace_validator.py`, `scripts/gmut_external_anchor_exclusion_note.py`).
  These already exist in the repo; the optional steps will SKIP if required JSON inputs are missing.
- Trinity runner expects Body + Heart artifacts already in the repo:
  - Body: `body_track_runner.py`
  - Heart: `freed_id_control_verifier.py`, `freed_id_minimum_disclosure_verifier.py`

## Added in v0.1 (same patch)
- `docs/claim_to_pdf_links_v0.md`
- `docs/drive_to_repo_evidence_pipeline_v0.md`
- `scripts/render_journey_pdf_registry.py` (generates `docs/journey_pdf_registry_v0.md`)
