# Trinity Unified Runner Report Template

Use this template for each unified Mind/Body/Heart cycle.

---

## Metadata
- generated_utc:
- branch:
- commit:
- runner_version:
- overall_status: PASS/FAIL

## Lanes
| lane | status | returncode | duration_seconds | command | artifacts |
|---|---|---:|---:|---|---|
| Body |  |  |  |  | docs/body-track-*.{json,md} |
| Mind |  |  |  |  | docs/mind-track-*.{json,md} |
| Heart(GOV-005) |  |  |  |  | docs/heart-track-governance-*.{json,md} |
| Heart(GOV-002) |  |  |  |  | docs/heart-track-min-disclosure-*.{json,md} |

## Interpretation
- regressions:
- improvements:
- open_gaps:

## Next actions
1.
2.
3.
