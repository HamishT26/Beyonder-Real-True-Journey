# Drive → Repo Evidence Pipeline v0

Goal: keep Drive PDFs, claim mapping, and repo checks synchronized.

## Artifacts
- `docs/journey_pdf_registry_v0.json` (Drive file registry)
- `docs/claim_to_pdf_links_v0.md` (claim/control → PDF location → runner/test)
- Optional: `sources/pdfs/` (downloaded copies for offline reproducibility)

## Workflow (manual-first)
1) Add/verify Drive PDFs in `journey_pdf_registry_v0.json`
2) For each claim/control you care about this week:
   - add a row in `claim_to_pdf_links_v0.md` with page ref + quote
3) Ensure there is a runnable check:
   - Mind: `mind_track_runner.py`
   - Body: `body_track_runner.py`
   - Heart: GOV verifiers
4) Run:
   - `python3 scripts/journey_pdf_registry_validator.py`
   - `python3 trinity_runner.py`

## Upgrade path (later)
- add a script that ingests Drive PDFs into `sources/pdfs/` and verifies checksums
- add lightweight extractors (page text snippets) and attach them as trace artifacts
