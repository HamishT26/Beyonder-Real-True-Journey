# Mind Runner Report Template

Use this template for each Mind-track validation cycle.

---

## Metadata
- generated_utc:
- branch:
- commit:
- runner_version:
- overall_status: PASS/FAIL

## Steps
| step | status | returncode | duration_seconds | command | artifact |
|---|---|---:|---:|---|---|
| compile_python_modules |  |  |  |  |  |
| gmut_gamma_sweep |  |  |  |  |  |
| anchor_trace_validation (optional) |  |  |  |  |  |
| anchor_exclusion_note (optional) |  |  |  |  |  |

## Evidence boundaries
- confirmed_evidence:
- inference:
- open_gap:

## Next actions
1.
2.
3.
