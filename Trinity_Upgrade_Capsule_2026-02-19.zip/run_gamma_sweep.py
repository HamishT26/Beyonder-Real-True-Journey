"""run_gamma_sweep.py

Run a simple parameter sweep over the GMUT coupling parameter gamma and
summarize how the simulated energy-density ratio changes.

Outputs:
- gamma_sweep.csv
- gamma_sweep.png (optional)

Usage:
  python3 run_gamma_sweep.py --gmin 0.0 --gmax 0.2 --steps 21 --plot
"""

from __future__ import annotations

import argparse
import csv
from pathlib import Path

import matplotlib.pyplot as plt

import trinity_simulation_engine as sim


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--gmin", type=float, default=0.0)
    ap.add_argument("--gmax", type=float, default=0.2)
    ap.add_argument("--steps", type=int, default=21)
    ap.add_argument("--out", type=str, default="gamma_sweep.csv")
    ap.add_argument("--plot", action="store_true")
    ap.add_argument("--plot-out", type=str, default="gamma_sweep.png")
    args = ap.parse_args()

    steps = max(2, int(args.steps))
    gmin, gmax = float(args.gmin), float(args.gmax)

    rows = []
    for k in range(steps):
        gamma = gmin + (gmax - gmin) * (k / (steps - 1))
        res = sim.run_experiment(gamma=gamma)
        rows.append({
            "gamma": gamma,
            "energy_density_ratio": float(res["energy_density_ratio"]),
        })

    out_path = Path(args.out)
    with out_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["gamma", "energy_density_ratio"])
        w.writeheader()
        w.writerows(rows)

    if args.plot:
        xs = [r["gamma"] for r in rows]
        ys = [r["energy_density_ratio"] for r in rows]
        plt.figure()
        plt.plot(xs, ys)
        plt.xlabel("gamma")
        plt.ylabel("energy_density_ratio")
        plt.title("GMUT sweep: energy density ratio vs gamma")
        plt.grid(True)
        plt.savefig(args.plot_out, bbox_inches="tight")
        plt.close()

    print(f"Wrote {out_path}")
    if args.plot:
        print(f"Wrote {args.plot_out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
