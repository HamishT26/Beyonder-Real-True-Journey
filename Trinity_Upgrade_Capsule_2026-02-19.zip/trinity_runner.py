"""
Unified Trinity Runner

This script orchestrates various tasks in the Beyonder-Real-True Journey project.
It runs pre/post stages such as snapshot generation and cache/waste regeneration,
executes the full Trinity orchestrator with QCIT integration, performs GMUT
simulations, and aggregates results into a single JSON report. The goal is to
provide a single entrypoint for running the entire pipeline and producing
standardized output.

Stages are modular and can be executed or skipped based on configuration.
Each stage returns a result dictionary with metrics and logs; these are
collected into a final report. Benchmark guardrails ensure that each stage
meets minimum pass rate and health scores.
"""

from __future__ import annotations

import json
import datetime
import importlib
import os
import time
from dataclasses import dataclass, asdict
from typing import Callable, Dict, List, Optional, Any

############################
# Data classes and helpers #
############################

@dataclass
class StageResult:
    """Holds metrics and logs for a pipeline stage."""
    name: str
    success: bool
    metrics: Dict[str, Any]
    logs: List[str]

    def as_dict(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "success": self.success,
            "metrics": self.metrics,
            "logs": self.logs,
        }


def _run_stage(name: str, func: Callable[[], Dict[str, Any]]) -> StageResult:
    """Execute a stage and capture its metrics/logs."""
    logs: List[str] = []
    metrics: Dict[str, Any] = {}
    try:
        t0 = time.perf_counter()
        logs.append(f"Starting stage {name}")
        result = func()
        if not isinstance(result, dict):
            raise ValueError(f"Stage {name} did not return a dict")
        metrics = result
        metrics.setdefault("duration_ms", (time.perf_counter() - t0) * 1000.0)
        success = True
        logs.append(f"Stage {name} completed successfully")
    except Exception as e:
        success = False
        metrics.setdefault("duration_ms", (time.perf_counter() - t0) * 1000.0 if 't0' in locals() else None)
        logs.append(f"Stage {name} failed: {e}")
    return StageResult(name=name, success=success, metrics=metrics, logs=logs)


def _build_summary(stage_results: List[StageResult]) -> Dict[str, Any]:
    """Build summary metrics across all stages."""
    summary = {
        "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
        "overall_success": all(sr.success for sr in stage_results),
        "stages": [sr.as_dict() for sr in stage_results],
    }
    return summary


###########################
# Stage implementations    #
###########################

def stage_snapshot() -> Dict[str, Any]:
    """Run the gyroscopic snapshot generator if available."""
    try:
        import scripts.gyroscopic_hybrid_zip_converter_generator as snapshot
    except ImportError:
        return {"skipped": True, "reason": "Snapshot generator not found"}
    return snapshot.main()


def stage_cache_waste() -> Dict[str, Any]:
    """Run the cache/waste regenerator if available."""
    try:
        import scripts.cache_waste_regenerator as regenerator
    except ImportError:
        return {"skipped": True, "reason": "Cache/waste regenerator not found"}
    return regenerator.main()


def stage_orchestrator() -> Dict[str, Any]:
    """Run the full Trinity orchestrator."""
    try:
        import trinity_orchestrator_full as orchestrator
    except ImportError:
        return {"skipped": True, "reason": "Trinity orchestrator not found"}
    return orchestrator.main()


def stage_simulation(gamma: float = 0.05) -> Dict[str, Any]:
    """Run the GMUT simulation with a given gamma coupling."""
    try:
        import trinity_simulation_engine as sim
    except ImportError:
        return {"skipped": True, "reason": "Simulation engine not found"}
    # call simulation with baseline + delta
    try:
        result = sim.run_experiment(gamma)
    except Exception as e:
        return {"success": False, "error": str(e)}
    return result


def stage_freed_id() -> Dict[str, Any]:
    """Issue a minimal Freed ID credential using the in-memory registry."""
    try:
        from freed_id_registry import FreedIDRegistry, DIDDocument
    except ImportError:
        return {"skipped": True, "reason": "Freed ID registry not found"}

    registry = FreedIDRegistry()
    doc = DIDDocument(
        did="did:freed:runner",
        controller="did:freed:runner",
        verification_methods=[{"id": "did:freed:runner#keys-1", "type": "Ed25519VerificationKey2018", "publicKeyBase58": "GfH2..."}],
        services=[{"id": "did:freed:runner#registry", "type": "FreedIDCredentialRegistry", "serviceEndpoint": "local://freed-id"}],
    )
    did = registry.register(doc)
    cred_id = registry.issue_credential(
        did,
        {
            "issuer": "did:freed:issuer",
            "subject": did,
            "level": 6,
            "rights": ["autonomy", "privacy", "recourse"],
        },
    )
    verified = registry.verify_credential(did, cred_id)
    return {"did": did, "credential_id": cred_id, "verified": verified}


##############################################
# Main runner and argument parsing            #
##############################################

def run_pipeline(
    run_snapshot: bool = True,
    run_cache: bool = True,
    run_orchestrator: bool = True,
    run_sim: bool = True,
    run_freed_id: bool = False,
    gamma: float = 0.05,
) -> Dict[str, Any]:
    """Run the selected stages and return a summary dict."""
    stage_results: List[StageResult] = []
    if run_snapshot:
        stage_results.append(_run_stage("snapshot", stage_snapshot))
    if run_cache:
        stage_results.append(_run_stage("cache_waste", stage_cache_waste))
    if run_orchestrator:
        stage_results.append(_run_stage("orchestrator", stage_orchestrator))
    if run_sim:
        stage_results.append(
            _run_stage("simulation", lambda: stage_simulation(gamma=gamma))
        )
    if run_freed_id:
        stage_results.append(_run_stage("freed_id", stage_freed_id))
    summary = _build_summary(stage_results)
    return summary


def main(argv: Optional[List[str]] = None) -> int:
    """Entry point for command-line execution."""
    import argparse

    parser = argparse.ArgumentParser(description="Unified Trinity Runner")
    parser.add_argument("--no-snapshot", action="store_true", help="Skip snapshot stage")
    parser.add_argument("--no-cache", action="store_true", help="Skip cache/waste stage")
    parser.add_argument("--no-orchestrator", action="store_true", help="Skip orchestrator stage")
    parser.add_argument("--no-sim", action="store_true", help="Skip simulation stage")
    parser.add_argument("--freed-id", action="store_true", help="Run Freed ID issuance stage")
    parser.add_argument("--gamma", type=float, default=0.05, help="Gamma coupling for simulation")
    parser.add_argument(
        "--out", type=str, default="report.json", help="Output file for JSON report"
    )
    args = parser.parse_args(argv)

    summary = run_pipeline(
        run_snapshot=not args.no_snapshot,
        run_cache=not args.no_cache,
        run_orchestrator=not args.no_orchestrator,
        run_sim=not args.no_sim,
        run_freed_id=args.freed_id,
        gamma=args.gamma,
    )
    # Write JSON report
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print(f"Report written to {args.out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())