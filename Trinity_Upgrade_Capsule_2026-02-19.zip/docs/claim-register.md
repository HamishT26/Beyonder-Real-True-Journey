# Claim Register

This register tracks major claims across:

- GMUT (pure science)
- Trinity Hybrid OS (applied systems)
- Freed ID + Cosmic Bill of Rights (governance)

Each claim is labelled with status:

- **Conceptual**: narrative only
- **Conjectured**: formal statement, not yet tested
- **Simulatable**: coded model exists
- **Testable**: concrete prediction + measurement plan
- **Validated**: matches evidence
- **Refuted**: contradicted by evidence

| Claim ID | Pillar | Claim | Status | Evidence | Next step |
|---|---|---|---|---|---|
| GMUT‑GW‑1 | GMUT | GMUT delta modifies stochastic GW spectrum vs baseline | Simulatable | `trinity_simulation_engine.py` | build sweep + compare to public constraints |
| TRIN‑QCIT‑1 | Trinity | QCIT can map amplitudes → stable classical features | Simulatable | `qc_transmuter.py` | validate against known distributions |
| FREED‑DID‑1 | Freed ID | `did:freed` + VC issuance supports identity gating | Simulatable | `freed_id_registry.py`, runner stage | add persistence + revocation log |
| CBR‑MAP‑1 | CBR | rights can be mapped to enforceable OS controls | Conceptual | `cosmic_bill_of_rights.md` | implement conformance tests |
