# Trinity Unified Runner Guide

This guide describes how to use `trinity_runner.py` as a single entrypoint to run the
core modules of the Beyonder‑Real‑True Journey stack:

- Snapshot generation (Aster-style gyroscopic ZIP module)
- Cache / waste regeneration (Lumen-style regenerator)
- Trinity orchestrator (QCIT + identity gating)
- GMUT simulation (baseline + delta)
- Freed ID issuance (minimal DID/VC demo)

## Quickstart

From the repository root:

```bash
python3 trinity_runner.py --freed-id --gamma 0.05
```

This writes a JSON report (default: `report.json`) containing stage metrics and logs.

## Flags

- `--no-snapshot` – skip snapshot stage
- `--no-cache` – skip cache/waste stage
- `--no-orchestrator` – skip orchestrator stage
- `--no-sim` – skip simulation stage
- `--freed-id` – run Freed ID issuance stage
- `--gamma <float>` – GMUT delta strength used by the simulation engine
- `--out <path>` – output report path (default `report.json`)

## Output format

The report is a dict with:

- `timestamp`
- `overall_success`
- `stages[]`: each has `name`, `success`, `metrics`, `logs`

## Extending

To add a new stage:

1. Implement a `stage_<name>() -> dict` function.
2. Add a CLI flag if you want it optional.
3. Append `_run_stage("<name>", stage_<name>)` to `run_pipeline()`.
4. Ensure the stage returns a JSON-serializable dict.
