# MONDAY RUNBOOK v1 — Trinity Hybrid OS Baseline

generated_utc: `2026-02-21T06:25:05Z`

This checklist turns the BC patch chain into a single reproducible baseline run committed to GitHub.

## Before you start
- [ ] Pull latest repo locally
- [ ] Ensure Python 3.10+ available
- [ ] Create a new branch for integration (recommended): `integrate/bc3-bc10-baseline`

## Apply patches in order
If you’re applying from zips, apply in this order:
1. BC3
2. BC5
3. BC6
4. BC7
5. BC8
6. BC9
7. BC10 (this)

## First baseline run sequence
### 1) Optional: Body daily check-in
```bash
python scripts/body_daily_checkin.py
python scripts/body_checkin_summary.py
```

### 2) Trinity cycle
```bash
python scripts/run_trinity_cycle.py --profile standard
```

### 3) Render registry pages
```bash
python scripts/render_journey_pdf_registry.py
```

### 4) Auto-generate claim/control mapping template (optional)
```bash
python scripts/extract_claim_control_ids.py --output docs/claim_to_pdf_links_auto.md
```

## What to commit
Commit `docs/` artifacts produced by the run, especially:
- docs/trinity-latest.json/.md
- docs/trinity-latest-with-evidence.json/.md
- docs/TRINITY_INDEX.md
- docs/evidence-links-latest.json
- docs/*history*.jsonl
- docs/body-track-daily-*.json*

## Tag the baseline (optional)
After merge to main:
- tag: `v0.1-trinity-hybrid-os-baseline`
