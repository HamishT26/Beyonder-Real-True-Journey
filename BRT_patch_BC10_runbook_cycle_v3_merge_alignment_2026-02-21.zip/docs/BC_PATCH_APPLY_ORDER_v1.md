# BC Patch Apply Order (v1)

generated_utc: `2026-02-21T06:25:05Z`

Recommended order for a clean baseline:
- BC3
- BC5
- BC6
- BC7
- BC8
- BC9
- BC10
