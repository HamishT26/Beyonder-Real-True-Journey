"""scripts/run_trinity_cycle.py (v3)
---------------------------------

One-command "full cycle" runner for Trinity Hybrid OS.

What it does:
1) Runs Trinity (Mind/Body/Heart) via trinity_runner.py
2) Generates evidence links (scripts/generate_evidence_links.py) if present
3) Generates Trinity-with-evidence merged artifacts (scripts/update_trinity_with_evidence.py) if present
4) Appends a compact run registry entry (docs/run-registry.jsonl)
5) Renders docs/TRINITY_INDEX.md

Designed to be robust: missing optional scripts/files do NOT break the run.

Usage:
    python scripts/run_trinity_cycle.py --profile standard
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


def _run(cmd: List[str]) -> int:
    p = subprocess.run(cmd, check=False)
    return int(p.returncode)


def _read_json(path: Path) -> Optional[Dict[str, Any]]:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None


def _render_index(history_jsonl: Path, out_md: Path, max_rows: int = 40) -> None:
    if not history_jsonl.exists():
        out_md.write_text("# Trinity Index\n\nNo runs yet.\n", encoding="utf-8")
        return

    rows = []
    for line in history_jsonl.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            continue

    rows = list(reversed(rows))[:max_rows]

    lines = [
        "# Trinity Index",
        "",
        f"Last updated: `{datetime.now(timezone.utc).replace(microsecond=0).isoformat()}`",
        "",
        "| generated_utc | overall_status | body | mind | heart | evidence_links | merged_trinity |",
        "|---|---|---|---|---|---|---|",
    ]

    def lane_status(payload: Dict[str, Any], lane_name: str) -> str:
        for l in payload.get("lanes", []):
            if str(l.get("lane")) == lane_name:
                return str(l.get("status"))
        return "-"

    for r in rows:
        generated = str(r.get("generated_utc", "-"))
        overall = str(r.get("overall_status", "-"))
        body = lane_status(r, "Body")
        mind = lane_status(r, "Mind")
        heart = lane_status(r, "Heart")
        ev = r.get("evidence_links_latest_json", "-")
        merged = r.get("trinity_with_evidence_json", "-")
        lines.append(f"| {generated} | **{overall}** | {body} | {mind} | {heart} | {ev} | {merged} |")

    out_md.write_text("\n".join(lines).strip() + "\n", encoding="utf-8")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--profile", default="standard", choices=("quick", "standard", "strict"))
    ap.add_argument("--gammas", type=float, nargs="+", default=[0.0, 0.05, 0.1, 0.2])
    args = ap.parse_args()

    root = Path(".")
    docs = root / "docs"
    docs.mkdir(exist_ok=True)

    # 1) Trinity run
    trinity_cmd = [
        sys.executable,
        "trinity_runner.py",
        "--body-benchmark-profile",
        args.profile,
        "--mind-gammas",
        *[str(g) for g in args.gammas],
    ]
    rc = _run(trinity_cmd)

    # 2) Evidence links (optional)
    ev_script = root / "scripts/generate_evidence_links.py"
    if ev_script.exists():
        _run([sys.executable, str(ev_script)])

    # 3) Merge Trinity + evidence + body daily (optional)
    merged_json = "docs/trinity-latest-with-evidence.json"
    merged_md = "docs/trinity-latest-with-evidence.md"
    merge_script = root / "scripts/update_trinity_with_evidence.py"
    if merge_script.exists():
        _run([sys.executable, str(merge_script),
              "--trinity-json", "docs/trinity-latest.json",
              "--body-json", "docs/body-track-daily-latest.json",
              "--evidence-json", "docs/evidence-links-latest.json",
              "--output-json", merged_json,
              "--output-md", merged_md])

    # Read latest to record lanes, etc
    latest = _read_json(docs / "trinity-latest.json") or {}

    # 4) Append compact run registry entry
    run_registry = docs / "run-registry.jsonl"
    run_registry.parent.mkdir(parents=True, exist_ok=True)
    entry = {
        "generated_utc": latest.get("generated_utc") or datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "overall_status": latest.get("overall_status", "UNKNOWN"),
        "lanes": latest.get("lanes", []),
        "evidence_links_latest_json": latest.get("evidence_links_latest_json", "docs/evidence-links-latest.json"),
        "trinity_with_evidence_json": merged_json if (docs / Path(merged_json).name).exists() else "-",
        "trinity_with_evidence_md": merged_md if (docs / Path(merged_md).name).exists() else "-",
    }
    with run_registry.open("a", encoding="utf-8") as h:
        h.write(json.dumps(entry) + "\n")

    # 5) Render index
    history = docs / "trinity-history.jsonl"
    index_out = docs / "TRINITY_INDEX.md"
    if history.exists():
        _render_index(history, index_out)
    else:
        _render_index(run_registry, index_out)

    return rc


if __name__ == "__main__":
    raise SystemExit(main())
