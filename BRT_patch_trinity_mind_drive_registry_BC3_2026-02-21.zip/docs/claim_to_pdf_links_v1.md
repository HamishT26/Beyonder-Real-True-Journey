# Claim → PDF → Test Link Map v1

This file is a living bridge between:
- Journey PDFs in Google Drive (registry),
- repo claims/controls,
- runnable validations (Mind/Body/Heart).

## Journey PDF registry
See: `docs/journey_pdf_registry_v0.json` and `docs/journey_pdf_registry_v0.md`

---

## Mind track (GMUT claims)

| claim_id | canonical_doc | runnable_test | primary_pdf_sources | page/section (TBD) | notes |
|---|---|---|---|---|---|
| GMUT-001 | `docs/gmut-claim-register-v0.md` | `python3 mind_track_runner.py` (gamma sweep baseline) | v34, v33 | TBD | bound derivation needed |
| GMUT-002 | `docs/gmut-claim-register-v0.md` | `python3 mind_track_runner.py` + `python3 run_simulation.py` | v34 | TBD | anchor to PTA/LISA envelopes later |
| GMUT-003 | `docs/gmut-claim-register-v0.md` | (future) PTA fit runner | v34 | TBD | define anomaly functional form |
| GMUT-004 | `docs/gmut-claim-register-v0.md` | (future) cosmology fit runner | v34 | TBD | derive w(z) |
| GMUT-005 | `docs/gmut-claim-register-v0.md` | `scripts/gmut_external_anchor_exclusion_note.py` | v34 | TBD | keep evidence-bounded |
| GMUT-006 | `docs/gmut-claim-register-v0.md` | (future) decoherence signal runner | v34 | TBD | define signal model |
| GMUT-007 | `docs/gmut-claim-register-v0.md` | `python3 mind_track_runner.py` | v34 | TBD | add seeded regression later |

---

## Heart track (Freed ID controls)

| control_id | canonical_doc | runnable_test | primary_pdf_sources | page/section (TBD) | notes |
|---|---|---|---|---|---|
| GOV-001 | `docs/freedid-cosmic-control-matrix-v0.md` | (future) signature interface tests | v34, v33 | TBD | maturity=specified |
| GOV-002 | `docs/freedid-cosmic-control-matrix-v0.md` | `python3 freed_id_minimum_disclosure_verifier.py` | v34 | TBD | maturity=verified |
| GOV-003 | `docs/freedid-cosmic-control-matrix-v0.md` | `python3 freed_id_auditability_verifier.py` | v34 | TBD | maturity=verified |
| GOV-004 | `docs/freedid-cosmic-control-matrix-v0.md` | dispute recourse verifiers | v34 | TBD | maturity=verified |
| GOV-005 | `docs/freedid-cosmic-control-matrix-v0.md` | `python3 freed_id_control_verifier.py` | v34 | TBD | maturity=verified |
| GOV-006 | `docs/freedid-cosmic-control-matrix-v0.md` | (future) DID-core schema validator | v34 | TBD | maturity=specified |
| GOV-007 | `docs/freedid-cosmic-control-matrix-v0.md` | (future) review log checker | v34 | TBD | maturity=implemented |

---

## Body track (Trinity runtime health)

| artifact | runner | meaning |
|---|---|---|
| `docs/body-track-smoke-latest.*` | `python3 body_track_runner.py` | compile + orchestrator + simulation smoke |
| `docs/body-track-metrics-history.jsonl` | `python3 body_track_runner.py` | longitudinal drift + regression detection |
