# Drive → Repo Evidence Pipeline v1

Goal: make PDFs actionable by linking them to claims, controls, and runnable tests.

## Minimal workflow (manual-first)
1. Add/maintain `docs/journey_pdf_registry_v0.json`
2. Render the registry: `python3 scripts/render_journey_pdf_registry.py`
3. Update claim links: `docs/claim_to_pdf_links_v1.md`
4. Run `python3 trinity_runner.py` to regenerate lane artifacts.

## Optional workflow (semi-automated later)
- Download PDFs into `sources/pdfs/` with a script (future).
- Extract page-level snippets and store under `sources/extracts/<pdf_version>/...`
- Maintain a trace manifest for each extraction (checksum-linked).

## Promotion rule
No claim/control is promoted in maturity unless there is at least one of:
- a runnable check producing an artifact, OR
- a trace-linked extraction snapshot with checksum, OR
- a dated review record with reproducible steps.

## Storage note (Google Drive / Google One)
Google One expands Google Drive storage automatically. Keep large archives (zip capsules)
in a Drive folder (suggested name: `Beyonder-Real-True_System`) and link them from the registry.
