# Trinity Runner Report Template

Use this template for each full Trinity (Mind/Body/Heart) cycle.

---

## Metadata
- generated_utc:
- branch:
- commit:
- runner_version:
- overall_status: PASS/WARN/FAIL

## Lanes
| lane | status | returncode | duration_seconds | artifacts |
|---|---|---:|---:|---|
| Body |  |  |  | `docs/body-track-smoke-latest.*` |
| Mind |  |  |  | `docs/mind-track-smoke-latest.*` |
| Heart GOV-005 |  |  |  | `docs/heart-track-governance-latest.*` |
| Heart GOV-002 |  |  |  | `docs/heart-track-min-disclosure-latest.*` |
| Heart (aggregate) |  |  |  | — |

## Cross-track notes
- regressions:
- improvements:
- open gaps:

## Next actions
1.
2.
3.
