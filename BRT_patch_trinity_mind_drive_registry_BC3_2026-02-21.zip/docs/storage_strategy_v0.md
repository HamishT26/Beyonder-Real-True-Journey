# Storage Strategy v0 (Drive / Google One / Local)

## What lives where
- `/mnt/data/Beyonder-Real-True_System/` : working session outputs + patch zips created inside ChatGPT.
- Google Drive folder `Beyonder-Real-True_System/` : long-term archive + sharing point.
- GitHub repo: source-of-truth code + docs + *lightweight* artifacts (avoid huge binaries unless necessary).

## Google One
Google One expands your Google Drive storage automatically.
There is no separate “Google One connector” needed—Drive is the interface.

## Recommended Drive folder layout
- Beyonder-Real-True_System/
  - patches/
  - capsules/
  - pdfs/
  - exports/

## Minimal weekly routine
1. Upload new patch zip(s) from `/mnt/data` to Drive → `patches/`
2. Keep the latest continuity capsule markdown in `capsules/`
3. Keep PDFs in `pdfs/` and reference them in `docs/journey_pdf_registry_v0.json`
