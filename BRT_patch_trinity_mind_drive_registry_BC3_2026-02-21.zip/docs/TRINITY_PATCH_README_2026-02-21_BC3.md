# Patch README (B+C v2) — 2026-02-21

This patch extends the earlier B+C bundle.

## Adds/updates
- Updated `mind_track_runner.py` (compile only existing files, better optional skips)
- Updated `trinity_runner.py` (skip flags, robust Heart aggregation, WARN vs FAIL)
- New docs:
  - `docs/trinity-runbook-v0.md`
  - `docs/drive_to_repo_evidence_pipeline_v1.md`
  - `docs/claim_to_pdf_links_v1.md`
  - `docs/journey_pdf_registry_v0.md` (renderable)
- Scripts:
  - `scripts/render_journey_pdf_registry.py`
  - `scripts/journey_pdf_registry_validator.py`
- Optional: `.github/workflows/trinity-smoke.yml` (CI scaffold)

## How to apply
Copy files into the repo root, then run:
- `python3 scripts/journey_pdf_registry_validator.py`
- `python3 scripts/render_journey_pdf_registry.py`
- `python3 mind_track_runner.py`
- `python3 trinity_runner.py --skip-heart` (if you want to avoid Heart lane on CI initially)

## Notes
This patch does not merge PRs; it is safe to apply later when you have laptop time.


## BC3 additions
- Enriched PDF registry with created/modified timestamps
- Renderer now includes timestamps
- Added docs/storage_strategy_v0.md
