# Trinity Runner Runbook v0

This runbook explains how to run the unified Trinity runners and where to find outputs.

## Quick start

Run a full cycle (requires Body+Mind+Heart scripts present):
```bash
python3 trinity_runner.py
```

Run only Mind lane:
```bash
python3 mind_track_runner.py --gammas 0.0 0.05 0.1 0.2
```

Run Trinity but skip Heart lane:
```bash
python3 trinity_runner.py --skip-heart
```

## Outputs

### Trinity
- timestamped: `docs/trinity-runs/<stamp>-trinity.json` and `.md`
- latest pointers: `docs/trinity-latest.json` and `.md`
- append-only history: `docs/trinity-history.jsonl`

### Mind
- timestamped: `docs/mind-track-runs/<stamp>-mind-track-smoke.json` and `.md`
- latest pointers: `docs/mind-track-smoke-latest.json` and `.md`
- metrics: `docs/mind-track-metrics-latest.json`
- history: `docs/mind-track-metrics-history.jsonl`

### Body
- timestamped: `docs/body-track-runs/...`
- latest pointers: `docs/body-track-smoke-latest.{json,md}`

### Heart
- GOV-005: `docs/heart-track-governance-latest.{json,md}`
- GOV-002: `docs/heart-track-min-disclosure-latest.{json,md}`

## Interpretation rules

- **PASS**: all required lanes ran and passed.
- **WARN**: required lane missing/skipped, or optional checks warn.
- **FAIL**: a lane failed or a required guardrail failed.

## Mobile workflow (Hamish)

1. Keep drafting changes in ChatGPT (patch zips under `/mnt/data/Beyonder-Real-True_System/`).
2. When laptop time is available, apply patch files into repo and commit.
3. Run `python3 trinity_runner.py` locally to regenerate artifacts, then commit outputs if desired.
