"""
trinity_runner.py
-----------------

Unified Trinity runner (Mind / Body / Heart).

Runs:
- Body:  body_track_runner.py
- Mind:  mind_track_runner.py
- Heart: one or more verifier scripts (default: GOV-005 + GOV-002)

Then writes a single Trinity summary:
- docs/trinity-runs/<stamp>-trinity.json / .md
- docs/trinity-latest.json / .md
- docs/trinity-history.jsonl

Design rule: lanes can be skipped, and missing scripts are SKIP (not FAIL) unless required.
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional


@dataclass
class LaneResult:
    lane: str
    command: List[str]
    returncode: int
    duration_seconds: float
    status: str  # PASS / FAIL / WARN / SKIP / UNKNOWN
    latest_json: Optional[str] = None
    latest_md: Optional[str] = None
    note: str = ""


def _run(cmd: List[str]) -> tuple[int, float, str, str]:
    started = time.perf_counter()
    completed = subprocess.run(cmd, capture_output=True, text=True, check=False)
    duration = time.perf_counter() - started
    return completed.returncode, duration, (completed.stdout or "").strip(), (completed.stderr or "").strip()


def _read_json_if_exists(path: Path) -> Optional[Dict[str, object]]:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None


def _derive_status(default: str, latest_payload: Optional[Dict[str, object]]) -> str:
    if not latest_payload:
        return default
    return str(latest_payload.get("overall_status", default))


def _build_markdown(generated_utc: str, overall_status: str, lanes: List[LaneResult]) -> str:
    lines = [
        "# Trinity Unified Run Report",
        "",
        f"- generated_utc: `{generated_utc}`",
        f"- overall_status: **{overall_status}**",
        "",
        "## Lanes",
        "| lane | status | returncode | duration_seconds | note | latest_json | latest_md | command |",
        "|---|---|---:|---:|---|---|---|---|",
    ]
    for lane in lanes:
        lines.append(
            f"| {lane.lane} | {lane.status} | {lane.returncode} | {lane.duration_seconds:.3f} | "
            f"{lane.note or '-'} | {lane.latest_json or '-'} | {lane.latest_md or '-'} | `{' '.join(lane.command)}` |"
        )
    return "\n".join(lines).strip() + "\n"


def _lane_skip(lane: str, cmd: List[str], note: str) -> LaneResult:
    return LaneResult(lane=lane, command=cmd, returncode=0, duration_seconds=0.0, status="SKIP", note=note)


def main() -> int:
    parser = argparse.ArgumentParser(description="Run unified Trinity (Mind/Body/Heart) runner.")
    parser.add_argument("--reports-dir", default="docs/trinity-runs")
    parser.add_argument("--latest-json", default="docs/trinity-latest.json")
    parser.add_argument("--latest-md", default="docs/trinity-latest.md")
    parser.add_argument("--history-jsonl", default="docs/trinity-history.jsonl")

    parser.add_argument("--skip-body", action="store_true")
    parser.add_argument("--skip-mind", action="store_true")
    parser.add_argument("--skip-heart", action="store_true")

    parser.add_argument("--body-benchmark-profile", default="standard", choices=("quick", "standard", "strict"))
    parser.add_argument("--mind-gammas", type=float, nargs="+", default=[0.0, 0.05, 0.1, 0.2])

    parser.add_argument(
        "--heart-scripts",
        nargs="+",
        default=["freed_id_control_verifier.py", "freed_id_minimum_disclosure_verifier.py"],
        help="One or more verifier scripts to run for Heart track.",
    )
    parser.add_argument("--require-lanes", nargs="*", default=["Body", "Mind", "Heart"], help="Which lanes must run (not SKIP).")
    args = parser.parse_args()

    root = Path(".")
    reports_dir = root / args.reports_dir
    reports_dir.mkdir(parents=True, exist_ok=True)

    generated_utc = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    lanes: List[LaneResult] = []

    required = set(args.require_lanes)

    # BODY
    body_cmd = [sys.executable, "body_track_runner.py", "--benchmark-profile", args.body_benchmark_profile, "--fail-on-benchmark"]
    if args.skip_body:
        lanes.append(_lane_skip("Body", body_cmd, "explicitly skipped"))
    elif not (root / "body_track_runner.py").exists():
        lanes.append(_lane_skip("Body", body_cmd, "missing body_track_runner.py"))
    else:
        rc, dur, _out, _err = _run(body_cmd)
        body_latest = _read_json_if_exists(root / "docs/body-track-smoke-latest.json")
        lanes.append(
            LaneResult(
                lane="Body",
                command=body_cmd,
                returncode=rc,
                duration_seconds=dur,
                status=_derive_status("UNKNOWN", body_latest) if rc == 0 else "FAIL",
                latest_json="docs/body-track-smoke-latest.json",
                latest_md="docs/body-track-smoke-latest.md",
            )
        )

    # MIND
    mind_cmd = [sys.executable, "mind_track_runner.py", "--gammas", *[str(g) for g in args.mind_gammas]]
    if args.skip_mind:
        lanes.append(_lane_skip("Mind", mind_cmd, "explicitly skipped"))
    elif not (root / "mind_track_runner.py").exists():
        lanes.append(_lane_skip("Mind", mind_cmd, "missing mind_track_runner.py"))
    else:
        rc, dur, _out, _err = _run(mind_cmd)
        mind_latest = _read_json_if_exists(root / "docs/mind-track-smoke-latest.json")
        lanes.append(
            LaneResult(
                lane="Mind",
                command=mind_cmd,
                returncode=rc,
                duration_seconds=dur,
                status=_derive_status("UNKNOWN", mind_latest) if rc == 0 else "FAIL",
                latest_json="docs/mind-track-smoke-latest.json",
                latest_md="docs/mind-track-smoke-latest.md",
            )
        )

    # HEART
    if args.skip_heart:
        lanes.append(_lane_skip("Heart", [sys.executable, *args.heart_scripts], "explicitly skipped"))
    else:
        # Each script becomes its own sub-lane, plus an aggregate Heart lane.
        heart_statuses: List[str] = []
        any_ran = False
        for script in args.heart_scripts:
            cmd = [sys.executable, script]
            if not (root / script).exists():
                lanes.append(_lane_skip(f"Heart:{script}", cmd, f"missing {script}"))
                heart_statuses.append("SKIP")
                continue
            any_ran = True
            rc, dur, _out, _err = _run(cmd)
            # Attempt to infer latest artifact path conventions
            latest_map = {
                "freed_id_control_verifier.py": ("docs/heart-track-governance-latest.json", "docs/heart-track-governance-latest.md"),
                "freed_id_minimum_disclosure_verifier.py": ("docs/heart-track-min-disclosure-latest.json", "docs/heart-track-min-disclosure-latest.md"),
            }
            lj, lm = latest_map.get(script, (None, None))
            latest_payload = _read_json_if_exists(root / lj) if lj else None
            status = _derive_status("UNKNOWN", latest_payload) if rc == 0 else "FAIL"
            heart_statuses.append(status)
            lanes.append(
                LaneResult(
                    lane=f"Heart:{script}",
                    command=cmd,
                    returncode=rc,
                    duration_seconds=dur,
                    status=status,
                    latest_json=lj,
                    latest_md=lm,
                )
            )
        aggregate_cmd = [sys.executable, *args.heart_scripts]
        if not any_ran:
            lanes.append(_lane_skip("Heart", aggregate_cmd, "no heart scripts present"))
        else:
            # Aggregate PASS only if all non-SKIP are PASS
            non_skip = [s for s in heart_statuses if s != "SKIP"]
            agg = "PASS" if non_skip and all(s == "PASS" for s in non_skip) else ("FAIL" if "FAIL" in non_skip else "WARN")
            lanes.append(LaneResult(lane="Heart", command=aggregate_cmd, returncode=0 if agg != "FAIL" else 1, duration_seconds=0.0, status=agg))

    # Determine overall status:
    # - any required lane that is SKIP => overall WARN
    # - any lane FAIL => overall FAIL
    # - otherwise PASS if all required lanes PASS (aggregate Heart counts as Heart)
    status_by_lane = {l.lane: l.status for l in lanes}
    hard_fail = any(l.status == "FAIL" for l in lanes)
    missing_required = any(status_by_lane.get(name) == "SKIP" for name in required if name in status_by_lane)

    if hard_fail:
        overall_status = "FAIL"
    elif missing_required:
        overall_status = "WARN"
    else:
        required_ok = True
        for name in required:
            st = status_by_lane.get(name)
            if st is None:
                required_ok = False
            elif st not in ("PASS",):
                required_ok = False
        overall_status = "PASS" if required_ok else "WARN"

    payload = {"generated_utc": generated_utc, "overall_status": overall_status, "lanes": [asdict(l) for l in lanes]}
    markdown = _build_markdown(generated_utc, overall_status, lanes)

    timestamped_json = reports_dir / f"{stamp}-trinity.json"
    timestamped_md = reports_dir / f"{stamp}-trinity.md"
    latest_json = root / args.latest_json
    latest_md = root / args.latest_md
    history = root / args.history_jsonl

    latest_json.parent.mkdir(parents=True, exist_ok=True)
    latest_md.parent.mkdir(parents=True, exist_ok=True)
    history.parent.mkdir(parents=True, exist_ok=True)

    timestamped_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    timestamped_md.write_text(markdown, encoding="utf-8")
    latest_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    latest_md.write_text(markdown, encoding="utf-8")
    with history.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload) + "\n")

    print(f"overall_status={overall_status}")
    print(f"timestamped_json={timestamped_json}")
    print(f"timestamped_md={timestamped_md}")
    print(f"latest_json={latest_json}")
    print(f"latest_md={latest_md}")
    print(f"history_jsonl={history}")

    return 0 if overall_status == "PASS" else (1 if overall_status == "FAIL" else 0)


if __name__ == "__main__":
    raise SystemExit(main())
