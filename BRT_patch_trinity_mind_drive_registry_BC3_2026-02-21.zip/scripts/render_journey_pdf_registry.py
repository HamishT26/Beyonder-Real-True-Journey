#!/usr/bin/env python3
"""
Render docs/journey_pdf_registry_v0.json to docs/journey_pdf_registry_v0.md.
"""
from __future__ import annotations
import json
from pathlib import Path

def main() -> int:
    src = Path("docs/journey_pdf_registry_v0.json")
    dst = Path("docs/journey_pdf_registry_v0.md")
    if not src.exists():
        print(f"missing {src}")
        return 1
    payload = json.loads(src.read_text(encoding="utf-8"))
    entries = payload.get("entries", [])
    lines = [
        "# Journey PDF Registry v0",
        "",
        payload.get("purpose",""),
        "",
        f"- suggested_drive_folder_name: `{payload.get('suggested_drive_folder_name','')}`",
        "",
        "| version_label | agent_name | title | drive_file_id | created_time_utc | modified_time_utc | ingestion_status | drive_url | notes |",
        "|---|---|---|---|---|---|---|---|---|",
    ]
    for e in entries:
        lines.append(
            "| {version_label} | {agent_name} | {title} | {drive_file_id} | {created} | {modified} | {status} | {url} | {notes} |".format(
                version_label=e.get("version_label",""),
                agent_name=e.get("agent_name",""),
                title=e.get("title",""),
                drive_file_id=e.get("drive_file_id",""),
                created=e.get("created_time_utc",""),
                modified=e.get("modified_time_utc",""),
                status=e.get("ingestion_status",""),
                url=e.get("drive_url",""),
                notes=str(e.get("notes","")).replace("\n"," "),
            )
        )
    dst.write_text("\n".join(lines).strip()+"\n", encoding="utf-8")
    print(f"wrote {dst}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
