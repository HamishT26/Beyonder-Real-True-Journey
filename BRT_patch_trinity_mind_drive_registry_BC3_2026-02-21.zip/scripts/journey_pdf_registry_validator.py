#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path

REQUIRED = {"drive_file_id","title","drive_url","ingestion_status"}

def main() -> int:
    path = Path("docs/journey_pdf_registry_v0.json")
    if not path.exists():
        print(f"Missing: {path}")
        return 1
    payload = json.loads(path.read_text(encoding="utf-8"))
    entries = payload.get("entries", [])
    if not isinstance(entries, list) or not entries:
        print("No entries list found.")
        return 1

    seen = set()
    errors = 0
    for i, e in enumerate(entries):
        if not isinstance(e, dict):
            print(f"Entry {i} not an object")
            errors += 1
            continue
        missing = sorted(REQUIRED - set(e.keys()))
        if missing:
            print(f"Entry {i} missing fields: {missing}")
            errors += 1
        fid = str(e.get("drive_file_id","")).strip()
        if fid:
            if fid in seen:
                print(f"Duplicate drive_file_id: {fid}")
                errors += 1
            seen.add(fid)
    print("registry_ok" if errors == 0 else f"registry_errors={errors}")
    return 0 if errors == 0 else 1

if __name__ == "__main__":
    raise SystemExit(main())
