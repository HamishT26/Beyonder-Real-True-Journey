"""
mind_track_runner.py
--------------------

Reproducible Mind-track smoke runner for GMUT artifacts.

Core checks:
1) py_compile core modules (only those that exist)
2) GMUT gamma sweep (via trinity_simulation_engine.GMUTSimulator)

Optional checks (auto-skip if inputs missing):
3) scripts/gmut_anchor_trace_validator.py
4) scripts/gmut_external_anchor_exclusion_note.py

Writes:
- docs/mind-track-runs/<stamp>-mind-track-smoke.{json,md}
- docs/mind-track-smoke-latest.{json,md}
- docs/mind-track-metrics-latest.json
- docs/mind-track-metrics-history.jsonl
"""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional

from trinity_simulation_engine import GMUTSimulator


@dataclass
class StepResult:
    name: str
    command: List[str]
    returncode: int
    duration_seconds: float
    stdout: str
    stderr: str
    metrics: Dict[str, object] = field(default_factory=dict)


def _run_subprocess_step(name: str, command: List[str]) -> StepResult:
    started = time.perf_counter()
    completed = subprocess.run(command, capture_output=True, text=True, check=False)
    duration = time.perf_counter() - started
    return StepResult(
        name=name,
        command=command,
        returncode=completed.returncode,
        duration_seconds=duration,
        stdout=(completed.stdout or "").strip(),
        stderr=(completed.stderr or "").strip(),
        metrics={},
    )


def _run_gmut_sweep(gammas: List[float]) -> StepResult:
    started = time.perf_counter()
    sim = GMUTSimulator()
    ratios: Dict[str, float] = {}
    for g in gammas:
        ratio = sim.run_simulation(gamma=g).energy_density_ratio()
        ratios[f"{g:.6g}"] = float(ratio)

    values = list(ratios.values())
    monotonic = all(values[i] <= values[i + 1] for i in range(len(values) - 1)) if values else True
    ratio_min = min(values) if values else None
    ratio_max = max(values) if values else None
    ratio_span = (ratio_max - ratio_min) if (ratio_min is not None and ratio_max is not None) else None

    duration = time.perf_counter() - started
    stdout_lines = [f"Gamma={k}: energy_density_ratio={v:.8f}" for k, v in ratios.items()]
    return StepResult(
        name="gmut_gamma_sweep",
        command=["(internal)", "GMUTSimulator.run_simulation", "--gammas", *[str(g) for g in gammas]],
        returncode=0,
        duration_seconds=duration,
        stdout="\n".join(stdout_lines),
        stderr="",
        metrics={
            "gamma_count": len(ratios),
            "gamma_ratios": ratios,
            "ratio_min": ratio_min,
            "ratio_max": ratio_max,
            "ratio_span": ratio_span,
            "monotonic_non_decreasing": monotonic,
        },
    )


def _trim(text: str, max_lines: int = 30) -> str:
    if not text:
        return "(empty)"
    lines = text.splitlines()
    if len(lines) <= max_lines:
        return "\n".join(lines)
    return "\n".join(lines[:max_lines] + [f"... ({len(lines) - max_lines} more lines)"])


def _build_summary(steps: List[StepResult]) -> Dict[str, object]:
    total_steps = len(steps)
    passed_steps = sum(1 for s in steps if s.returncode == 0)
    total_duration = round(sum(s.duration_seconds for s in steps), 6)
    pass_rate = round((passed_steps / total_steps) if total_steps else 0.0, 6)
    mind_health_score = round(pass_rate * 100.0, 2)
    return {
        "total_steps": total_steps,
        "passed_steps": passed_steps,
        "failed_steps": total_steps - passed_steps,
        "pass_rate": pass_rate,
        "total_duration_seconds": total_duration,
        "mind_health_score": mind_health_score,
    }


def _build_markdown(generated_utc: str, overall_status: str, summary: Dict[str, object], steps: List[StepResult]) -> str:
    lines = [
        "# Mind Track Smoke Report",
        "",
        f"- generated_utc: `{generated_utc}`",
        f"- overall_status: **{overall_status}**",
        "",
        "## Summary metrics",
        f"- pass_rate: `{summary['pass_rate']}`",
        f"- total_duration_seconds: `{summary['total_duration_seconds']}`",
        f"- mind_health_score: `{summary['mind_health_score']}`",
        "",
        "## Step summary",
        "| step | status | returncode | duration_seconds | command |",
        "|---|---|---:|---:|---|",
    ]
    for s in steps:
        status = "PASS" if s.returncode == 0 else "FAIL"
        lines.append(f"| {s.name} | {status} | {s.returncode} | {s.duration_seconds:.3f} | `{' '.join(s.command)}` |")

    for s in steps:
        lines += [
            "",
            f"## {s.name}",
            "",
            f"- returncode: `{s.returncode}`",
            f"- duration_seconds: `{s.duration_seconds:.3f}`",
            "",
            "### stdout (trimmed)",
            "```",
            _trim(s.stdout),
            "```",
            "",
            "### stderr (trimmed)",
            "```",
            _trim(s.stderr),
            "```",
        ]
        if s.metrics:
            lines += ["", "### extracted_metrics", "```json", json.dumps(s.metrics, indent=2), "```"]

    return "\n".join(lines).strip() + "\n"


def _maybe_run_optional_script(name: str, script_path: Path, required_inputs: List[Path]) -> StepResult:
    if not script_path.exists():
        return StepResult(
            name=name,
            command=[str(script_path)],
            returncode=0,
            duration_seconds=0.0,
            stdout="SKIP: script missing",
            stderr="",
            metrics={"skipped": True, "reason": "script_missing"},
        )
    missing = [str(p) for p in required_inputs if not p.exists()]
    if missing:
        return StepResult(
            name=name,
            command=[sys.executable, str(script_path)],
            returncode=0,
            duration_seconds=0.0,
            stdout=f"SKIP: missing inputs: {missing}",
            stderr="",
            metrics={"skipped": True, "reason": "missing_inputs", "missing": missing},
        )
    return _run_subprocess_step(name, [sys.executable, str(script_path)])


def main() -> int:
    parser = argparse.ArgumentParser(description="Run Mind-track smoke checks and emit reports.")
    parser.add_argument("--gammas", type=float, nargs="+", default=[0.0, 0.05, 0.1, 0.2])
    parser.add_argument("--reports-dir", default="docs/mind-track-runs")
    parser.add_argument("--latest-json", default="docs/mind-track-smoke-latest.json")
    parser.add_argument("--latest-md", default="docs/mind-track-smoke-latest.md")
    parser.add_argument("--latest-metrics", default="docs/mind-track-metrics-latest.json")
    parser.add_argument("--metrics-history", default="docs/mind-track-metrics-history.jsonl")
    args = parser.parse_args()

    root = Path(".")
    reports_dir = root / args.reports_dir
    reports_dir.mkdir(parents=True, exist_ok=True)

    generated_utc = datetime.now(timezone.utc).replace(microsecond=0).isoformat()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    # 1) compile (only compile files that exist)
    candidates = [
        "trinity_simulation_engine.py",
        "run_simulation.py",
        "mind_track_runner.py",
        "scripts/gmut_anchor_trace_validator.py",
        "scripts/gmut_external_anchor_exclusion_note.py",
    ]
    existing = [f for f in candidates if (root / f).exists()]
    compile_step = _run_subprocess_step(
        "compile_python_modules",
        [sys.executable, "-m", "py_compile", *existing] if existing else [sys.executable, "-c", "print('no files to compile')"],
    )

    # 2) simulation sweep
    sweep_step = _run_gmut_sweep(args.gammas)

    # 3/4) optional anchor scripts
    trace_validator = _maybe_run_optional_script(
        "anchor_trace_validation",
        root / "scripts/gmut_anchor_trace_validator.py",
        required_inputs=[
            root / "docs/mind-track-external-anchor-canonical-inputs-v1.json",
            root / "docs/mind-track-external-anchor-trace-manifest-v1.json",
        ],
    )
    exclusion_note = _maybe_run_optional_script(
        "anchor_exclusion_note",
        root / "scripts/gmut_external_anchor_exclusion_note.py",
        required_inputs=[
            root / "docs/mind-track-external-anchor-canonical-inputs-v1.json",
            root / "docs/mind-track-gmut-comparator-latest.json",
        ],
    )

    steps = [compile_step, sweep_step, trace_validator, exclusion_note]

    core_ok = (compile_step.returncode == 0) and (sweep_step.returncode == 0)
    overall_status = "PASS" if core_ok else "FAIL"

    summary = _build_summary(steps)
    payload = {
        "generated_utc": generated_utc,
        "overall_status": overall_status,
        "summary": summary,
        "steps": [asdict(s) for s in steps],
    }
    markdown = _build_markdown(generated_utc, overall_status, summary, steps)

    timestamped_json = reports_dir / f"{stamp}-mind-track-smoke.json"
    timestamped_md = reports_dir / f"{stamp}-mind-track-smoke.md"

    latest_json = root / args.latest_json
    latest_md = root / args.latest_md
    latest_metrics = root / args.latest_metrics
    metrics_history = root / args.metrics_history

    latest_json.parent.mkdir(parents=True, exist_ok=True)
    latest_md.parent.mkdir(parents=True, exist_ok=True)
    latest_metrics.parent.mkdir(parents=True, exist_ok=True)
    metrics_history.parent.mkdir(parents=True, exist_ok=True)

    timestamped_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    timestamped_md.write_text(markdown, encoding="utf-8")
    latest_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    latest_md.write_text(markdown, encoding="utf-8")
    latest_metrics.write_text(json.dumps(summary, indent=2) + "\n", encoding="utf-8")
    with metrics_history.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps({"generated_utc": generated_utc, **summary}) + "\n")

    print(f"overall_status={overall_status}")
    print(f"timestamped_json={timestamped_json}")
    print(f"timestamped_md={timestamped_md}")
    print(f"latest_json={latest_json}")
    print(f"latest_md={latest_md}")
    print(f"latest_metrics={latest_metrics}")
    print(f"metrics_history={metrics_history}")
    return 0 if overall_status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
