#!/usr/bin/env python3
"""repo_audit.py

Offline repo auditor for the Beyonder‑Real‑True Journey repository.

This is designed for situations where ChatGPT can't directly fetch GitHub/Drive.
You (or the assistant, once the zip is uploaded here) can run it locally to
produce a file-by-file inventory and a maturity scorecard.

Usage:
  python repo_audit.py /path/to/repo --out report.md

If you extracted a zip:
  unzip Beyonder-Real-True-Journey-main.zip -d repo
  python repo_audit.py repo/Beyonder-Real-True-Journey-main --out report.md

Notes
- Heuristic scoring only (not scientific validation).
- Safe: does not execute any repo code.
"""

from __future__ import annotations

import argparse
import hashlib
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

PILLARS = {
    "GMUT": [r"gmut", r"grand\s+mandala", r"mandala\s+unified", r"lagrang", r"field\s+equation", r"psi[-_ ]?field", r"\bpsi\b", r"omega[-_ ]?field", r"\b\u03a8\b", r"\b\u03a9\b"],
    "TrinityOS": [r"trinity", r"hybrid\s+os", r"orchestrator", r"module\s+manager", r"qcit", r"quantum-to-classical", r"simulation\s+engine"],
    "FreedID": [r"freed\s*id", r"did", r"decentralized\s+identifier", r"verifiable\s+credential", r"credential", r"registry", r"pbkdf2", r"totp"],
    "CBR": [r"cosmic\s+bill\s+of\s+rights", r"bill\s+of\s+rights", r"rights", r"governance", r"ethic"],
}

CODE_EXT = {".py", ".js", ".ts", ".tsx", ".go", ".rs", ".java", ".kt", ".cpp", ".c", ".cs", ".sh"}
DOC_EXT = {".md", ".rst", ".txt"}
DATA_EXT = {".json", ".yaml", ".yml", ".csv"}

@dataclass
class FileRec:
    rel: str
    size: int
    sha8: str
    pillar_hits: Dict[str, int]
    kind: str


def sha8(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()[:8]


def classify_kind(path: Path) -> str:
    ext = path.suffix.lower()
    if ext in CODE_EXT:
        return "code"
    if ext in DOC_EXT:
        return "doc"
    if ext in DATA_EXT:
        return "data"
    if ext in {".pdf", ".docx"}:
        return "artifact"
    return "other"


def text_for_scan(path: Path, max_bytes: int = 200_000) -> str:
    """Best-effort read for scanning keywords (only for small-ish text files)."""
    try:
        if path.suffix.lower() not in (CODE_EXT | DOC_EXT | DATA_EXT):
            return ""
        if path.stat().st_size > max_bytes:
            return ""
        return path.read_text(errors="ignore")
    except Exception:
        return ""


def count_hits(text: str, patterns: List[str]) -> int:
    total = 0
    for pat in patterns:
        total += len(re.findall(pat, text, flags=re.IGNORECASE))
    return total


def walk_repo(root: Path) -> List[FileRec]:
    recs: List[FileRec] = []
    for p in root.rglob("*"):
        if p.is_dir():
            continue
        rel = str(p.relative_to(root))
        # skip common binary/large dirs
        if rel.startswith((".git/", "node_modules/", "dist/", "build/", ".venv/")):
            continue
        kind = classify_kind(p)
        text = text_for_scan(p)
        hits: Dict[str, int] = {}
        for pillar, pats in PILLARS.items():
            base = count_hits(rel, pats)  # path/name signal
            body = count_hits(text, pats)
            hits[pillar] = base + body
        recs.append(FileRec(rel=rel, size=p.stat().st_size, sha8=sha8(p), pillar_hits=hits, kind=kind))
    return sorted(recs, key=lambda r: r.rel.lower())


def top_dirs(recs: List[FileRec]) -> List[Tuple[str, int]]:
    counts: Dict[str, int] = {}
    for r in recs:
        parts = r.rel.split("/")
        top = parts[0]
        counts[top] = counts.get(top, 0) + 1
    return sorted(counts.items(), key=lambda x: (-x[1], x[0]))


def maturity_score(recs: List[FileRec]) -> Dict[str, int]:
    """Heuristic 0-5 per pillar based on presence of docs, code, tests, experiments."""
    score = {k: 0 for k in PILLARS.keys()}

    has_tests = any(re.search(r"(^|/)test(s)?/|_test\.|\.spec\.", r.rel, flags=re.IGNORECASE) for r in recs)
    has_ci = any(r.rel.lower().startswith(".github/workflows") for r in recs)
    has_readme = any(r.rel.lower() in {"readme.md", "readme"} for r in recs)

    # global hygiene bump
    hygiene = 1 if has_readme else 0
    hygiene += 1 if has_tests else 0
    hygiene += 1 if has_ci else 0

    for pillar in score:
        pillar_recs = [r for r in recs if r.pillar_hits.get(pillar, 0) > 0]
        if not pillar_recs:
            score[pillar] = 0
            continue

        kinds = {r.kind for r in pillar_recs}
        s = 1  # exists
        if "doc" in kinds:
            s += 1
        if "code" in kinds:
            s += 1
        if any(re.search(r"experiments/|notebooks/|simulation", r.rel, flags=re.IGNORECASE) for r in pillar_recs):
            s += 1
        if any(re.search(r"spec|schema", r.rel, flags=re.IGNORECASE) for r in pillar_recs):
            s += 1

        # cap at 5, add small hygiene influence
        s = min(5, s + (1 if hygiene >= 2 else 0))
        score[pillar] = s

    return score


def write_report(root: Path, recs: List[FileRec], out_path: Path) -> None:
    td = top_dirs(recs)
    score = maturity_score(recs)

    def fmt_bytes(n: int) -> str:
        for unit in ["B", "KB", "MB", "GB"]:
            if n < 1024:
                return f"{n:.0f}{unit}" if unit == "B" else f"{n:.1f}{unit}"
            n /= 1024
        return f"{n:.1f}TB"

    lines: List[str] = []
    lines.append(f"# Repo Audit Report\n")
    lines.append(f"**Root:** `{root}`\n")

    lines.append("## Top-level inventory\n")
    for name, cnt in td[:25]:
        lines.append(f"- `{name}/` — {cnt} files")
    lines.append("")

    lines.append("## Pillar maturity scorecard (heuristic)\n")
    lines.append("Scores 0–5 indicate *repo completeness* signals (docs/specs/code/tests), **not** scientific validation.\n")
    for k, v in score.items():
        bar = "█" * v + "░" * (5 - v)
        lines.append(f"- **{k}**: {v}/5  `{bar}`")
    lines.append("")

    lines.append("## File-by-file map (selected)\n")
    lines.append("This section lists files with strong pillar signals (hit count ≥ 5), plus key project hygiene files.\n")

    def is_key(rel: str) -> bool:
        low = rel.lower()
        return low in {"readme.md", "license", "license.md", "contributing.md"} or low.startswith(".github/workflows")

    selected = [r for r in recs if is_key(r.rel) or max(r.pillar_hits.values()) >= 5]
    for r in selected[:400]:
        top_pillar = max(r.pillar_hits.items(), key=lambda kv: kv[1])[0]
        lines.append(f"- `{r.rel}` ({r.kind}, {fmt_bytes(r.size)}, sha8={r.sha8}) — top: **{top_pillar}** hits={r.pillar_hits[top_pillar]}")
    lines.append("")

    lines.append("## Next recommended steps\n")
    lines.append("1. Ensure there is **one runnable demo** per pillar (GMUT / TrinityOS / FreedID / CBR).")
    lines.append("2. Add a **tests/** folder (or equivalent) and minimal CI workflow.")
    lines.append("3. Create an `integrate/` branch strategy: theory, os, identity, governance, docs.")
    lines.append("4. For GMUT, add parameterized predictions + notebooks that reproduce plots.")
    lines.append("5. For FreedID, add DID method decision + VC schemas + threat model.\n")

    out_path.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("repo", type=str, help="Path to extracted repo folder")
    ap.add_argument("--out", type=str, default="repo_audit_report.md")
    args = ap.parse_args()

    root = Path(args.repo).expanduser().resolve()
    if not root.exists() or not root.is_dir():
        raise SystemExit(f"Repo folder not found: {root}")

    recs = walk_repo(root)
    out_path = Path(args.out).expanduser().resolve()
    write_report(root, recs, out_path)
    print(f"Wrote report: {out_path}")


if __name__ == "__main__":
    main()
