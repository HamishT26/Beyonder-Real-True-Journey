# Governance Conformance Matrix

This matrix maps Cosmic Bill of Rights (CBR) principles and Freed ID governance
into enforceable controls in the Trinity Hybrid OS.

| Right / Principle | System(s) | Enforcement Mechanism | Evidence | Status | Next Step |
|---|---|---|---|---|---|
| Autonomy | Orchestrator + Freed ID | DID-gated execution; explicit consent hooks | Stage logs + credential | Prototype | add consent prompts + audit trail |
| Privacy | Memory + logs | selective disclosure (VC claims), redaction in logs | redaction report | Concept | implement SD-JWT style claims |
| Safety | Simulation + runner | guardrails (bounds, fail-fast) | report.json | Prototype | add policy rules + thresholds |
| Recourse | Registry | revocation + appeal metadata | revocation list | Concept | add transparency log + appeal workflow |

This document is updated as enforcement mechanisms mature.
