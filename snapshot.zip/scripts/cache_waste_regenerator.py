"""
Cache/Waste Regenerator

This module simulates reclaiming resources from cache and temporary files.
It reports the amount of reclaimed storage, tokens, credits and energy.
In a real system, this module would scan configured directories, purge
unnecessary files subject to safety rules, and calculate reclaimed
resource units for budgeting and reporting.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Dict, Any, List


def _targets() -> List[Path]:
    raw = os.environ.get("CACHE_PATHS", "")
    if raw.strip():
        return [Path(p.strip()) for p in raw.split(":") if p.strip()]
    return [Path.cwd()]


def _collect_waste(root: Path) -> List[Path]:
    waste: List[Path] = []
    waste += list(root.rglob("__pycache__"))
    waste += list(root.rglob("*.pyc"))
    waste += list(root.rglob("*.pyo"))
    return [p for p in waste if p.exists()]

def main() -> Dict[str, Any]:
    """Clean lightweight python caches and return reclaimed metrics."""
    dry_run = os.environ.get("CACHE_DRY_RUN", "0") == "1"
    roots = _targets()
    waste = []
    for r in roots:
        if r.exists():
            waste.extend(_collect_waste(r))

    reclaimed_bytes = 0
    removed = 0
    for p in waste:
        try:
            if p.is_dir():
                # estimate size before removal
                size = sum(f.stat().st_size for f in p.rglob("*") if f.is_file())
                reclaimed_bytes += size
                if not dry_run:
                    for f in sorted(p.rglob("*"), reverse=True):
                        if f.is_file():
                            f.unlink(missing_ok=True)
                        elif f.is_dir():
                            try:
                                f.rmdir()
                            except OSError:
                                pass
                    p.rmdir()
                removed += 1
            elif p.is_file():
                size = p.stat().st_size
                reclaimed_bytes += size
                if not dry_run:
                    p.unlink(missing_ok=True)
                removed += 1
        except Exception:
            # best-effort cleanup
            continue

    reclaimed_tokens = reclaimed_bytes / 50_000  # heuristic
    reclaimed_credits = reclaimed_bytes / 100_000
    reclaimed_energy = reclaimed_bytes / 1_000_000

    return {
        "dry_run": dry_run,
        "roots": [str(r) for r in roots],
        "waste_items": len(waste),
        "removed": removed,
        "reclaimed_bytes": int(reclaimed_bytes),
        "reclaimed_tokens": float(reclaimed_tokens),
        "reclaimed_credits": float(reclaimed_credits),
        "reclaimed_energy": float(reclaimed_energy),
    }