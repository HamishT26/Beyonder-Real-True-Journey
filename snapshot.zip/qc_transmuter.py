"""qc_transmuter.py

Quantum-to-Classical Information Transmuter (QCIT)

This module provides a lightweight, dependency-free implementation of a
"quantum-to-classical" transmutation step.

Given a list of complex amplitudes representing a quantum state (not
necessarily normalized), QCIT:

1) normalizes amplitudes,
2) computes measurement probabilities,
3) samples a histogram of measurement outcomes ("shots"),
4) derives a compact classical feature vector.

The goal is not to claim physical novelty; it is to provide a consistent
software interface for integrating quantum-like state representations into
the Trinity Hybrid OS pipeline.
"""

from __future__ import annotations

import math
import random
from typing import Any, Dict, List, Optional


def _normalize(amplitudes: List[complex]) -> List[complex]:
    norm_sq = sum((a.real * a.real + a.imag * a.imag) for a in amplitudes)
    if norm_sq <= 0.0:
        n = max(1, len(amplitudes))
        return [complex(1.0 / math.sqrt(n), 0.0) for _ in range(n)]
    inv = 1.0 / math.sqrt(norm_sq)
    return [a * inv for a in amplitudes]


def _probs(amplitudes: List[complex]) -> List[float]:
    return [(a.real * a.real + a.imag * a.imag) for a in amplitudes]


def _entropy_bits(p: List[float]) -> float:
    h = 0.0
    for x in p:
        if x > 0.0:
            h -= x * math.log2(x)
    return h


def _effective_dimension(p: List[float]) -> float:
    denom = sum((x * x) for x in p)
    return (1.0 / denom) if denom > 0.0 else float("nan")


def transmute_state(
    amplitudes: List[complex],
    shots: int = 1024,
    seed: Optional[int] = None,
    top_k: int = 8,
) -> Dict[str, Any]:
    """Transmute a quantum-like state into classical features."""

    if seed is not None:
        random.seed(seed)

    amps = _normalize(amplitudes)
    p = _probs(amps)
    n = len(p)

    counts = [0] * n

    # cumulative distribution for sampling
    cdf = []
    running = 0.0
    for x in p:
        running += x
        cdf.append(running)
    if cdf:
        cdf[-1] = 1.0

    for _ in range(max(0, int(shots))):
        r = random.random()
        idx = 0
        while idx < n and r > cdf[idx]:
            idx += 1
        if idx >= n:
            idx = n - 1
        counts[idx] += 1

    ranked = sorted(range(n), key=lambda i: p[i], reverse=True)
    top = ranked[: max(1, min(int(top_k), n))]
    histogram = {str(i): counts[i] for i in top}

    h_bits = _entropy_bits(p)
    eff_dim = _effective_dimension(p)

    p_max = max(p) if p else float("nan")
    i_max = int(ranked[0]) if ranked else -1

    feature_vector = {
        "n_states": n,
        "p_max": p_max,
        "argmax": i_max,
        "entropy_bits": h_bits,
        "effective_dimension": eff_dim,
        "topk_prob_mass": float(sum(p[i] for i in top)) if top else 0.0,
    }

    return {
        "shots": int(shots),
        "n_states": n,
        "topk_histogram": histogram,
        "feature_vector": feature_vector,
    }


if __name__ == "__main__":
    # Tiny smoke test
    amps = [1 + 0j, 0.5 + 0.5j, 0.1 + 0j, 0.0 + 0j]
    print(transmute_state(amps, shots=1000, seed=7))
