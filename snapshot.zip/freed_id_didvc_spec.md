# Freed ID DID and Verifiable Credential Specification

This document defines a minimal DID method (`did:freed`) and a corresponding
Verifiable Credential (VC) profile for Freed ID certificates. It is intended
to align the Beyonder‑Real‑True Freed ID system with the W3C DID Core and
Verifiable Credentials standards, enabling interoperability with other
decentralised identity systems.

## DID Method: `did:freed`

A Freed ID DID has the following structure:

```
did:freed:<uniqueIdentifier>
```

`<uniqueIdentifier>` is a base58‑encoded string derived from a cryptographic
public key or other unique source. Each DID resolves to a DID Document that
describes how to verify the subject’s control over the identifier.

### DID Document

An example DID Document for a Freed ID is:

```json
{
  "@context": [
    "https://www.w3.org/ns/did/v1",
    "https://w3id.org/security/suites/ed25519-2020/v1"
  ],
  "id": "did:freed:example123",
  "verificationMethod": [
    {
      "id": "did:freed:example123#key-1",
      "type": "Ed25519VerificationKey2020",
      "controller": "did:freed:example123",
      "publicKeyMultibase": "z6MkrG..."
    }
  ],
  "authentication": ["did:freed:example123#key-1"],
  "assertionMethod": ["did:freed:example123#key-1"],
  "service": [
    {
      "id": "did:freed:example123#credentials",
      "type": "FreedIDCredentialRegistry",
      "serviceEndpoint": "https://freed.example/registry"
    }
  ]
}
```

The DID Document lists verification methods for authentication and assertion,
and defines a service endpoint where credentials can be issued or revoked.

### DID Resolution

The `did:freed` method resolves DIDs via a simple registry service.
Given a DID, the resolver performs a lookup in the registry and returns the
stored DID Document. The registry maintains an append‑only log of DID
registrations and updates.

## Verifiable Credential: `FreedIDCredential`

Freed ID certificates are represented as W3C Verifiable Credentials. A
minimal Freed ID credential contains claims about the holder’s Freed ID
level and rights, along with cryptographic proofs.

### Credential Schema

```json
{
  "@context": [
    "https://www.w3.org/2018/credentials/v1",
    "https://freed.example/contexts/freed-id.jsonld"
  ],
  "id": "urn:uuid:90d4...",
  "type": ["VerifiableCredential", "FreedIDCredential"],
  "issuer": "did:freed:issuer456",
  "issuanceDate": "2026-02-19T00:00:00Z",
  "credentialSubject": {
    "id": "did:freed:example123",
    "level": 6,
    "rights": [
      "autonomy",
      "privacy",
      "fairness",
      "safety",
      "cosmic community"
    ]
  },
  "proof": {
    "type": "Ed25519Signature2020",
    "created": "2026-02-19T00:00:01Z",
    "verificationMethod": "did:freed:issuer456#key-1",
    "proofPurpose": "assertionMethod",
    "jws": "eyJhbGciOiJFZERTQSJ9..."
  }
}
```

The `credentialSubject` contains the DID of the holder, the level of Freed ID,
and an array of rights derived from the Cosmic Bill of Rights. The `issuer`
is another DID capable of issuing Freed ID credentials. The `proof` field
contains a JSON Web Signature (JWS) verifying the credential’s authenticity.

### Credential Issuance and Verification

Issuers create credentials by generating a new UUID for the credential ID,
setting the `issuer`, `issuanceDate` and `credentialSubject` fields, and
signing the credential using their private key. Holders present credentials
to verifiers, who then resolve the issuer’s DID, retrieve the public key,
and verify the JWS signature.

Revocation can be implemented by adding a `credentialStatus` entry with a
URL pointing to a revocation list or status registry. Verifiers must check
the status of a credential before accepting it.

---

This specification is intended as a starting point. Further extensions
should include richer claim schemas, multi‑signature credentials, and
integration with the Cosmic Bill of Rights enforcement mechanisms.
