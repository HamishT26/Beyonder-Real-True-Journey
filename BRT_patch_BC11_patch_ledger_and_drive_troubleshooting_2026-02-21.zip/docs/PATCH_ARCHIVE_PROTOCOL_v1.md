# Patch Archive Protocol (v1)

generated_utc: `2026-02-21T06:38:50Z`

## Goal
Keep patches **verifiable**, **findable**, and **easy to reapply**.

## Local workflow
1) Create `patches/` folder in repo root.
2) Download (or copy) patch zips into `patches/`.
3) Generate ledger:
```bash
python scripts/patch_ledger_local.py
```
4) (Optional) verify a patch zip contains a valid manifest:
```bash
python scripts/verify_patch_manifest.py --zip patches/<PATCH>.zip
```
5) Commit:
- `docs/patch-ledger.json`
- `docs/PATCH_LEDGER.md`

## Drive workflow
- Upload patch zips to Drive `Beyonder-Real-True_System/patches/`
- Keep the ledger in GitHub so anyone can verify the archive integrity.

## Apply order reminder
Use `docs/BC_PATCH_APPLY_ORDER_v1.md` (BC3 → BC10 → …)
