# Drive Patch Visibility Troubleshooting (v1)

generated_utc: `2026-02-21T06:38:50Z`

If you uploaded patch zips to Drive but ChatGPT/connector views show an empty folder, common causes:

## 1) Upload still pending (mobile background)
- Android/iOS Drive can show the file locally while upload is still syncing.
- Check Drive app → the file’s status (spinning/progress icon).

## 2) Uploaded to a different account / Drive
- Verify you’re in the correct Google account in the Drive app.
- Check: Drive app → profile icon → account email.

## 3) Uploaded into a different folder (similar names)
- In Drive: open the file → “i” details → confirm its parent folder is `patches/`.

## 4) Connector indexing delay
- Some connectors lag behind Drive by minutes/hours.
- If you can see files in Drive web UI but not in ChatGPT, wait and retry later.

## 5) Permission edge
- If the folder is shared, ensure **you** have access as the connected account (hamisht4647@gmail.com).

## Best quick verification
- Open the `patches/` folder in a browser (not just the app), and confirm files appear.
- Sort by “Last modified” and screenshot the list.
