#!/usr/bin/env python3
"""
scripts/verify_patch_manifest.py
--------------------------------

Verify a patch zip that contains a PATCH_MANIFEST*.json listing sha256 checksums.

Usage:
    python scripts/verify_patch_manifest.py --zip patches/BRT_patch_BC10_....zip

Exit code:
- 0 if all checks pass
- 1 otherwise
"""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import re
import zipfile
from typing import Dict, Any, Optional


MANIFEST_RE = re.compile(r"PATCH_MANIFEST_.*\.json$", re.IGNORECASE)


def sha256_bytes(b: bytes) -> str:
    h = hashlib.sha256()
    h.update(b)
    return h.hexdigest()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--zip", required=True, help="Path to patch zip")
    args = ap.parse_args()

    ok = True
    with zipfile.ZipFile(args.zip, "r") as z:
        manifest_name: Optional[str] = None
        for n in z.namelist():
            if MANIFEST_RE.search(n):
                manifest_name = n
                break
        if not manifest_name:
            print("FAIL: no PATCH_MANIFEST_*.json found in zip")
            return 1

        manifest = json.loads(z.read(manifest_name).decode("utf-8"))
        files = manifest.get("files", [])
        if not isinstance(files, list):
            print("FAIL: manifest 'files' not a list")
            return 1

        for f in files:
            rel = f.get("path")
            expected = f.get("sha256")
            if not rel or not expected:
                print(f"FAIL: bad manifest entry: {f}")
                ok = False
                continue
            try:
                content = z.read(rel)
            except KeyError:
                print(f"FAIL: missing file in zip: {rel}")
                ok = False
                continue
            actual = sha256_bytes(content)
            if actual != expected:
                print(f"FAIL: sha mismatch {rel}\n  expected={expected}\n  actual  ={actual}")
                ok = False
            else:
                print(f"OK: {rel}")

    print("PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
