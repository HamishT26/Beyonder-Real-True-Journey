#!/usr/bin/env python3
"""
scripts/patch_ledger_local.py
-----------------------------

Generate a local patch ledger from .zip files in a directory.

Default input dir: ./patches
Outputs:
- docs/patch-ledger.json
- docs/PATCH_LEDGER.md

This is intentionally "Drive-agnostic": you can download your Drive patch zips
into ./patches, then run this script to produce a verifiable index.

Usage:
    python scripts/patch_ledger_local.py
    python scripts/patch_ledger_local.py --patches-dir patches --out-json docs/patch-ledger.json --out-md docs/PATCH_LEDGER.md
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional


BC_RE = re.compile(r"\bBC(\d+)\b", re.IGNORECASE)


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def detect_bc(filename: str) -> Optional[int]:
    m = BC_RE.search(filename)
    if not m:
        return None
    try:
        return int(m.group(1))
    except ValueError:
        return None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--patches-dir", default="patches")
    ap.add_argument("--out-json", default="docs/patch-ledger.json")
    ap.add_argument("--out-md", default="docs/PATCH_LEDGER.md")
    args = ap.parse_args()

    root = Path(".")
    patches_dir = root / args.patches_dir
    out_json = root / args.out_json
    out_md = root / args.out_md

    out_json.parent.mkdir(parents=True, exist_ok=True)
    out_md.parent.mkdir(parents=True, exist_ok=True)

    entries: List[Dict[str, Any]] = []
    if patches_dir.exists():
        for p in sorted(patches_dir.glob("*.zip")):
            stat = p.stat()
            entries.append({
                "filename": p.name,
                "path": str(p),
                "bc": detect_bc(p.name),
                "bytes": int(stat.st_size),
                "modified_utc": datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).replace(microsecond=0).isoformat(),
                "sha256": sha256_file(p),
            })

    payload = {
        "generated_utc": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "patches_dir": str(patches_dir),
        "count": len(entries),
        "entries": entries,
    }
    out_json.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")

    # Markdown
    lines: List[str] = [
        "# Patch Ledger",
        "",
        f"- generated_utc: `{payload['generated_utc']}`",
        f"- patches_dir: `{payload['patches_dir']}`",
        f"- count: `{payload['count']}`",
        "",
        "## Patches",
        "| BC | filename | bytes | modified_utc | sha256 |",
        "|---:|---|---:|---|---|",
    ]
    for e in entries:
        bc = e["bc"] if e["bc"] is not None else "-"
        lines.append(f"| {bc} | {e['filename']} | {e['bytes']} | {e['modified_utc']} | `{e['sha256']}` |")

    lines += [
        "",
        "## Notes",
        "- Put your downloaded Drive patch zips into `./patches/` and re-run this script to refresh the ledger.",
        "- The SHA256 values are your integrity anchors: if a file changes, the hash changes.",
    ]
    out_md.write_text("\n".join(lines).strip() + "\n", encoding="utf-8")

    print(f"wrote={out_json}")
    print(f"wrote={out_md}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
